#!/usr/bin/env python3
"""Frozen background-update design and unmodified legacy regression cohort."""
import argparse,csv,hashlib,io,json,platform,random,subprocess,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/certified'
MAPS=['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown']
MAIN=['mc','fresh-backward','author-mesh','author-lattice','author-lazy','mpgaa-grouped','cached-dlite','cmesh-dlite','csb','mir']
ABLATIONS=['mc-geometry','mc-flat','mc-uniform','path-reuse']
REGRESSION=['mc','fresh-backward','author-mesh','author-lazy','mpgaa-grouped']
VALIDATION=MAIN+['mc-uniform']

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def command(job,method):
    model='lattice';algo=method;binary='certified'
    if method.startswith('author-'):binary='author_baseline'
    elif method=='cached-dlite':binary='ima';algo='dlite-cached'
    elif method=='cmesh-dlite':binary='ima';model='cmesh';algo='dlite'
    elif method in ['csb','mir']:binary='repair'
    return [str(ROOT/'bin'/binary),'--model',str(ROOT/f'data/{job["control"]}_{model}.model'),
            '--workload',str(ROOT/job['workfile']),'--algorithm',algo]

def reference(grid,start,goal,control,tmp):
    H=len(grid);W=len(grid[0]);mp=tmp/'snapshot.map';wp=tmp/'snapshot.work'
    mp.write_text(f'type octile\nheight {H}\nwidth {W}\nmap\n'+'\n'.join(''.join('@' if v else '.' for v in row) for row in grid)+'\n')
    wp.write_text(str(mp)+'\n'+' '.join(map(str,(*start,*goal)))+'\n'+' '.join(map(str,(*start,0)))+'\n')
    run=subprocess.run([str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{control}_lattice.model'),
         '--workload',str(wp),'--algorithm','astar','--dump'],check=True,capture_output=True,text=True,timeout=240)
    rows=list(csv.DictReader(io.StringIO(run.stdout)));ids=list(map(int,run.stderr.strip().split()[2:]))
    return int(rows[0]['cost']),ids

def states_on_path(start,ids,primitives):
    states=[start];costs=[0];cells=[];r,c,h=start
    for pid in ids:
        p=primitives[pid];cells.extend((r+a,c+b) for a,b in p['trace'])
        a,b,h=p['goal'];r+=a;c+=b;states.append((r,c,h));costs.append(costs[-1]+p['cost'])
    return states,costs,cells

def background(mapname,control,mode,seed,tmp):
    suffix=f'bg__{mapname}__{control}__{mode}__{seed}';target=ROOT/'workloads'/f'{suffix}.work'
    # Eligible roots are sampled by an independent legacy A*, never MC-A* time.
    prims=json.loads((ROOT/f'data/{control}_primitives.json').read_text());byid={p['id']:p for p in prims}
    original=(ROOT/f'maps/{mapname}.map').read_text().splitlines();H=int(original[1].split()[1]);W=int(original[2].split()[1])
    base=[[v not in '.GS' for v in row[:W]] for row in original[4:4+H]]
    for attempt in range(30):
        initial_seed=seed+10000*attempt;sample=tmp/'root.work'
        subprocess.run([str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{control}_lattice.model'),
             '--map',str(ROOT/f'maps/{mapname}.map'),'--generate',str(sample),'--seed',str(initial_seed),
             '--episodes','0','--pattern','local','--moving','0'],check=True,capture_output=True,text=True,timeout=240)
        values=list(map(int,sample.read_text().splitlines()[1].split()));start=tuple(values[:3]);goal=tuple(values[3:])
        oldcost,ids=reference(base,start,goal,control,tmp)
        if oldcost>0 and len(ids)>=12:break
    else:raise RuntimeError('Could not sample an eligible root')
    grid=[r[:] for r in base];initial=start;overlay=set();rng=random.Random(seed*7001+MAPS.index(mapname)*17+(control=='add')*101)
    # Paired modes share root and random seed; only actual robot moves differ.
    lines=[str(ROOT/f'maps/{mapname}.map'),' '.join(map(str,(*start,*goal)))];records=[];moved=0
    for ep in range(25):
        previous_start=start;previous_ids=ids[:];previous_cost=oldcost
        if ep and mode=='moving' and ep%4==0 and moved<4 and len(ids)>4:
            p=byid[ids.pop(0)];a,b,h=p['goal'];start=(start[0]+a,start[1]+b,h);moved+=1
        states,costs,pathcells=states_on_path(previous_start,previous_ids,byid)
        oldsuffix=-1
        if previous_cost>=0 and start in states:oldsuffix=previous_cost-costs[states.index(start)]
        changes=[];event='initial'
        if ep:
            event='shock' if ep%8==0 else 'background'
            remaining_cells=states_on_path(start,ids,byid)[2]
            if event=='shock' and len(remaining_cells)>10:
                center=remaining_cells[len(remaining_cells)//2]
            else:
                for _ in range(1000):
                    center=(rng.randrange(1,H-1),rng.randrange(1,W-1))
                    if not base[center[0]][center[1]]:break
            new=set()
            for r in range(max(0,center[0]-1),min(H,center[0]+2)):
                for c in range(max(0,center[1]-1),min(W,center[1]+2)):
                    if not base[r][c] and (r,c) not in [start[:2],goal[:2]]:new.add((r,c))
            for r,c in sorted(overlay|new):
                value=(r,c) in new
                if grid[r][c]!=value:changes.append((r,c,int(value)));grid[r][c]=value
            overlay=new
        lines.append(' '.join(map(str,(*start,len(changes)))));lines+=[' '.join(map(str,q)) for q in changes]
        cost,ids=reference(grid,start,goal,control,tmp)
        if cost==0:raise RuntimeError('Finished-goal query would make timing trivial')
        category='initial' if ep==0 else 'off_reference' if oldsuffix<0 else 'disconnected' if cost<0 else 'increase_finite' if cost>oldsuffix else 'improvement' if cost<oldsuffix else 'unchanged'
        records.append(dict(name=suffix,episode=ep,cost=cost,category=category,event=event,previous_suffix_cost=oldsuffix))
        oldcost=cost
    target.write_text('\n'.join(lines)+'\n')
    job=dict(name=suffix,map=mapname,control=control,mode=mode,seed=seed,actual_root_seed=initial_seed,
             moves=moved,cohort='primary' if seed==1006 else 'validation',workfile=str(target.relative_to(ROOT)),
             episodes=25,workload_sha256=digest(target))
    return job,records

def prepare():
    OUT.mkdir(exist_ok=True);jobs=[];refs=[]
    plan=dict(primary_seed=1006,validation_seed=1007,background_replans=24,
              patch='3x3, uniform static-free center; relocate previous patch',
              shocks='every eighth event uses middle swept cell of independent forward-A* path',
              movement='up to four first-primitive moves, every fourth event, at least four remaining primitives',
              main_methods=MAIN,ablations=ABLATIONS,regression_methods=REGRESSION,repeats=3)
    if (OUT/'cohorts.json').exists():raise RuntimeError('Inputs already frozen; do not overwrite them')
    (OUT/'design.json').write_text(json.dumps(plan,indent=2)+'\n')
    with tempfile.TemporaryDirectory(prefix='mc_generation_') as directory:
        tmp=Path(directory)
        for i,mapname in enumerate(MAPS):
            for k,control in enumerate(['base','add']):
                for mode in ['fixed','moving']:
                    job,r=background(mapname,control,mode,1006,tmp);jobs.append(job);refs+=r
                mode=['fixed','moving'][(i+k)%2]
                job,r=background(mapname,control,mode,1007,tmp);jobs.append(job);refs+=r
                print('generated',len(jobs),'/ 36',mapname,control,flush=True)
    prior=json.loads((ROOT/'results/repair/influence/cohorts.json').read_text())
    prior_ref=list(csv.DictReader((ROOT/'results/repair/influence/reference.csv').open()))
    for j in prior:
        job=dict(j,cohort='regression',workfile='workloads/'+j['name']+'.work',episodes=17)
        job['workload_sha256']=digest(ROOT/job['workfile']);jobs.append(job)
        refs += [dict(name=r['name'],episode=int(r['episode']),cost=int(r['cost']),category=r['category'],
                      event='legacy',previous_suffix_cost=int(r['previous_suffix_cost'])) for r in prior_ref if r['name']==j['name']]
    (OUT/'cohorts.json').write_text(json.dumps(jobs,indent=2)+'\n')
    with (OUT/'reference.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=refs[0],lineterminator='\n');writer.writeheader();writer.writerows(refs)
    print('Frozen',len(jobs),'sequences,',len(refs),'snapshots',flush=True)

def run(cohort):
    jobs=json.loads((OUT/'cohorts.json').read_text());jobs=[j for j in jobs if cohort=='all' or j['cohort']==cohort]
    raw=OUT/'raw';raw.mkdir(exist_ok=True)
    files=[ROOT/'bin'/x for x in ['certified','repair','ima','author_baseline']]
    files += [ROOT/'src'/x for x in ['certified.cpp','mpgaa_reference.hpp','repair.cpp','ima.cpp','author_baseline.cpp']]
    sha={str(p.relative_to(ROOT)):digest(p) for p in files}
    env=raw/'environment.json'
    if env.exists():assert json.loads(env.read_text())['sha256']==sha,'Code/binary changed'
    else:env.write_text(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        platform=platform.platform(),compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
        cpu=subprocess.check_output(['lscpu'],text=True),sha256=sha,
        note='Sequential timed processes, random order per sequence/repeat; no concurrent tests/builds.'),indent=2)+'\n')
    expected={}
    for r in csv.DictReader((OUT/'reference.csv').open()):expected.setdefault(r['name'],[]).append(int(r['cost']))
    rng=random.Random(619973);rng.shuffle(jobs);start=time.monotonic();done=queries=0
    for job in jobs:
        assert digest(ROOT/job['workfile'])==job['workload_sha256']
        methods=REGRESSION if job['cohort']=='regression' else MAIN+ABLATIONS if job['cohort']=='primary' else VALIDATION
        for rep in range(3):
            order=methods[:];rng.shuffle(order)
            for method in order:
                dst=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not dst.exists():
                    p=subprocess.run(command(job,method),check=True,text=True,capture_output=True,timeout=300)
                    rows=list(csv.DictReader(io.StringIO(p.stdout)))
                    assert [int(r['cost']) for r in rows]==expected[job['name']],(job['name'],method,'cost mismatch')
                    dst.write_text(p.stdout)
                else:
                    rows=list(csv.DictReader(dst.open()));assert [int(r['cost']) for r in rows]==expected[job['name']]
                done+=1;queries+=job['episodes']
        print(done,'runs;',round(time.monotonic()-start,1),'seconds;',job['name'],flush=True)
    (raw/f'completion_{cohort}.json').write_text(json.dumps(dict(status='passed',runs=done,queries=queries,
          sequences=len(jobs),cost_disagreements=0,seconds=time.monotonic()-start),indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','run'],required=True)
    p.add_argument('--cohort',choices=['all','primary','validation','regression'],default='all');a=p.parse_args()
    prepare() if a.stage=='prepare' else run(a.cohort)
