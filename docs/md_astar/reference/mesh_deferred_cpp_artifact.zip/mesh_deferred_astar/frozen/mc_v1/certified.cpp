// MC-A*: a map-independent mesh certificate plus an exact A* fallback.
#define REPAIR_LIBRARY
#include "repair.cpp"
#include <array>
#include "mpgaa_reference.hpp"

class MeshCertificate {
    using V8=std::array<I,8>;
    std::array<RC,8> directions{{{1000,414},{414,1000},{-414,1000},{-1000,414},
                                {-1000,-414},{-414,-1000},{414,-1000},{1000,-414}}};
    I alpha;
    I dot(int a,int r,int c)const {return alpha*(I(directions[a].r)*r+I(directions[a].c)*c);}
public:
    std::array<V8,8> mu;
    I beta;
    I uniform;
    explicit MeshCertificate(const Model& lattice,const std::string& path):alpha(lattice.alpha),beta(alpha) {
        std::string meshpath=path;auto at=meshpath.rfind("_lattice.model");
        if(at==std::string::npos)throw std::runtime_error("Expected lattice model");
        meshpath.replace(at,14,"_mesh.model");Model mesh(meshpath);
        std::vector<int> indegree(mesh.Q),order;
        for(const auto& e:mesh.edges)if(e.pid<0)++indegree[e.dst];
        for(int v=0;v<mesh.Q;++v)if(!indegree[v])order.push_back(v);
        for(size_t i=0;i<order.size();++i)for(int ei:mesh.out[order[i]]) {
            const auto& e=mesh.edges[ei];if(e.pid<0 && !--indegree[e.dst])order.push_back(e.dst);
        }
        if(order.size()!=size_t(mesh.Q))throw std::runtime_error("Primitive mesh is not a DAG");
        std::vector<V8> f(mesh.Q),b(mesh.Q);
        for(int v=0;v<mesh.Q;++v){f[v].fill(INF);b[v].fill(INF);}
        for(int h=0;h<mesh.headings;++h)f[h].fill(0);
        for(int u:order)for(int ei:mesh.out[u]) {
            const auto& e=mesh.edges[ei];if(e.pid>=0)continue;
            for(int a=0;a<8;++a)if(f[u][a]<INF)
                f[e.dst][a]=std::min(f[e.dst][a],f[u][a]+e.cost-dot(a,e.dr,e.dc));
        }
        for(auto it=order.rbegin();it!=order.rend();++it)for(int ei:mesh.out[*it]) {
            const auto& e=mesh.edges[ei];
            for(int a=0;a<8;++a) {
                I tail=e.pid>=0?0:b[e.dst][a];
                if(tail<INF)b[*it][a]=std::min(b[*it][a],e.cost-dot(a,e.dr,e.dc)+tail);
            }
        }
        for(auto& row:mu)row.fill(INF);
        // Every regular vertex is a swept-cell witness. Initial vertices also
        // represent the primitive's origin. Terminal vertices are distinct
        // sinks, so paths cannot accidentally concatenate two primitives.
        for(int u=0;u<mesh.Q;++u)for(int a=0;a<8;++a)for(int z=0;z<8;++z)
            if(f[u][a]<INF && b[u][z]<INF)mu[a][z]=std::min(mu[a][z],f[u][a]+b[u][z]);
        for(const auto& e:mesh.edges)for(auto d:e.trace) {
            bool endpoint=d.r==e.dr && d.c==e.dc;
            bool interior=(d.r||d.c)&&!endpoint;
            if(!interior && !(endpoint&&e.pid>=0))continue;
            for(int a=0;a<8;++a)for(int z=0;z<8;++z) {
                I after=e.pid>=0?0:b[e.dst][z];
                if(f[e.src][a]<INF && after<INF)mu[a][z]=std::min(mu[a][z],
                    f[e.src][a]+e.cost-dot(a,d.r,d.c)-dot(z,e.dr-d.r,e.dc-d.c)+after);
            }
        }
        // An independent flat enumeration is an audit, never the compiler.
        for(const auto& e:lattice.edges)for(auto d:e.trace) {
            I denom=units(d.r,d.c)+units(e.dr-d.r,e.dc-d.c);
            if(denom)beta=std::min(beta,e.cost/denom);
        }
        if(verify_repair_invariants)for(int a=0;a<8;++a)for(int z=0;z<8;++z) {
            I direct=INF;
            for(const auto& e:lattice.edges)for(auto d:e.trace)
                direct=std::min(direct,e.cost-dot(a,d.r,d.c)-dot(z,e.dr-d.r,e.dc-d.c));
            if(mu[a][z]!=direct)throw std::runtime_error("Mesh coefficient differs from primitive enumeration");
        }
        uniform=INF;for(const auto& row:mu)for(I value:row)uniform=std::min(uniform,value);
    }
    static I units(int r,int c){I a=std::abs(r),b=std::abs(c);return 1000*std::max(a,b)+414*std::min(a,b);}
    bool excludes(RC s,RC t,RC q,I upper,uint64_t& terms)const {
        V8 x,y;int a=0,z=0;
        for(int k=0;k<8;++k) {
            x[k]=dot(k,q.r-s.r,q.c-s.c);y[k]=dot(k,t.r-q.r,t.c-q.c);
            if(x[k]>x[a])a=k;
            if(y[k]>y[z])z=k;
        }
        ++terms;if(x[a]+y[z]+mu[a][z]>=upper)return true;
        for(int i=0;i<8;++i)for(int j=0;j<8;++j) {
            if(i==a&&j==z)continue;
            ++terms;if(x[i]+y[j]+mu[i][j]>=upper)return true;
        }
        return false;
    }
};

// For a moving start only the last occurrence of a cell matters: the suffix
// contains a blocked cell iff its last edge index is >= the suffix position.
class SuffixCertificate {
    Graph& g;Chain path;
    std::unordered_map<Id,size_t> index;
    std::unordered_map<int,size_t> last;
    std::set<std::pair<size_t,int>> blocked;
    std::vector<I> remaining;
public:
    size_t certified_at=0;
    explicit SuffixCertificate(Graph& graph):g(graph){}
    void install(const Chain& p) {
        path=p;index.clear();last.clear();blocked.clear();remaining.clear();certified_at=0;
        if(p.cost>=INF)return;
        remaining.assign(p.states.size(),0);
        for(size_t i=0;i<p.states.size();++i)index[p.states[i]]=i;
        for(size_t i=0;i<p.edges.size();++i) {
            auto u=g.pos(p.states[i]);
            for(auto d:g.m.edges[p.edges[i]].trace)last[(u.r+d.r)*g.grid.W+u.c+d.c]=i;
        }
        for(size_t i=p.edges.size();i-->0;)remaining[i]=remaining[i+1]+g.m.edges[p.edges[i]].cost;
    }
    void update(const Changes& changes) {
        for(auto q:changes.blocked){int cell=q.r*g.grid.W+q.c;auto it=last.find(cell);if(it!=last.end())blocked.insert({it->second,cell});}
        for(auto q:changes.opened){int cell=q.r*g.grid.W+q.c;auto it=last.find(cell);if(it!=last.end())blocked.erase({it->second,cell});}
    }
    std::optional<size_t> position(Id u)const {auto it=index.find(u);return it==index.end()?std::optional<size_t>{}:it->second;}
    bool valid(size_t i)const {return blocked.empty()||blocked.rbegin()->first<i;}
    I cost(size_t i)const{return remaining[i];}
    size_t cells()const{return last.size();}
    Chain suffix(size_t i)const{return {remaining[i],{path.states.begin()+i,path.states.end()},{path.edges.begin()+i,path.edges.end()}};}
};

struct CertificateStats {uint64_t certified=0,gate_cells=0,gate_terms=0,search_called=0,witness_probes=0,witness_budget_hit=0;};
class CertifiedPlanner {
    Graph& g;Id goal;std::string method;SuffixCertificate cache;ForwardSearch search;
    std::unique_ptr<MeshCertificate> certificate;
    std::unique_ptr<MPGAAReference> mpgaa;
    bool no_path=false;Id no_path_start=NONE;
    uint64_t previous_work=0;
    I old_goal_lower(Id u)const {
        I exact=search.settled_distance(u);if(exact<INF)return exact;
        if(search.exhausted)return INF;
        auto at=cache.position(u);if(at)return cache.cost(*at);
        auto a=g.pos(u),b=g.pos(goal);return g.m.metric(a.r-b.r,a.c-b.c);
    }
    bool witness_certificate(Id start,const Changes& changes,I upper,CertificateStats& stats) {
        auto s=g.pos(start),t=g.pos(goal);
        uint64_t budget=method=="mc-unbounded"?uint64_t(-1):std::max<uint64_t>(64,previous_work/8);
        for(auto q:changes.opened) {
            ++stats.gate_cells;bool cheap=false;
            if(method=="mc-uniform") {
                ++stats.gate_terms;cheap=g.m.metric(s.r-q.r,s.c-q.c)+g.m.metric(t.r-q.r,t.c-q.c)+certificate->uniform>=upper;
            } else if(method!="mc-flat")cheap=certificate->excludes(s,t,q,upper,stats.gate_terms);
            if(cheap)continue;
            // Last newly feasible edge: its suffix contains only reference-map
            // edges, so an OLD goal-distance lower bound remains valid there.
            for(const auto& d:g.m.dep) {
                if(++stats.witness_probes>budget){stats.witness_budget_hit=1;return false;}
                int r=q.r-d.dr,c=q.c-d.dc;if(!g.grid.inside(r,c))continue;
                const auto& e=g.m.edges[d.edge];Id tail=g.id(r,c,e.src),head=g.head(tail,d.edge);
                if(head==NONE)continue;
                I after=old_goal_lower(head);if(after>=INF)continue;
                I lower=g.m.metric(r-s.r,c-s.c)+e.cost+after;
                if(lower<upper&&g.cost(tail,d.edge)<INF)return false;
            }
        }
        return true;
    }
public:
    CertifiedPlanner(Graph& graph,MeshOracle& oracle,Id t,const std::string& name,const std::string& model):
        g(graph),goal(t),method(name),cache(g),search(g,oracle) {
        if(method=="mc"||method=="sphere"||method=="primitive-gate"||method=="uniform"||method=="mc-geometry"||method=="mc-flat"||method=="mc-uniform"||method=="mc-unbounded")certificate=std::make_unique<MeshCertificate>(g.m,model);
        if(method=="mpgaa"||method=="mpgaa-grouped")mpgaa=std::make_unique<MPGAAReference>(g,oracle,t,method=="mpgaa-grouped");
    }
    size_t cells()const{return cache.cells();}
    Chain solve(Id start,const Changes& changes,CertificateStats& stats) {
        if(mpgaa){stats.search_called=1;return mpgaa->solve(start,changes);}
        bool reuse=method!="fresh"&&method!="fresh-backward"&&method!="fresh-mesh";
        bool frozen=method=="mc"||method=="mc-flat"||method=="mc-uniform"||method=="mc-unbounded";
        if(reuse) {
            cache.update(changes);
            if(no_path&&start==no_path_start&&changes.opened.empty()){stats.certified=1;return {};}
            if(frozen&&no_path&&start==no_path_start&&search.exhausted&&witness_certificate(start,changes,INF,stats)) {
                stats.certified=1;return {};
            }
            auto at=cache.position(start);
            if(at&&*at>=cache.certified_at&&cache.valid(*at)&&g.free(start)&&g.free(goal)) {
                I upper=cache.cost(*at);bool safe=true;auto s=g.pos(start),t=g.pos(goal);
                if(frozen)safe=witness_certificate(start,changes,upper,stats);
                else if(method=="path-reuse")safe=changes.opened.empty();
                else for(auto q:changes.opened) {
                    ++stats.gate_cells;bool excludes=false;
                    if(method=="mc-geometry")excludes=certificate->excludes(s,t,q,upper,stats.gate_terms);
                    else if(method=="sphere") {
                        ++stats.gate_terms;excludes=certificate->beta*(MeshCertificate::units(s.r-q.r,s.c-q.c)+MeshCertificate::units(t.r-q.r,t.c-q.c))>=upper;
                    } else if(method=="uniform") {
                        ++stats.gate_terms;excludes=g.m.metric(s.r-q.r,s.c-q.c)+g.m.metric(t.r-q.r,t.c-q.c)+certificate->uniform>=upper;
                    } else {
                        I lower=INF;
                        for(const auto& e:g.m.edges)for(auto d:e.trace) {
                            ++stats.gate_terms;
                            lower=std::min(lower,g.m.metric(q.r-d.r-s.r,q.c-d.c-s.c)+e.cost+
                                g.m.metric(t.r-q.r+d.r-e.dr,t.c-q.c+d.c-e.dc));
                        }
                        excludes=lower>=upper;
                    }
                    if(!excludes){safe=false;break;}
                }
                if(safe){stats.certified=1;cache.certified_at=*at;return cache.suffix(*at);}
            }
        }
        RepairStats unused;++stats.search_called;
        uint64_t before=g.st.cell_checks+g.st.pushes+g.st.pops;
        auto p=search.solve(start,goal,nullptr,nullptr,unused,method!="fresh"&&method!="fresh-mesh");
        previous_work=g.st.cell_checks+g.st.pushes+g.st.pops-before;
        if(reuse){cache.install(p);no_path=p.cost>=INF;no_path_start=start;}
        return p;
    }
};

int main(int argc,char** argv) {
    try {
        std::unordered_map<std::string,std::string> args;
        for(int i=1;i<argc;++i){std::string k=argv[i];if(k=="--dump"||k=="--audit")args[k]="1";else{if(i+1>=argc)throw std::runtime_error("Missing option");args[k]=argv[++i];}}
        verify_repair_invariants=args.count("--audit");
        std::string method=args.count("--algorithm")?args.at("--algorithm"):"mc";
        const std::set<std::string> methods={"mc","mc-geometry","mc-flat","mc-uniform","mc-unbounded","sphere","primitive-gate","uniform","path-reuse","fresh","fresh-backward","fresh-mesh","mpgaa","mpgaa-grouped"};
        if(!methods.count(method))throw std::runtime_error("Unknown method");
        auto begin=Clock::now();Model model(args.at("--model"));auto w=load_workload(args.at("--workload"));Grid grid(w.map);Graph graph(model,grid);
        MeshOracle oracle(graph,args.at("--model"),method=="fresh-mesh");Id goal=graph.id(w.goal);
        CertifiedPlanner planner(graph,oracle,goal,method,args.at("--model"));
        double setup=std::chrono::duration<double,std::micro>(Clock::now()-begin).count();Chain previous;
        std::cout<<"episode,cost,total_us,expanded,edge_checks,cell_checks,pushes,pops,certified,search_called,gate_cells,gate_terms,cache_cells,changes,setup_us,rss_kib,previous_suffix_valid,previous_suffix_cost,witness_probes,witness_budget_hit\n";
        for(size_t ep=0;ep<w.steps.size();++ep) {
            graph.st={};CertificateStats stats;auto t0=Clock::now();auto changes=change_grid(grid,w.steps[ep]);oracle.snapshot();Id start=graph.id(w.steps[ep].start);
            auto p=planner.solve(start,changes,stats);auto t1=Clock::now();validate_chain(graph,p,start,goal);
            int old_valid=-1;I old_cost=-1;auto at=std::find(previous.states.begin(),previous.states.end(),start);
            if(previous.cost<INF&&at!=previous.states.end()) {
                old_valid=1;old_cost=0;
                for(size_t i=at-previous.states.begin();i<previous.edges.size();++i) {
                    auto u=graph.pos(previous.states[i]);const auto& e=model.edges[previous.edges[i]];old_cost+=e.cost;
                    for(auto d:e.trace)if(!grid.free(u.r+d.r,u.c+d.c))old_valid=0;
                }
            }
            struct rusage rss{};getrusage(RUSAGE_SELF,&rss);const auto& s=graph.st;
            std::cout<<ep<<','<<(p.cost>=INF?-1:p.cost)<<','<<std::chrono::duration<double,std::micro>(t1-t0).count()<<','<<s.expanded<<','<<s.edge_checks<<','<<s.cell_checks<<','<<s.pushes<<','<<s.pops<<','<<stats.certified<<','<<stats.search_called<<','<<stats.gate_cells<<','<<stats.gate_terms<<','<<planner.cells()<<','<<changes.opened.size()+changes.blocked.size()<<','<<(ep==0?setup:0)<<','<<rss.ru_maxrss<<','<<old_valid<<','<<old_cost<<','<<stats.witness_probes<<','<<stats.witness_budget_hit<<'\n';
            if(args.count("--dump")){std::cerr<<"PATH "<<ep;for(int ei:p.edges)std::cerr<<' '<<model.edges[ei].pid;std::cerr<<'\n';}previous=std::move(p);
        }
    }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
