// Independent port of Hernandez, Asin & Baier (AAAI 2015), Algorithms 1--2.
// Generalized from undirected grids to this directed primitive graph via pred().
// The optional grouped event adapter strengthens the baseline, not MC-A*.
class MPGAAReference {
    Graph& g;MeshOracle& oracle;Id goal;bool grouped;
    Potential h;
    struct Arrow {Id next;int edge;};
    std::unordered_map<Id,Arrow> next,support;
    struct Label {I cost=INF;Id parent=NONE;int edge=-1;};
    std::unordered_map<Id,Label> labels;
    std::unordered_map<Id,bool> memo;
    bool impossible=false;Id impossible_start=NONE;
    bool goal_condition(Id u) {
        std::vector<Id> chain;bool good=false;
        while(true) {
            if(u==goal){good=true;break;}
            auto known=memo.find(u);if(known!=memo.end()){good=known->second;break;}
            chain.push_back(u);auto it=next.find(u);
            if(it==next.end() || h.get(u)!=g.m.edges[it->second.edge].cost+h.get(it->second.next) || !oracle.valid(u,it->second.edge))break;
            u=it->second.next;
        }
        for(Id x:chain)memo[x]=good;
        return good;
    }
public:
    MPGAAReference(Graph& graph,MeshOracle& o,Id t,bool groups):g(graph),oracle(o),goal(t),grouped(groups),h(g,o,t){}
    Chain solve(Id start,const Changes& changes) {
        if(grouped)for(auto q:changes.blocked)for(const auto& d:oracle.groups) {
            ++g.st.notify_probes;int r=q.r-d.dr,c=q.c-d.dc;if(!g.grid.inside(r,c))continue;
            auto it=next.find(g.id(r,c,d.heading));
            if(it!=next.end()&&(d.bits&(uint64_t(1)<<g.m.edge_slot[it->second.edge])))next.erase(it);
        }
        if(!grouped)for(auto q:changes.blocked)for(auto d:g.m.dep) {
            ++g.st.notify_probes;int r=q.r-d.dr,c=q.c-d.dc;if(!g.grid.inside(r,c))continue;
            auto it=next.find(g.id(r,c,g.m.edges[d.edge].src));
            if(it!=next.end()&&it->second.edge==d.edge)next.erase(it);
        }
        RepairStats stats;
        h.repair(changes.opened,grouped,stats,[&](Id u,Id parent,int edge){
            next.erase(u);support[u]={parent,edge};
        },[&](Id u){
            auto p=support.find(u);
            if(p!=support.end() && next.find(p->second.next)!=next.end())next[u]=p->second;
        });
        if(verify_repair_invariants)h.audit();
        if(impossible&&impossible_start==start&&changes.opened.empty())return {};
        labels.clear();memo.clear();std::vector<std::pair<Id,I>> closed;
        if(!g.free(start)||!g.free(goal)){impossible=true;impossible_start=start;return {};}
        std::priority_queue<Entry> open;labels[start].cost=0;open.push({{h.get(start),0},start,0});++g.st.pushes;
        Id join=NONE;
        auto value=[&](Id x){auto it=labels.find(x);return it==labels.end()?INF:it->second.cost;};
        while(!open.empty()) {
            auto e=open.top();open.pop();++g.st.pops;I gu=value(e.id);if(e.key.second!=-gu)continue;
            if(goal_condition(e.id)){join=e.id;break;}
            ++g.st.expanded;closed.push_back({e.id,gu});
            g.succ(e.id,[&](Id v,int edge){
                I candidate=gu+g.m.edges[edge].cost;
                if(candidate>=value(v)||!oracle.valid(e.id,edge))return;
                labels[v]={candidate,e.id,edge};open.push({{candidate+h.get(v),-candidate},v,0});++g.st.pushes;
            });
        }
        if(join==NONE){impossible=true;impossible_start=start;return {};}
        Chain path;path.cost=value(join)+h.get(join);Id u=join;path.states.push_back(u);
        while(u!=start){const auto& n=labels.at(u);path.edges.push_back(n.edge);u=n.parent;path.states.push_back(u);}
        std::reverse(path.states.begin(),path.states.end());std::reverse(path.edges.begin(),path.edges.end());
        u=join;
        while(u!=goal){const auto& n=next.at(u);path.edges.push_back(n.edge);u=n.next;path.states.push_back(u);}
        h.learn(closed,path.cost,stats);
        for(size_t i=0;i<path.edges.size();++i)next[path.states[i]]={path.states[i+1],path.edges[i]};
        if(verify_repair_invariants)h.audit();
        impossible=false;return path;
    }
};
