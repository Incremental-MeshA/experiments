// New repair study. The frozen baseline supplies only common data/model code.
#include <map>
#include <optional>
#include <functional>
#define main legacy_program_main
#include "ima.cpp"
#undef main
bool verify_repair_invariants=false;

struct Changes {
    std::vector<RC> opened, blocked;
};
Changes change_grid(Grid& grid, const Step& step) {
    std::map<int, bool> before;
    for (auto [r,c,v] : step.changes) {
        if (!grid.inside(r,c)) throw std::runtime_error("Change outside grid");
        int cell=r*grid.W+c;
        before.try_emplace(cell,grid.blocked[cell]);
        grid.blocked[cell]=v;
    }
    Changes out;
    for (auto [cell,old] : before) if (old!=bool(grid.blocked[cell])) {
        RC p{cell/grid.W,cell%grid.W};
        (grid.blocked[cell] ? out.blocked : out.opened).push_back(p);
    }
    return out;
}
struct RepairStats {
    uint64_t h_lowered=0,h_raised=0,invalidated=0,bridge_hits=0,certified=0,repair_pops=0;
    uint64_t filtered_cells=0,alternate_parents=0;
    double potential_us=0;
};
struct Chain {
    I cost=INF;
    std::vector<Id> states;
    std::vector<int> edges;
};
void validate_chain(Graph& g, const Chain& p, Id start, Id goal) {
    if (p.cost>=INF) return;
    if (p.states.size()!=p.edges.size()+1 || p.states.front()!=start || p.states.back()!=goal)
        throw std::runtime_error("Chain endpoints");
    I total=0;
    for (size_t i=0;i<p.edges.size();++i) {
        int ei=p.edges[i],r,c,q; g.decode(p.states[i],r,c,q);
        const auto& e=g.m.edges[ei];
        if (e.src!=q || g.head(p.states[i],ei)!=p.states[i+1]) throw std::runtime_error("Chain transition");
        for (auto d:e.trace) if (!g.grid.free(r+d.r,c+d.c)) throw std::runtime_error("Chain collision");
        total+=e.cost;
    }
    if (total!=p.cost) throw std::runtime_error("Chain cost");
}

// Same collision kernel for matched fresh searches and potential-repair methods.
// Epochs invalidate masks lazily; a mask is NEVER reused across map snapshots.
class MeshOracle {
    Graph& g;
    std::unique_ptr<Model> mesh;
    struct Mask {uint64_t epoch=0,bits=0;};
    std::unordered_map<Id,Mask> masks;
    std::vector<int> pid_slot;
    uint64_t epoch=0;
public:
    bool use_mesh;
    struct Group {int heading,dr,dc;uint64_t bits;};
    std::vector<Group> groups;
    MeshOracle(Graph& graph,const std::string& model_path,bool batching):g(graph),use_mesh(batching) {
        if (g.m.Q!=g.m.headings) throw std::runtime_error("Repair engine requires boundary/lattice model");
        std::map<std::tuple<int,int,int>,uint64_t> grouped;
        int maxpid=0;
        for (size_t ei=0;ei<g.m.edges.size();++ei) {
            const auto& e=g.m.edges[ei];
            if (g.m.out[e.src].size()>63) throw std::runtime_error("Primitive mask exceeds 63 bits");
            maxpid=std::max(maxpid,e.pid);
            for (auto d:e.trace) grouped[{e.src,d.r,d.c}]|=uint64_t(1)<<g.m.edge_slot[ei];
        }
        for (auto [key,bits]:grouped) {auto [h,r,c]=key;groups.push_back({h,r,c,bits});}
        pid_slot.assign(maxpid+1,-1);
        for (size_t ei=0;ei<g.m.edges.size();++ei) pid_slot[g.m.edges[ei].pid]=g.m.edge_slot[ei];
        if (use_mesh) {
            auto path=model_path;auto at=path.rfind("_lattice.model");
            if (at==std::string::npos) throw std::runtime_error("Expected lattice model filename");
            path.replace(at,14,"_mesh.model");mesh=std::make_unique<Model>(path);
        }
    }
    void snapshot() {++epoch;}
    uint64_t mask(Id origin) {
        auto& cached=masks[origin];if (cached.epoch==epoch) return cached.bits;
        int r,c,h;g.decode(origin,r,c,h);uint64_t bits=0;
        struct Item {int q,r,c;};std::vector<Item> stack{{h,0,0}};
        while (!stack.empty()) {
            auto u=stack.back();stack.pop_back();++g.st.cell_checks;
            if (!g.grid.free(r+u.r,c+u.c)) continue;
            for (int ei:mesh->out[u.q]) {
                const auto& e=mesh->edges[ei];int nr=u.r+e.dr,nc=u.c+e.dc;
                if (e.pid>=0) {
                    ++g.st.cell_checks;
                    if (g.grid.free(r+nr,c+nc)) bits|=uint64_t(1)<<pid_slot[e.pid];
                } else stack.push_back({e.dst,nr,nc});
            }
        }
        cached={epoch,bits};return bits;
    }
    bool valid(Id tail,int ei) {
        if (!use_mesh) return g.cost(tail,ei)<INF;
        ++g.st.edge_checks;return (mask(tail)&(uint64_t(1)<<g.m.edge_slot[ei]))!=0;
    }
    size_t cache_size() const {return masks.size();}
};

// Sparse, globally consistent lower potential toward the fixed goal.
// Cost increases never require repairing this field. Newly freed swept cells
// seed only downward corrections; a positive-cost reverse Dijkstra closes them.
class Potential {
    Graph& g;MeshOracle& oracle;Id goal;
    std::unordered_map<Id,I> learned;
public:
    Potential(Graph& graph,MeshOracle& o,Id t):g(graph),oracle(o),goal(t) {}
    I base(Id u) const {auto a=g.pos(u),b=g.pos(goal);return g.m.metric(a.r-b.r,a.c-b.c);}
    I get(Id u) const {auto it=learned.find(u);return it==learned.end()?base(u):it->second;}
    size_t size() const {return learned.size();}
    void audit() const {
        if(get(goal)!=0)throw std::runtime_error("Potential(goal) is not zero");
        for(auto [u,hu]:learned) {
            if(hu<base(u))throw std::runtime_error("Learned potential below base");
            int r,c,q;g.decode(u,r,c,q);
            for(int ei:g.m.out[q]) {
                Id v=g.head(u,ei);if(v==NONE)continue;
                bool valid=true;for(auto d:g.m.edges[ei].trace)if(!g.grid.free(r+d.r,c+d.c)){valid=false;break;}
                if(valid && hu>g.m.edges[ei].cost+get(v))
                    throw std::runtime_error("Inconsistent learned potential at "+std::to_string(u));
            }
        }
    }
    void learn(const std::vector<std::pair<Id,I>>& closed,I optimum,RepairStats& st) {
        if (optimum>=INF) return;
        for (auto [u,gu]:closed) {
            I h=optimum-gu,old=get(u);
            if (h<old) throw std::runtime_error("Adaptive potential would decrease during learning");
            if (h>old) {learned[u]=h;++st.h_raised;}
        }
    }
    void repair(const std::vector<RC>& opened,bool grouped,RepairStats& st,
                const std::function<void(Id,Id,int)>& lowered={},
                const std::function<void(Id)>& settled={}) {
        if (learned.empty() || opened.empty()) return;
        using Item=std::pair<I,Id>;
        std::priority_queue<Item,std::vector<Item>,std::greater<Item>> queue;
        auto lower=[&](Id u,I h,Id parent,int edge) {
            auto it=learned.find(u);
            if (it==learned.end() || h>=it->second) return;
            if (h<base(u)) throw std::runtime_error("Potential fell below its consistent base");
            it->second=h;queue.push({h,u});++st.h_lowered;
            if(lowered)lowered(u,parent,edge);
        };
        auto seed=[&](Id u,int ei) {
            auto it=learned.find(u);if (it==learned.end()) return;
            Id v=g.head(u,ei);if (v==NONE) return;
            I h=g.m.edges[ei].cost+get(v);
            if (h<it->second && oracle.valid(u,ei)) lower(u,h,v,ei);
        };
        if (grouped) {
            std::unordered_map<Id,uint64_t> affected;
            for (auto p:opened) for (const auto& d:oracle.groups) {
                ++g.st.notify_probes;int r=p.r-d.dr,c=p.c-d.dc;
                if (!g.grid.inside(r,c)) continue;
                Id u=g.id(r,c,d.heading);
                if (learned.find(u)!=learned.end()) affected[u]|=d.bits;
            }
            std::vector<std::pair<Id,uint64_t>> ordered(affected.begin(),affected.end());
            std::sort(ordered.begin(),ordered.end());
            for (auto [u,bits]:ordered) {
                int q=u%g.m.Q;
                while (bits) {int slot=__builtin_ctzll(bits);bits&=bits-1;seed(u,g.m.out[q][slot]);}
            }
        } else {
            for (auto p:opened) for (auto d:g.m.dep) {
                ++g.st.notify_probes;int r=p.r-d.dr,c=p.c-d.dc;
                if (g.grid.inside(r,c)) seed(g.id(r,c,g.m.edges[d.edge].src),d.edge);
            }
        }
        while (!queue.empty()) {
            auto [h,u]=queue.top();queue.pop();if (h!=get(u)) continue;++st.repair_pops;
            if(settled)settled(u);
            g.pred(u,[&](Id v,int ei) {
                auto it=learned.find(v);if (it==learned.end()) return;
                I candidate=h+g.m.edges[ei].cost;
                if (candidate<it->second && oracle.valid(v,ei)) lower(v,candidate,u,ei);
            });
        }
    }
};

// Exact old-path supports. Changes behind a moving start do not invalidate its
// remaining suffix; every selected edge is rechecked only when its cells change.
class PathCache {
    Graph& g;
    Chain path;
    std::unordered_map<Id,size_t> index;
    std::unordered_map<int,std::vector<int>> supports;
    std::set<int> bad;
    std::vector<I> remaining;
public:
    size_t last_certified_index=0;
    explicit PathCache(Graph& graph):g(graph) {}
    bool empty() const {return path.cost>=INF;}
    void install(const Chain& p) {
        path=p;index.clear();supports.clear();bad.clear();remaining.clear();last_certified_index=0;
        if (empty()) return;
        remaining.assign(p.states.size(),0);
        for (size_t i=0;i<p.states.size();++i) index[p.states[i]]=i;
        for (size_t i=0;i<p.edges.size();++i) {
            int r,c,q;g.decode(p.states[i],r,c,q);
            std::set<int> cells;
            for (auto d:g.m.edges[p.edges[i]].trace) cells.insert((r+d.r)*g.grid.W+c+d.c);
            for (int cell:cells) supports[cell].push_back(i);
        }
        for (size_t i=p.edges.size();i-->0;) remaining[i]=remaining[i+1]+g.m.edges[p.edges[i]].cost;
    }
    void update(const Changes& changes) {
        if (empty()) return;
        std::set<int> dirty;
        auto add=[&](RC p) {auto it=supports.find(p.r*g.grid.W+p.c);if (it!=supports.end())dirty.insert(it->second.begin(),it->second.end());};
        for (auto p:changes.opened)add(p);
        for (auto p:changes.blocked)add(p);
        for (int i:dirty) {if (g.cost(path.states[i],path.edges[i])<INF)bad.erase(i);else bad.insert(i);}
    }
    std::optional<size_t> position(Id u) const {auto it=index.find(u);if (it==index.end())return {};return it->second;}
    bool valid_from(size_t i) const {return bad.empty() || *bad.rbegin()<int(i);}
    I suffix_cost(size_t i) const {return remaining[i];}
    Chain suffix(size_t i) const {
        Chain p;p.cost=remaining[i];p.states.assign(path.states.begin()+i,path.states.end());p.edges.assign(path.edges.begin()+i,path.edges.end());return p;
    }
    struct Anchor {I cost;size_t index;};
    std::unordered_map<Id,Anchor> anchors() const {
        std::unordered_map<Id,Anchor> out;if (empty())return out;
        size_t begin=bad.empty()?0:size_t(*bad.rbegin()+1);
        for (size_t i=begin;i<path.states.size();++i) if(g.free(path.states[i]))out[path.states[i]]={remaining[i],i};
        return out;
    }
};

class ForwardSearch {
    Graph& g;MeshOracle& oracle;
    struct Label {I g=INF;Id parent=NONE;int edge=-1;bool settled=false;};
    std::unordered_map<Id,Label> labels;
public:
    size_t record_count=0;
    bool exhausted=false;
    I settled_distance(Id u)const {
        auto it=labels.find(u);return it!=labels.end()&&it->second.settled?it->second.g:INF;
    }
    std::vector<std::pair<Id,I>> closed;
    ForwardSearch(Graph& graph,MeshOracle& o):g(graph),oracle(o) {labels.reserve(4096);}
    Chain solve(Id start,Id goal,Potential* potential,PathCache* old,RepairStats& stats,bool reverse=false) {
        labels.clear();closed.clear();record_count=0;exhausted=false;
        if (!g.free(start) || !g.free(goal))return {};
        Id root=reverse?goal:start,target=reverse?start:goal;
        auto h=[&](Id u) {if(potential)return potential->get(u);auto a=g.pos(u),b=g.pos(target);return g.m.metric(a.r-b.r,a.c-b.c);};
        auto val=[&](Id u) {auto it=labels.find(u);return it==labels.end()?INF:it->second.g;};
        std::priority_queue<Entry> open;
        labels[root].g=0;open.push({{h(root),0},root,0});++g.st.pushes;
        auto anchors=old?old->anchors():std::unordered_map<Id,PathCache::Anchor>{};
        I upper=INF;Id join=NONE;std::optional<size_t> suffix_index;
        auto candidate=[&](Id u,I gu) {
            if (u==target && gu<upper) {upper=gu;join=u;suffix_index.reset();}
            auto it=anchors.find(u);
            if (it!=anchors.end() && gu+it->second.cost<upper) {
                upper=gu+it->second.cost;join=u;suffix_index=it->second.index;++stats.bridge_hits;
            }
        };
        candidate(root,0);
        while (!open.empty()) {
            auto e=open.top();open.pop();++g.st.pops;
            I gu=val(e.id);if (e.key.second!=-gu)continue;
            if (e.key.first>=upper)break;
            candidate(e.id,gu);
            auto anchor=anchors.find(e.id);
            if (anchor!=anchors.end() && h(e.id)==anchor->second.cost)continue;
            closed.push_back({e.id,gu});++g.st.expanded;
            labels[e.id].settled=true;
            auto relax=[&](Id v,int ei) {
                I ng=gu+g.m.edges[ei].cost;
                if (ng>=val(v))return;
                if (!oracle.valid(reverse?v:e.id,ei))return;
                auto& l=labels[v];l.g=ng;l.parent=e.id;l.edge=ei;l.settled=false;
                open.push({{ng+h(v),-ng},v,0});++g.st.pushes;candidate(v,ng);
            };
            if (reverse)g.pred(e.id,relax);else g.succ(e.id,relax);
        }
        record_count=labels.size();exhausted=upper>=INF&&open.empty();if (upper>=INF)return {};
        Chain result;result.cost=upper;Id u=join;result.states.push_back(u);
        while (u!=root) {
            const auto& l=labels.at(u);result.edges.push_back(l.edge);u=l.parent;result.states.push_back(u);
            if(result.states.size()>labels.size()+1)throw std::runtime_error("Fresh parent cycle");
        }
        if (!reverse) {std::reverse(result.states.begin(),result.states.end());std::reverse(result.edges.begin(),result.edges.end());}
        if (suffix_index) {
            auto tail=old->suffix(*suffix_index);
            result.states.insert(result.states.end(),tail.states.begin()+1,tail.states.end());result.edges.insert(result.edges.end(),tail.edges.begin(),tail.edges.end());
        }
        return result;
    }
};

// Dependency-forest repair rooted at the fixed goal. Increases invalidate only
// parent-dependent descendants. Decreases seed direct relaxations, not rhs scans.
class DependencyForest {
    Graph& g;MeshOracle& oracle;Id root,target;I km=0;
    bool grouped_index,forward;
    bool influence_filter,alternate_parent;
    int tile_rows=0,tile_cols=0;
    std::vector<uint8_t> active_tiles;
    std::vector<std::vector<RC>> tile_offsets;
    struct Node {I g=INF;Id parent=NONE;int edge=-1;uint64_t ver=0,parentver=0;bool pending=false;std::vector<Id> children;};
    struct Watch {Id node;uint64_t parentver;};
    std::unordered_map<Id,Node> nodes;
    std::unordered_map<int,std::vector<Watch>> watch;
    std::priority_queue<Entry> open;
    I distance(Id a,Id b) const {auto x=g.pos(a),y=g.pos(b);return g.m.metric(x.r-y.r,x.c-y.c);}
    Key key(Id u)const {I gu=nodes.at(u).g;return {gu+distance(u,target)+km,-gu};}
    void push(Id u) {auto& n=nodes.at(u);n.pending=true;++n.ver;open.push({key(u),u,n.ver});++g.st.pushes;}
    void activate(Id u) {
        if(!influence_filter)return;
        int r,c,h;g.decode(u,r,c,h);
        for(auto d:tile_offsets[h*256+(r%16)*16+c%16]) {
            int a=r/16+d.r,b=c/16+d.c;
            if(a>=0&&a<tile_rows&&b>=0&&b<tile_cols)active_tiles[a*tile_cols+b]=1;
        }
    }
    bool relevant(RC p)const {return !influence_filter||active_tiles[(p.r/16)*tile_cols+p.c/16];}
    void prepare_influence() {
        tile_rows=(g.grid.H+15)/16;tile_cols=(g.grid.W+15)/16;
        active_tiles.assign(tile_rows*tile_cols,0);tile_offsets.resize(g.m.headings*256);
        auto floor16=[](int x){return x>=0?x/16:-((15-x)/16);};
        for(int h=0;h<g.m.headings;++h) {
            std::set<std::pair<int,int>> support;
            for(int ei:(forward?g.m.out[h]:g.m.in[h])) {
                const auto& e=g.m.edges[ei];
                for(auto d:e.trace)support.emplace(d.r-(forward?0:e.dr),d.c-(forward?0:e.dc));
            }
            for(int r=0;r<16;++r)for(int c=0;c<16;++c) {
                std::set<std::pair<int,int>> tiles;
                for(auto [a,b]:support)tiles.emplace(floor16(r+a),floor16(c+b));
                for(auto [a,b]:tiles)tile_offsets[h*256+r*16+c].push_back({a,b});
            }
        }
    }
    void link_parent(Id u,Id parent,int ei) {
        auto& n=nodes.at(u);
        if(n.parent!=parent || n.edge!=ei) {
            n.parent=parent;n.edge=ei;++n.parentver;nodes[parent].children.push_back(u);
            if(!grouped_index) {
                int r,c,q;g.decode(forward?parent:u,r,c,q);std::set<int> cells;
                for(auto d:g.m.edges[ei].trace)cells.insert((r+d.r)*g.grid.W+c+d.c);
                for(int cell:cells)watch[cell].push_back({u,n.parentver});
            }
        }
    }
    void relax(Id u,Id parent,int ei) {
        I candidate=value(parent)+g.m.edges[ei].cost;if (candidate>=value(u))return;
        auto& n=nodes[u];bool newly_finite=n.g>=INF;n.g=candidate;
        link_parent(u,parent,ei);if(newly_finite)activate(u);push(u);
    }
    bool reparent(Id u,RepairStats& stats) {
        bool found=false;I old=value(u);
        auto try_parent=[&](Id p,int ei) {
            if(found||value(p)>=INF||value(p)+g.m.edges[ei].cost>old)return;
            if(!oracle.valid(forward?p:u,ei))return;
            auto& n=nodes.at(u);bool changed=n.parent!=p||n.edge!=ei;
            if(value(p)+g.m.edges[ei].cost<old)relax(u,p,ei);else link_parent(u,p,ei);
            if(changed)++stats.alternate_parents;
            found=true;
        };
        if(forward)g.pred(u,try_parent);else g.succ(u,try_parent);
        return found;
    }
    void clean() {
        while(!open.empty()) {const auto& e=open.top();auto it=nodes.find(e.id);
            if(it!=nodes.end() && it->second.pending && it->second.ver==e.ver && it->second.g<INF)break;
            open.pop();++g.st.pops;
        }
    }
public:
    DependencyForest(Graph& graph,MeshOracle& o,Id start,Id goal,bool grouped,bool from_start=false,bool filter=false,bool alternate=false):g(graph),oracle(o),root(from_start?start:goal),target(from_start?goal:start),grouped_index(grouped),forward(from_start),influence_filter(filter),alternate_parent(alternate) {
        if(influence_filter)prepare_influence();
        nodes[root].g=0;activate(root);push(root);
    }
    I value(Id u)const {auto it=nodes.find(u);return it==nodes.end()?INF:it->second.g;}
    size_t size()const{return nodes.size();}
    void audit() const {
        for(const auto& [u,n]:nodes)if(u!=root && n.g<INF) {
            if(n.parent==NONE || value(n.parent)>=INF || n.g<value(n.parent)+g.m.edges[n.edge].cost)
                throw std::runtime_error("Invalid dependency-forest label");
            int r,c,q;g.decode(forward?n.parent:u,r,c,q);
            for(auto d:g.m.edges[n.edge].trace)if(!g.grid.free(r+d.r,c+d.c))
                throw std::runtime_error("Invalid dependency-forest edge");
        }
    }
    void move(Id next) {
        if(forward) {
            if(next!=root) {nodes.clear();watch.clear();open={};km=0;root=next;nodes[root].g=0;
                if(influence_filter)std::fill(active_tiles.begin(),active_tiles.end(),0);
                activate(root);push(root);}
        } else if(next!=target){km+=distance(target,next);target=next;}
    }
    void repair_changes(const Changes& changes,RepairStats& st) {
        std::vector<Id> invalid;
        for(auto p:changes.blocked) {
            if(!relevant(p)){++st.filtered_cells;continue;}
            if(grouped_index) {
                for(const auto& d:oracle.groups) {
                    ++g.st.notify_probes;int r=p.r-d.dr,c=p.c-d.dc;
                    if(!g.grid.inside(r,c))continue;
                    Id u=g.id(r,c,d.heading);
                    if(forward) {
                        uint64_t bits=d.bits;
                        while(bits) {
                            int slot=__builtin_ctzll(bits);bits&=bits-1;int ei=g.m.out[d.heading][slot];
                            Id v=g.head(u,ei);if(v==NONE)continue;auto n=nodes.find(v);
                            if(n!=nodes.end() && n->second.g<INF && n->second.parent==u && n->second.edge==ei)invalid.push_back(v);
                        }
                    } else {
                        auto n=nodes.find(u);
                        if(n!=nodes.end() && n->second.g<INF && n->second.edge>=0 &&
                           (d.bits&(uint64_t(1)<<g.m.edge_slot[n->second.edge])))invalid.push_back(u);
                    }
                }
                continue;
            }
            auto it=watch.find(p.r*g.grid.W+p.c);if(it==watch.end())continue;
            for(auto w:it->second) {
                auto n=nodes.find(w.node);
                if(n!=nodes.end() && n->second.g<INF && n->second.parentver==w.parentver)invalid.push_back(w.node);
            }
        }
        for(size_t i=0;i<invalid.size();++i) {
            Id u=invalid[i];auto& n=nodes.at(u);if(n.g>=INF || u==root)continue;
            if(alternate_parent&&reparent(u,st))continue;
            n.g=INF;n.pending=false;++n.ver;++n.parentver;++st.invalidated;
            for(Id child:n.children) {auto it=nodes.find(child);if(it!=nodes.end() && it->second.g<INF && it->second.parent==u)invalid.push_back(child);}
            n.parent=NONE;n.edge=-1;n.children.clear();
        }
        std::sort(invalid.begin(),invalid.end());invalid.erase(std::unique(invalid.begin(),invalid.end()),invalid.end());
        // Every still-valid successor offers a boundary seed into the invalid region.
        auto improve=[&](Id u,Id v,int ei) {
            if(value(v)<INF && value(v)+g.m.edges[ei].cost<value(u) && oracle.valid(forward?v:u,ei))relax(u,v,ei);
        };
        for(Id u:invalid)if(value(u)>=INF) {
            if(forward)g.pred(u,[&](Id v,int ei){improve(u,v,ei);});
            else g.succ(u,[&](Id v,int ei){improve(u,v,ei);});
        }
        if(grouped_index) {
            std::unordered_map<Id,uint64_t> affected;
            for(auto p:changes.opened) {
                if(!relevant(p)){++st.filtered_cells;continue;}
                for(const auto& d:oracle.groups) {
                    ++g.st.notify_probes;int r=p.r-d.dr,c=p.c-d.dc;
                    if(g.grid.inside(r,c))affected[g.id(r,c,d.heading)]|=d.bits;
                }
            }
            std::vector<std::pair<Id,uint64_t>> ordered(affected.begin(),affected.end());
            std::sort(ordered.begin(),ordered.end());
            for(auto [u,bits]:ordered)while(bits) {
                int slot=__builtin_ctzll(bits);bits&=bits-1;int ei=g.m.out[u%g.m.Q][slot];
                Id v=g.head(u,ei);if(v!=NONE){if(forward)improve(v,u,ei);else improve(u,v,ei);}
            }
        } else for(auto p:changes.opened)for(auto d:g.m.dep) {
            ++g.st.notify_probes;int r=p.r-d.dr,c=p.c-d.dc;if(!g.grid.inside(r,c))continue;
            Id u=g.id(r,c,g.m.edges[d.edge].src),v=g.head(u,d.edge);
            if(v!=NONE){if(forward)improve(v,u,d.edge);else improve(u,v,d.edge);}
        }
    }
    Chain solve() {
        if(!g.free(root)||!g.free(target))return {};
        clean();
        while(!open.empty()) {
            if(open.top().key.first>=value(target)+km)break;
            auto e=open.top();open.pop();++g.st.pops;
            if(e.key<key(e.id)){push(e.id);clean();continue;}
            auto& n=nodes.at(e.id);n.pending=false;++g.st.expanded;
            auto step=[&](Id u,int ei){
                if(value(e.id)+g.m.edges[ei].cost<value(u) && oracle.valid(forward?e.id:u,ei))relax(u,e.id,ei);
            };
            if(forward)g.succ(e.id,step);else g.pred(e.id,step);
            clean();
        }
        if(value(target)>=INF)return {};
        Chain p;p.cost=value(target);Id u=target;p.states.push_back(u);
        while(u!=root) {
            const auto& n=nodes.at(u);if(n.parent==NONE)throw std::runtime_error("Forest parent missing");
            p.edges.push_back(n.edge);u=n.parent;p.states.push_back(u);
            if(p.states.size()>nodes.size()+1)throw std::runtime_error("Forest parent cycle");
        }
        if(forward){std::reverse(p.states.begin(),p.states.end());std::reverse(p.edges.begin(),p.edges.end());}
        return p;
    }
};

class RepairPlanner {
    Graph& g;MeshOracle& oracle;std::string method;Id goal;
    Potential potential;
    ForwardSearch search;
    PathCache cache;
    std::unique_ptr<DependencyForest> forest;
    std::set<int> deferred_open;
    bool no_path=false;Id no_path_start=NONE;
    I gate_alpha;
    I units(int r,int c)const {I a=std::abs(r),b=std::abs(c);return 1000*std::max(a,b)+414*std::min(a,b);}
    I cell_bound(Id start,RC p)const {auto s=g.pos(start),t=g.pos(goal);return gate_alpha*(units(s.r-p.r,s.c-p.c)+units(t.r-p.r,t.c-p.c));}
public:
    size_t records=0;
    RepairPlanner(Graph& graph,MeshOracle& o,const std::string& algorithm,Id start,Id t):g(graph),oracle(o),method(algorithm),goal(t),potential(g,o,t),search(g,o),cache(g) {
        gate_alpha=g.m.alpha;
        for(const auto& e:g.m.edges)for(auto d:e.trace) {
            I denom=units(d.r,d.c)+units(e.dr-d.r,e.dc-d.c);
            if(denom)gate_alpha=std::min(gate_alpha,e.cost/denom);
        }
        if(method=="forest"||method=="mdf"||method=="mfr"||method=="mir"||method=="mir-forward"||method=="mir-filter"||method=="mdf-rp")
            forest=std::make_unique<DependencyForest>(g,o,start,t,method!="forest",method=="mfr"||method=="mir-forward",
                 method=="mir"||method=="mir-forward"||method=="mir-filter",method=="mir"||method=="mir-forward"||method=="mdf-rp");
    }
    Chain solve(Id start,const Changes& changes,RepairStats& stats) {
        oracle.snapshot();
        if(forest){forest->move(start);forest->repair_changes(changes,stats);auto p=forest->solve();if(verify_repair_invariants)forest->audit();records=forest->size();return p;}
        bool learned=method=="gaa"||method=="gaa-plain"||method=="msp"||method=="csb"||method=="bridge-eager";
        bool bridge=method=="csb"||method=="bridge-eager";
        bool defer=method=="csb";
        if(!learned){auto p=search.solve(start,goal,nullptr,nullptr,stats,method=="fresh-backward");records=search.record_count;return p;}
        if(bridge)cache.update(changes);
        for(auto q:changes.opened)deferred_open.insert(q.r*g.grid.W+q.c);
        for(auto q:changes.blocked)deferred_open.erase(q.r*g.grid.W+q.c);
        auto pos=cache.position(start);
        if(defer && no_path && start==no_path_start && changes.opened.empty()) {stats.certified=1;return {};}
        if(defer && pos && *pos>=cache.last_certified_index && cache.valid_from(*pos) && g.free(start)&&g.free(goal)) {
            I upper=cache.suffix_cost(*pos);bool safe=true;
            for(auto q:changes.opened)if(cell_bound(start,q)<upper){safe=false;break;}
            if(safe){stats.certified=1;cache.last_certified_index=*pos;return cache.suffix(*pos);}
        }
        std::vector<RC> opened;
        for(int cell:deferred_open)if(!g.grid.blocked[cell])opened.push_back({cell/g.grid.W,cell%g.grid.W});
        auto repair_begin=Clock::now();
        potential.repair(opened,method!="gaa"&&method!="gaa-plain",stats);deferred_open.clear();
        stats.potential_us=std::chrono::duration<double,std::micro>(Clock::now()-repair_begin).count();
        if(verify_repair_invariants)potential.audit();
        if(bridge && pos && cache.valid_from(*pos) && g.free(start)&&g.free(goal) && potential.get(start)==cache.suffix_cost(*pos)) {
            stats.certified=1;cache.last_certified_index=*pos;return cache.suffix(*pos);
        }
        auto p=search.solve(start,goal,&potential,bridge?&cache:nullptr,stats);
        potential.learn(search.closed,p.cost,stats);records=potential.size()+search.record_count;
        if(verify_repair_invariants)potential.audit();
        if(bridge){cache.install(p);no_path=p.cost>=INF;no_path_start=start;}
        return p;
    }
};

void run_repair(const std::string& model,const std::string& workload,const std::string& method,bool dump) {
    auto setup0=Clock::now();Model m(model);auto w=load_workload(workload);Grid grid(w.map);Graph graph(m,grid);
    bool batched=method=="fresh-mesh"||method=="gaa"||method=="msp"||method=="csb"||method=="bridge-eager";
    MeshOracle oracle(graph,model,batched);Id goal=graph.id(w.goal);
    RepairPlanner planner(graph,oracle,method,graph.id(w.start),goal);
    double setup=std::chrono::duration<double,std::micro>(Clock::now()-setup0).count();
    std::cout<<"episode,cost,total_us,expanded,edge_checks,cell_checks,pushes,pops,notify_probes,h_lowered,h_raised,invalidated,bridge_hits,certified,records,cache_origins,previous_suffix_valid,previous_suffix_cost,changes,setup_us,rss_kib,repair_pops,potential_us,filtered_cells,alternate_parents\n";
    Chain previous;
    for(size_t ep=0;ep<w.steps.size();++ep) {
        graph.st={};RepairStats stats;auto begin=Clock::now();auto changes=change_grid(grid,w.steps[ep]);Id start=graph.id(w.steps[ep].start);
        auto p=planner.solve(start,changes,stats);auto end=Clock::now();
        validate_chain(graph,p,start,goal);
        int old_valid=-1;I old_cost=-1;
        auto at=std::find(previous.states.begin(),previous.states.end(),start);
        if(previous.cost<INF && at!=previous.states.end()) {
            size_t j=at-previous.states.begin();old_valid=1;old_cost=0;
            for(size_t i=j;i<previous.edges.size();++i) {
                int r,c,q;graph.decode(previous.states[i],r,c,q);const auto& e=m.edges[previous.edges[i]];old_cost+=e.cost;
                for(auto d:e.trace)if(!grid.free(r+d.r,c+d.c))old_valid=0;
            }
        }
        struct rusage usage{};getrusage(RUSAGE_SELF,&usage);const auto& s=graph.st;
        std::cout<<ep<<','<<(p.cost>=INF?-1:p.cost)<<','<<std::chrono::duration<double,std::micro>(end-begin).count()<<','
                 <<s.expanded<<','<<s.edge_checks<<','<<s.cell_checks<<','<<s.pushes<<','<<s.pops<<','<<s.notify_probes<<','
                 <<stats.h_lowered<<','<<stats.h_raised<<','<<stats.invalidated<<','<<stats.bridge_hits<<','<<stats.certified<<','
                 <<planner.records<<','<<oracle.cache_size()<<','<<old_valid<<','<<old_cost<<','<<changes.opened.size()+changes.blocked.size()<<','
                 <<(ep==0?setup:0)<<','<<usage.ru_maxrss<<','<<stats.repair_pops<<','<<stats.potential_us<<','<<stats.filtered_cells<<','<<stats.alternate_parents<<'\n';
        if(dump){std::cerr<<"PATH "<<ep;for(int ei:p.edges)std::cerr<<' '<<m.edges[ei].pid;std::cerr<<'\n';}
        previous=std::move(p);
    }
}
#ifndef REPAIR_LIBRARY
int main(int argc,char** argv) {
    try {
        std::unordered_map<std::string,std::string> args;
        for(int i=1;i<argc;++i){std::string k=argv[i];if(k=="--dump"||k=="--audit")args[k]="1";else{if(i+1>=argc)throw std::runtime_error("Missing option");args[k]=argv[++i];}}
        verify_repair_invariants=args.count("--audit");
        std::string method=args.count("--algorithm")?args.at("--algorithm"):"csb";
        const std::set<std::string> valid={"fresh","fresh-mesh","fresh-backward","gaa","gaa-plain","msp","csb","bridge-eager","forest","mdf","mfr","mir","mir-forward","mir-filter","mdf-rp"};
        if(!valid.count(method))throw std::runtime_error("Unknown repair method");
        run_repair(args.at("--model"),args.at("--workload"),method,args.count("--dump"));return 0;
    }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
#endif
