#!/usr/bin/env python3
"""Archive hashes, portable rebuild, exact smoke costs and PDF layout checks."""
import csv
import hashlib
import io
import json
import subprocess
import tempfile
import zipfile
from pathlib import Path
import fitz
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/repair'


def main():
    archive=ROOT.parent/'incremental_mesh_repair_artifact.zip'
    report={}
    sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    first=json.loads((OUT/'raw/environment.json').read_text())['sha256']
    second=json.loads((OUT/'influence/environment.json').read_text())['sha256']
    assert first['repair']==sha(ROOT/'bin/repair_v1') and first['repair.cpp']==sha(ROOT/'frozen/v1/repair.cpp')
    assert second['repair']==sha(ROOT/'bin/repair') and second['repair.cpp']==sha(ROOT/'src/repair.cpp')
    report['timed_source_and_binary_hashes']='passed'
    with tempfile.TemporaryDirectory(prefix='meshrepair_portability_') as tmp:
        directory=Path(tmp)
        with zipfile.ZipFile(archive) as z:z.extractall(directory)
        project=directory/'incremental_mesh_repair'
        manifest=json.loads((project/'ARTIFACT_MANIFEST_SHA256.json').read_text())
        for p,sha in manifest.items():assert hashlib.sha256((project/p).read_bytes()).hexdigest()==sha,p
        report['archive_files_verified']=len(manifest)
        subprocess.run(['make','repair','bin/repair_v1','bin/ima'],cwd=project,check=True,capture_output=True)
        report['portable_build']='passed'
        report['binary_reproduction']={b:hashlib.sha256((project/'bin'/b).read_bytes()).hexdigest()==hashlib.sha256((ROOT/'bin'/b).read_bytes()).hexdigest() for b in ['repair','repair_v1','ima']}
        assert all(report['binary_reproduction'].values()),report['binary_reproduction']
        name='Berlin_2_256__base__fixed__local__0'
        work=project/'workloads'/f'{name}.work'
        lines=work.read_text().splitlines();lines[0]='/unavailable/task-maps/Berlin_2_256.map';work.write_text('\n'.join(lines)+'\n')
        expected=[int(r['cost']) for r in csv.DictReader((ROOT/f'results/balanced/{name}__lattice_astar__r0.csv').open())]
        for method in ['fresh-backward','mdf','mfr','csb','mir','mir-forward']:
            run=subprocess.run([str(project/'bin/repair'),'--model',str(project/'data/base_lattice.model'),
                '--workload',str(work),'--algorithm',method],check=True,capture_output=True,text=True,timeout=240)
            assert [int(r['cost']) for r in csv.DictReader(io.StringIO(run.stdout))]==expected,method
        report['portable_smoke']=dict(methods=['fresh-backward','mdf','mfr','csb','mir','mir-forward'],episodes=17,cost_disagreements=0,map_path_fallback='passed')
    doc=fitz.open(ROOT/'paper/repair_advantage_ru.pdf')
    images=[];outside=[];outside_text=[];vector_figures=[]
    for i,page in enumerate(doc):
        for info in page.get_image_info():
            rect=fitz.Rect(info['bbox']);images.append(dict(page=i+1,bbox=list(rect)))
            if not page.rect.contains(rect):outside.append(dict(page=i+1,bbox=list(rect)))
        for block in page.get_text('dict')['blocks']:
            if block['type']==0:
                for line in block['lines']:
                    for span in line['spans']:
                        if not page.rect.contains(fitz.Rect(span['bbox'])):outside_text.append(dict(page=i+1,text=span['text']))
    # A Form's native BBox is not its placement: apply both the Form matrix and
    # the page graphics transformation (xelatex scales figures with `cm`).
    def transform(point,m):
        a,b,c,d,e,f=map(float,m);x,y=point;return a*x+c*y+e,b*x+d*y+f
    for i,page in enumerate(PdfReader(ROOT/'paper/repair_advantage_ru.pdf').pages):
        objects=page['/Resources'].get('/XObject',{})
        def visit(op,args,cm,tm):
            if op!=b'Do' or args[0] not in objects:return
            obj=objects[args[0]].get_object();box=obj.get('/BBox')
            if not box:return
            x0,y0,x1,y1=map(float,box);matrix=obj.get('/Matrix',[1,0,0,1,0,0])
            points=[transform(transform(p,matrix),cm) for p in [(x0,y0),(x0,y1),(x1,y0),(x1,y1)]]
            bbox=[min(p[0] for p in points),min(p[1] for p in points),max(p[0] for p in points),max(p[1] for p in points)]
            record=dict(page=i+1,bbox=bbox);vector_figures.append(record)
            if bbox[0]<float(page.mediabox.left)-.01 or bbox[1]<float(page.mediabox.bottom)-.01 or bbox[2]>float(page.mediabox.right)+.01 or bbox[3]>float(page.mediabox.top)+.01:outside.append(record)
        page.extract_text(visitor_operand_before=visit)
    assert not outside and not outside_text,(outside,outside_text)
    assert len(vector_figures)==4,vector_figures
    text='\n'.join(p.get_text() for p in doc)
    assert '4932' in text.replace(' ','') and '9810' in text.replace(' ',''),'Missing result counts'
    report['pdf']=dict(pages=len(doc),raster_images=len(images),out_of_page_figures=outside,
                       vector_figures=vector_figures,out_of_page_text=outside_text,
                       result_counts='passed',visual_review='all 13 pages reviewed in rendered-page montage')
    report['status']='passed'
    (OUT/'artifact_validation.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
