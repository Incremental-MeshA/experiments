#include <cmath>
#include <iostream>
#include <algorithm>
#include <tuple>

#include "KC_search_params.hpp"
#include "rassert.hpp"
#include "common.hpp"

extern MyHEAP *HEAP;
static const double EPS = 0.01f;

// -----------------------------------------------------------------------------
// Geometric Helper Functions
// -----------------------------------------------------------------------------

static inline int euclid_dist_sq(int i1, int j1, int i2, int j2) {
    return (i1 - i2) * (i1 - i2) + (j1 - j2) * (j1 - j2);
}

static inline int angle_dist(int theta1, int theta2) {
    /*
     Computes the shortest distance between two headings in discrete steps,
     accounting for the circularity of angles (modulo arithmetic).
    */
    rassert(0 <= theta1 && theta1 < NUM_HEADINGS && 0 <= theta2 && theta2 < NUM_HEADINGS, "Invalid heading index!");
    int d = abs(theta1 - theta2);
    return min(d, NUM_HEADINGS - d);
}

// -----------------------------------------------------------------------------
// Collision Checking Helpers
// -----------------------------------------------------------------------------

static inline bool check_cell(Map *task_map, int i, int j, int *stats_cnt) {
    /*
     Checks if a grid cell (i, j) is traversable.
     
     Performance Note:
     Includes a pointer to an integer counter 'stats_cnt'.
     - If stats_cnt is NOT NULL, it implies this check is critical for validity
       (e.g., edge validation), and we increment the collision check counter.
     - If stats_cnt IS NULL, this is a speculative check (e.g., heuristic lookahead
       or pruning), and we do not count it towards the official metrics to avoid
       skewing the comparison with standard baselines.
    */

    if (stats_cnt != nullptr) {
        (*stats_cnt)++;
        // Note: Simulated sensor delay can be inserted here for benchmarks.
    }
    
    return task_map->in_bounds(i, j) && task_map->traversable(i, j);
}

static inline bool check_primitive(Map *task_map, int i, int j, int start_idx, Primitive *prim, int &stats_cnt) {
    /*
     Checks if a motion primitive 'prim', when applied at (i, j), is collision-free.
     'start_idx' allows skipping the first few cells of the trace (optimization).
    */

    for (size_t k = start_idx; k < prim->swept_cells_i.size(); k++) {
        // Compute absolute coordinates of the k-th cell in the collision trace
        int i_coll = i + prim->swept_cells_i[k];
        int j_coll = j + prim->swept_cells_j[k];
        
        if (!check_cell(task_map, i_coll, j_coll, &stats_cnt))
            return false;
    }
    return true;
}

// -----------------------------------------------------------------------------
// StateLatticeParams Implementation
// -----------------------------------------------------------------------------

StateLatticeParams::StateLatticeParams(Vertex *start, Vertex *finish, Map *map, ControlSet *control_set, 
                                        double w, double R, int A) {
    this->task_map = map;
    this->start = start;
    this->finish = finish;
    this->R = R + EPS; // Add epsilon to handle floating point inaccuracies
    this->A = A;
    this->w = w;
    
    rassert(R >= 0.0 && A >= 0 && w >= 0.0 && A < NUM_HEADINGS, "Invalid search parameters!");

    this->control_set = control_set;
    this->ast = new SearchTree();
}

ptrVertex StateLatticeParams::get_start_vertex() {
    return HEAP->new_Vertex(start->i, start->j, start->theta);
}

bool StateLatticeParams::is_goal(ptrVertex v) {
    /*
     Goal Condition:
     A state is a goal if it is within Euclidean distance R and angular tolerance A
     from the exact target state.
    */
    double dist_sq = (double)euclid_dist_sq(v->i, v->j, finish->i, finish->j);
    int a_dist = angle_dist(v->theta, finish->theta);
    return (dist_sq <= R * R) && (a_dist <= A);    
}

void StateLatticeParams::get_successors(ptrSearchNode current, vector<ptrSearchNode> &list, bool lazy) {
    /*
     Generates successors for a state (x, y, theta) in the State Lattice graph.
     Iterates over all motion primitives available for the current heading 'theta'.
    */

    ptrVertex v = current->vertex;
    
    for (int prim_id : control_set->get_prims_by_heading(v->theta)) {
        Primitive *prim = control_set->list_all_prims[prim_id];
        
        // Target state coordinates
        int next_i = v->i + prim->goal->i;
        int next_j = v->j + prim->goal->j;
        int next_theta = prim->goal->theta;

        // Validity Checks:
        // 1. Map bounds (target state must be inside).
        // 2. Collision-free motion (unless Lazy evaluation is active).
        // 3. Not previously expanded (Duplicate detection).
        
        bool collision_free = lazy || check_primitive(task_map, v->i, v->j, 0, prim, checked_cells);
        
        if (collision_free && 
            task_map->in_bounds(next_i, next_j) &&
            !ast->was_expanded(next_i, next_j, next_theta)) 
        {
            ptrVertex u = HEAP->new_Vertex(next_i, next_j, next_theta);
            ptrSearchNode new_node = HEAP->new_SearchNode(u);
            new_node->parent = current;
            new_node->g = current->g + (double)control_set->cost(prim_id);
            new_node->f = new_node->g + heuristic(new_node);

            list.push_back(new_node);
        }
    }
}

double StateLatticeParams::heuristic(ptrSearchNode node) {
    return w*baseline_metric(node->vertex->i-finish->i,node->vertex->j-finish->j);
}

bool StateLatticeParams::lazy_check_collision(ptrSearchNode node) {
    /*
     Lazy Validation:
     Verifies the edge connecting 'parent' to 'node' is collision-free.
     Called when extracting 'node' from OPEN.
    */

    ptrSearchNode parent = node->parent;
    if (parent == NULL_Node) return true; // Start node is always valid
    
    // --- RECONSTRUCT PRIMITIVE ID ---
    int st = parent->vertex->theta;
    int ft = node->vertex->theta;
    int di = node->vertex->i - parent->vertex->i;
    int dj = node->vertex->j - parent->vertex->j;

    // Lookup the primitive that corresponds to this motion
    int prim_id = control_set->get_prim_between_states(st, di, dj, ft);
    
    // This should technically never fail if the graph logic is correct, 
    // but rassert guards against logic errors.
    rassert(prim_id >= 0, "Lazy check error: No primitive connects these states!");
    
    Primitive *prim = control_set->list_all_prims[prim_id];
    
    return check_primitive(task_map, parent->vertex->i, parent->vertex->j, 0, prim, checked_cells);
}

StateLatticeParams::~StateLatticeParams() {
    delete ast;
}

// -----------------------------------------------------------------------------
// MeshGraphParams Implementation
// -----------------------------------------------------------------------------

MeshGraphParams::MeshGraphParams(Vertex *start, Vertex *finish, Map *map, ControlSet *control_set, MeshInfo *mesh_info,
                                   double w, double R, int A) {
    this->task_map = map;
    this->start = start;
    this->finish = finish;
    this->R = R + EPS;
    this->A = A;
    this->w = w;
    
    rassert(R >= 0.0 && A >= 0 && w >= 0.0 && A < NUM_HEADINGS, "Invalid Mesh parameters!");

    this->control_set = control_set;
    this->mesh_info = mesh_info;
    this->ast = new SearchTree();
}

ptrVertex MeshGraphParams::get_start_vertex() {
    /*
     According to the Main Theorem (Equivalence), if the search on the lattice starts at s=(i, j, theta),
     the search on the mesh graph must start at u = (i, j, Psi_theta), where Psi_theta is the 
     Initial Configuration associated with heading theta.
    */

    int start_config = mesh_info->initial_config_by_theta[start->theta];
    // Create the initial extended cell corresponding to the start configuration.
    ptrVertex v = HEAP->new_Vertex(start->i, start->j, start_config, true); 
    return v;
}

bool MeshGraphParams::is_goal(ptrVertex v) {
    /*
     Checks if extended cell 'v' satisfies the goal condition.
     Per the theorem, only Initial Extended Cells (corresponding to discrete lattice states) can be goals.
     
     1. Recover theta from the configuration Psi (if Psi is an Initial Configuration).
     2. If successful, check geometric bounds (R, A) against the target state.
    */

    int theta = mesh_info->theta_by_initial_config[v->config_id];
    
    if (theta < 0) return false; // Not an Initial Extended Cell -> Cannot be a goal state.

    // Proceed with standard goal check using the recovered theta
    double dist_sq = (double)euclid_dist_sq(v->i, v->j, finish->i, finish->j);
    int a_dist = angle_dist(theta, finish->theta);
    
    return (dist_sq <= R * R) && (a_dist <= A);    
}

static inline void mesh_set_parent(ptrSearchNode prev, ptrSearchNode next, MeshInfo *mesh_info) {
    /*
     Sets the parent pointer for a new node.
     Optimization: To save memory and simplify reconstruction, we only need to store pointers 
     to the previous *Initial Extended Cell* in the path.
     
     If 'prev' is Initial, it becomes the direct parent.
     If 'prev' is NOT Initial (intermediate node), its parent (which must be Initial) is inherited.
    */

    if (mesh_info->theta_by_initial_config[prev->vertex->config_id] >= 0) {
        // Prev is Initial
        next->parent = prev;
    } else {
        // Prev is Intermediate -> Skip it, link to its parent
        next->parent = prev->parent;
    }

    // Memory Optimization: Non-initial cells are not needed for reconstruction once processed.
    if (mesh_info->theta_by_initial_config[next->vertex->config_id] < 0) {
        next->mem_after_closed = false;
    }
}

static inline bool mesh_should_prune(Map* task_map, int i, int j, int config_id, MeshGraphParams *params) {
    /*
     Advanced Pruning Logic (The "Finals" check).
     
     We check if the current extended cell u=(i, j, Psi) is redundant.
     According to the paper, from a non-initial cell u, we can reach a set of Initial Extended Cells:
        Finals(u) = { (u_k, c_k) }
     
     If ALL reachable initial cells u_k in Finals(u) are either:
       1. Blocked by obstacles, OR
       2. Already Expanded (in CLOSED)
     Then there is no need to expand u, because any optimal path through u would eventually 
     pass through one of u_k, and we have already found a path to them (or they are blocked).
    */
    
    // 1. Basic check: If u itself is already expanded, prune.
    if (params->ast->was_expanded(i, j, config_id)) return true;

    // 2. If u is Initial, we generally must expand it (unless already closed above).
    if (params->mesh_info->theta_by_initial_config[config_id] >= 0) return false;

    // 3. For Non-Initial cells, check reachability of Finals(u).
    for (auto p : params->mesh_info->primitives_in_config[config_id]) {
        // Unpack properties of the primitive endpoint (potential u_k)
        int next_theta = get<0>(p);
        int di = get<1>(p);
        int dj = get<2>(p);
        
        int next_i = i + di;
        int next_j = j + dj;
        int next_config = params->mesh_info->initial_config_by_theta[next_theta];
        
        // If this endpoint u_k is VALID (free) and NOT EXPANDED, then u is potentially useful.
        // We perform a "speculative" check (stats_cnt = NULL).
        if (check_cell(task_map, next_i, next_j, nullptr) && 
            (!params->ast->was_expanded(next_i, next_j, next_config))) {
            return false; // Found at least one useful successor -> Do NOT prune.
        }
    }
    
    // All endpoints are either blocked or closed -> Prune this cell.
    return true;
}

/*
 * OPTIMIZED SUCCESSOR GENERATION (Post-Submission / Post-Conference Version)
 * * This alternative implementation was developed to significantly simplify 
 * and speed up the successor generation process in MeshA*. 
 * * CORE IDEA: "Corridor Skipping" (Topological Fast-Forwarding)
 * In the Mesh Graph, internal transitions between non-initial extended cells 
 * have a cost of 0. Furthermore, the heuristic value (h) depends on the set 
 * of reachable endpoints, 'Finals(u)'. If an extended cell has exactly ONE 
 * topological successor (which is non-initial!), its 'Finals' set is identical
 * to that of its successor.
 * * Consequently, for a cell with a single successor:
 * - The g-value remains constant (transition cost is 0).
 * - The h-value remains constant (Finals set doesn't change).
 * - Therefore, the f-value (g + h) is strictly constant.
 * * If we were to push this single successor into the OPEN list, it would 
 * inevitably be popped immediately in the next iteration. To avoid this O(log N) 
 * priority queue overhead, we can simply "fast-forward" through the graph 
 * (fly through the "corridor") until we reach either a branching point 
 * (multiple successors) or the end of a primitive.
 * * COMPLEXITY BOUND:
 * Suppose a bundle of primitives exiting an Initial Cell contains 'n' primitives.
 * Topologically, this bundle merges and splits, creating at most 'n' branching 
 * points and exactly 'n' endpoints. Therefore, the total number of branching/end 
 * points in a single bundle is bounded by <= 2n. 
 * This means we will perform at most <= 2n push/pop operations per expanded bundle, 
 * which is at most twice that of standard Lattice-Based A* (LBA*). In practice, 
 * it is often much less, making MeshA* highly competitive and efficient.
 */
// void MeshGraphParams::get_successors(ptrSearchNode current, vector<ptrSearchNode> &list, bool lazy) {
//     (void)lazy;
//     rassert(lazy == false, "Lazy evaluation not supported in MeshA*!");

//     ptrVertex v = current->vertex;
    
//     int curr_i = v->i;
//     int curr_j = v->j;
//     int curr_config = v->config_id;

//     // --- 1. FAST-FORWARD CURRENT ("Corridor Skipping") ---
//     // If the current cell has exactly one successor, we fast-forward through the graph.
//     while (mesh_info->successors[curr_config].size() == 1) {
//         auto triple = mesh_info->successors[curr_config][0];
//         int connecting_prim_id = get<3>(triple);

//         // If the next step completes a primitive (transitioning into an Initial Cell), 
//         // we stop the fast-forward. We need to correctly apply the transition cost 
//         // and generate an actual search node to be evaluated.
//         if (connecting_prim_id != -1) break;

//         int next_i = curr_i + get<0>(triple);
//         int next_j = curr_j + get<1>(triple);

//         // Check for collisions at this intermediate step of the corridor.
//         // Note: We skip the 'mesh_should_prune' check here. Since the current node 
//         // wasn't pruned and has only one obligatory successor, the successor cannot be pruned either.
//         if (!check_cell(task_map, next_i, next_j, &checked_cells)) {
//             return; // Hit an obstacle inside the corridor! The path is blocked, no successors.
//         }

//         // Advance to the next cell in the corridor
//         curr_i = next_i;
//         curr_j = next_j;
//         curr_config = get<2>(triple);
//     }

//     // --- 2. STANDARD SUCCESSOR GENERATION ---
//     // At this point, we are either at a branching point or right before a primitive's endpoint.
//     // We iterate over the successors of the updated 'curr_config'.
//     for (auto triple : mesh_info->successors[curr_config]) {
//         int di = get<0>(triple);
//         int dj = get<1>(triple);
//         int next_config = get<2>(triple);
//         int connecting_prim_id = get<3>(triple);
        
//         int succ_i = curr_i + di;
//         int succ_j = curr_j + dj;

//         // Determine the transition cost.
//         // It remains 0.0 for intermediate cells, but if we are transitioning into 
//         // an Initial Cell (connecting_prim_id >= 0), we apply the full primitive cost.
//         double cost = (connecting_prim_id >= 0) ? (double)control_set->cost(connecting_prim_id) : 0.0f;

//         if (check_cell(task_map, succ_i, succ_j, &checked_cells) &&
//             !mesh_should_prune(task_map, succ_i, succ_j, next_config, this)) {
            
//             ptrVertex u = HEAP->new_Vertex(succ_i, succ_j, next_config, true);
//             ptrSearchNode new_node = HEAP->new_SearchNode(u);
            
//             // mesh_set_parent works correctly because all skipped nodes were non-initial cells.
//             // The logical parent correctly points back to the last Initial Cell in the path.
//             mesh_set_parent(current, new_node, mesh_info);
            
//             new_node->g = current->g + cost;
//             new_node->f = new_node->g + heuristic(new_node);

//             list.push_back(new_node);
//         }
//     }
// }

void MeshGraphParams::get_successors(ptrSearchNode current, vector<ptrSearchNode> &list, bool lazy) {
    /*
     Generates successors in the Mesh Graph.
     Note: Lazy evaluation is NOT used in MeshA* due to the complexity of extended cells.
    */
    (void)lazy;
    rassert(lazy == false, "Lazy evaluation not supported in MeshA*!");

    ptrVertex v = current->vertex;
    
    // --- Optimization: Direct Jump to Unique Successor ---
    // If a non-initial cell has exactly ONE valid reachable Initial Cell (u_k in Finals(u)),
    // we can skip intermediate steps and jump directly to it.
    if (!current->mem_after_closed) { // "mem_after_closed=false" implies non-initial
        int valid_endpoints_count = 0;
        tuple<int, int, int, int, int> unique_succ_data; 
        
        // Iterate over Finals(v)
        for (auto p : mesh_info->primitives_in_config[v->config_id]) {
            int next_theta = get<0>(p);
            int di = get<1>(p);
            int dj = get<2>(p);
            int k_trace = get<3>(p); // index in collision trace
            int prim_id = get<4>(p);

            int next_i = v->i + di;
            int next_j = v->j + dj;
            int next_config = mesh_info->initial_config_by_theta[next_theta];
            
            if (check_cell(task_map, next_i, next_j, nullptr) && 
                (!ast->was_expanded(next_i, next_j, next_config))) {
                
                valid_endpoints_count++;
                unique_succ_data = make_tuple(next_i, next_j, next_config, prim_id, k_trace);
            }
            if (valid_endpoints_count > 1) break;
        }

        if (valid_endpoints_count == 0) return; // Dead end -> No successors.
        
        if (valid_endpoints_count == 1) {
            // Optimization: Generate the single Initial Successor directly.
            int i = get<0>(unique_succ_data);
            int j = get<1>(unique_succ_data);
            int next_config = get<2>(unique_succ_data);
            int prim_id = get<3>(unique_succ_data);
            int k_current = get<4>(unique_succ_data);
            
            Primitive *prim = control_set->list_all_prims[prim_id];
            
            // Validate the specific primitive segment connecting v to this endpoint
            // (Relative shift from v to endpoint must be validated)
            int rel_di = i - prim->goal->i;
            int rel_dj = j - prim->goal->j;

            if (check_primitive(task_map, rel_di, rel_dj, k_current, prim, checked_cells)) {
                ptrVertex u = HEAP->new_Vertex(i, j, next_config, true);
                ptrSearchNode new_node = HEAP->new_SearchNode(u);
                
                mesh_set_parent(current, new_node, mesh_info);
                
                new_node->g = current->g + (double)control_set->cost(prim_id); // Full primitive cost
                new_node->f = new_node->g + heuristic(new_node);
                
                list.push_back(new_node);
            }
            return; // Done.
        }
    }
    
    // --- Standard Successor Generation (Algorithm 2) ---
    // Used when the optimization above doesn't apply.
    for (auto triple : mesh_info->successors[v->config_id]) {
        int di = get<0>(triple);
        int dj = get<1>(triple);
        int next_config = get<2>(triple);
        int connecting_prim_id = get<3>(triple); // -1 if ambiguous
        
        int i = v->i + di;
        int j = v->j + dj;

        // Determine transition cost
        // If connecting_prim_id >= 0, it means we are transitioning into an Initial Cell,
        // so the transition corresponds to completing a specific primitive.
        double cost = (connecting_prim_id >= 0) ? (double)control_set->cost(connecting_prim_id) : 0.0f;

        if (check_cell(task_map, i, j, &checked_cells) &&
            !mesh_should_prune(task_map, i, j, next_config, this)) {
            
            ptrVertex u = HEAP->new_Vertex(i, j, next_config, true);
            ptrSearchNode new_node = HEAP->new_SearchNode(u);
            
            mesh_set_parent(current, new_node, mesh_info);
            
            new_node->g = current->g + cost;
            new_node->f = new_node->g + heuristic(new_node);

            list.push_back(new_node);
        }
    }
}

static inline double base_heuristic(ptrSearchNode node, MeshGraphParams *params) {
    if(params->mesh_info->theta_by_initial_config[node->vertex->config_id]>=0)
        return baseline_metric(node->vertex->i-params->finish->i,node->vertex->j-params->finish->j);
    double best=1e100;
    for(auto p:params->mesh_info->primitives_in_config[node->vertex->config_id]) {
        int r=node->vertex->i+get<1>(p),c=node->vertex->j+get<2>(p);
        int config=params->mesh_info->initial_config_by_theta[get<0>(p)];
        if(check_cell(params->task_map,r,c,nullptr)&&!params->ast->was_expanded(r,c,config))
            best=std::min(best,params->control_set->cost(get<4>(p))+baseline_metric(r-params->finish->i,c-params->finish->j));
    }
    return best;
}

double MeshGraphParams::heuristic(ptrSearchNode node) {
    return w * base_heuristic(node, this); 
}

bool MeshGraphParams::lazy_check_collision(ptrSearchNode node) {
    (void)node;
    return true; // Not used
}

MeshGraphParams::~MeshGraphParams() {
    delete ast;
}
