#!/usr/bin/env python3
"""Paired sequence analysis; six map clusters, never independent episodes."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/certified'
FRESH=['fresh-backward','author-mesh','author-lattice','author-lazy']
LABELS={'mc':'MC-A*','mc-uniform':'MC scalar','mc-geometry':'Geometry only','mc-flat':'No compiled gate',
        'path-reuse':'Path reuse','fresh-backward':'Repeated backward A*','author-mesh':'Author MeshA*',
        'author-lattice':'Author LBA*','author-lazy':'Author LazyLBA*','mpgaa-grouped':'MPGAA* grouped',
        'cached-dlite':'Cached D* Lite','cmesh-dlite':'C-Mesh D* Lite','csb':'CSB','mir':'MIR'}

def collect(rawdir,reference,cohorts):
    frames=[]
    for p in sorted(rawdir.glob('*.csv')):
        name,method,rep=p.stem.rsplit('__',2);d=pd.read_csv(p);d['name']=name;d['method']=method;d['repeat']=int(rep[1:]);frames.append(d)
    raw=pd.concat(frames,ignore_index=True).merge(reference[['name','episode','category','event']],on=['name','episode'],validate='many_to_one')
    records=[]
    for (name,method,rep),d in raw.groupby(['name','method','repeat']):
        def total(mask,col='total_us'):
            s=d.loc[mask,col];return float(s.sum()) if len(s) else np.nan
        records.append(dict(name=name,method=method,repeat=rep,online_us=total(d.episode>0),
             all_us=float(d.total_us.sum()),amortized_us=float(d.total_us.sum()+d.setup_us.sum()),
             repair_us=total(d.category=='increase_finite'),improvement_us=total(d.category=='improvement'),
             unchanged_us=total(d.category.isin(['unchanged','unchanged_valid','unchanged_broken'])),
             initial_us=total(d.episode==0),rss_mib=float(d.rss_kib.max()/1024),
             certified=float(d.loc[d.episode>0,'certified'].sum()) if 'certified' in d else 0,
             budget_hits=float(d.loc[d.episode>0,'witness_budget_hit'].sum()) if 'witness_budget_hit' in d else 0,
             witness_probes=float(d['witness_probes'].sum()) if 'witness_probes' in d else 0,
             gate_terms=float(d['gate_terms'].sum()) if 'gate_terms' in d else 0,
             queries=int((d.episode>0).sum())))
    run=pd.DataFrame(records)
    seq=run.groupby(['name','method']).median(numeric_only=True).reset_index().merge(cohorts,on='name',validate='many_to_one')
    return seq,raw,run

def analyze():
    cohorts=pd.DataFrame(json.loads((OUT/'cohorts.json').read_text()))
    reference=pd.read_csv(OUT/'reference.csv')
    seq,raw,run=collect(OUT/'raw',reference,cohorts)
    seq.to_csv(OUT/'sequence_metrics.csv',index=False)
    partial=not all((OUT/'raw'/f'completion_{c}.json').exists() for c in ['primary','validation','regression'])
    result=dict(status='partial' if partial else 'passed',runs=len(run),timed_queries=len(raw),snapshots=len(reference),
                sequences=len(cohorts),cohorts={},comparisons={},
                statistics='Median per-sequence ratios of median repeated sums. 6000 bootstrap resamples of six map clusters retaining controls and modes. Exploratory intervals; no independent-episode assumption.')
    rng=np.random.default_rng(151126);maps=cohorts['map'].unique().tolist()
    weights=np.array([rng.integers(0,len(maps),len(maps)) for _ in range(6000)])
    def compare(method,cohort,metric='online_us',baseline='best-fresh'):
        s=seq[seq.cohort==cohort];p=s.pivot(index='name',columns='method',values=metric)
        if baseline=='best-fresh':base=p[[m for m in FRESH if m in p]].min(axis=1)
        else:base=p[baseline]
        ratio=(base/p[method]).rename('speedup').to_frame().join(cohorts.set_index('name')[['map','mode','control']]).dropna(subset=['speedup'])
        if not len(ratio):return dict(n=0)
        ci=None
        if cohort!='validation':
            arrays=[ratio[ratio['map']==m].speedup.to_numpy() for m in maps]
            med=[]
            for sample in weights:
                values=np.concatenate([arrays[int(i)] for i in sample]);med.append(np.median(values) if len(values) else np.nan)
            ci=np.nanpercentile(med,[2.5,97.5]).tolist()
        return dict(n=len(ratio),median=float(ratio.speedup.median()),ci=ci,wins=int((ratio.speedup>1).sum()),
                    q25=float(ratio.speedup.quantile(.25)),q75=float(ratio.speedup.quantile(.75)))
    for cohort in ['primary','validation','regression']:
        s=seq[seq.cohort==cohort];info=dict(methods={},categories=reference[reference.name.isin(s.name)].category.value_counts().to_dict(),
             sequences=s.name.nunique(),runs=int((run.name.isin(s.name)).sum()),snapshots=int(reference.name.isin(s.name).sum()))
        for method in sorted(s.method.unique()):
            z={metric:compare(method,cohort,metric) for metric in ['online_us','all_us','amortized_us','repair_us','improvement_us','unchanged_us']}
            current=s[s.method==method]
            z['rss_mib']=float(current.rss_mib.median());z['certified_fraction']=float(current.certified.sum()/current.queries.sum())
            z['budget_hit_fraction']=float(current.budget_hits.sum()/current.queries.sum())
            info['methods'][method]=z
        result['cohorts'][cohort]=info
        available=set(s.method)
        for baseline in ['author-mesh','author-lattice','author-lazy','mpgaa-grouped','cached-dlite','cmesh-dlite','csb','mir','path-reuse','mc-geometry','mc-flat','mc-uniform']:
            if baseline in available:result['comparisons'][f'{cohort}:mc/{baseline}']={metric:compare('mc',cohort,metric,baseline) for metric in ['online_us','amortized_us','repair_us']}
    # Descriptive map/mode strata, without pretending each row is a new trial.
    p=seq[seq.cohort=='primary'].pivot(index='name',columns='method',values='online_us')
    base=p[FRESH].min(axis=1)
    ratio=(base/p['mc']).rename('speedup').to_frame().join(cohorts.set_index('name')[['map','mode','control']])
    result['strata']={key:{str(k):float(v.speedup.median()) for k,v in ratio.groupby(key)} for key in ['map','mode','control']}
    result['movement']=cohorts[cohorts.cohort!='regression'].groupby(['cohort','mode']).moves.agg(['min','max']).reset_index().to_dict('records')
    (OUT/('analysis_partial.json' if partial else 'analysis.json')).write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    rows=[]
    for cohort,info in result['cohorts'].items():
        for method,z in info['methods'].items():
            rows.append(dict(cohort=cohort,method=method,online=z['online_us']['median'],
                 setup_included=z['amortized_us']['median'],repair=z['repair_us'].get('median'),
                 certificates=z['certified_fraction'],rss=z['rss_mib']))
    pd.DataFrame(rows).to_csv(OUT/'summary.csv',index=False)
    print(pd.DataFrame(rows).round(3).to_string(index=False))
    return result

def plots(result):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import NullFormatter
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    dest=OUT/'figures';dest.mkdir(exist_ok=True)
    primary=result['cohorts']['primary']['methods']
    methods=['author-mesh','author-lazy','mpgaa-grouped','cached-dlite','cmesh-dlite','csb','mir','mc-geometry','mc-flat','mc-uniform','mc']
    fig,axes=plt.subplots(1,2,figsize=(9,4.4),constrained_layout=True)
    for ax,metric,title in zip(axes,['online_us','amortized_us'],['Replanning only','Whole sequence with setup']):
        vals=[primary[m][metric]['median'] for m in methods];ci=[primary[m][metric]['ci'] for m in methods];y=np.arange(len(methods))
        ax.scatter(vals,y,c=['#777']*7+['#6898bd']*3+['#c1572c'],s=30,zorder=3)
        ax.hlines(y,[c[0] for c in ci],[c[1] for c in ci],color='black',lw=1)
        ax.set_yticks(y,[LABELS[m] for m in methods]);ax.invert_yaxis();ax.set_xscale('log');ax.axvline(1,c='black',lw=.8)
        ax.set_title(title);ax.set_xlabel('Speedup vs best measured fresh engine')
        lo=.75*min(c[0] for c in ci);hi=1.3*max(1,max(c[1] for c in ci));ticks=[x for x in [.01,.02,.05,.1,.2,.5,1,2,5,10,20,50,100] if lo<=x<=hi]
        ax.set_xticks(ticks,[f'{x:g}' for x in ticks]);ax.set_xlim(lo,hi);ax.xaxis.set_minor_formatter(NullFormatter())
    fig.savefig(dest/'comparison.pdf');fig.savefig(dest/'comparison.png',dpi=180);plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(8.6,3.5),constrained_layout=True)
    names=list(result['strata']['map']);values=[result['strata']['map'][n] for n in names]
    axes[0].barh(names,values,color='#c1572c');axes[0].axvline(1,c='black',lw=.8);axes[0].set_xlabel('MC-A* replanning speedup');axes[0].invert_yaxis()
    names=['mc','mc-geometry','mc-flat','mc-uniform','path-reuse'];values=[100*primary[n]['certified_fraction'] for n in names]
    axes[1].barh([LABELS[n] for n in names],values,color='#6898bd');axes[1].set_xlim(0,100);axes[1].set_xlabel('Certified queries, %');axes[1].invert_yaxis()
    fig.savefig(dest/'maps_and_certificates.pdf');fig.savefig(dest/'maps_and_certificates.png',dpi=180);plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--plots',action='store_true');p.add_argument('--plots-only',action='store_true');args=p.parse_args()
    result=json.loads((OUT/'analysis.json').read_text()) if args.plots_only else analyze()
    if args.plots or args.plots_only:plots(result)
