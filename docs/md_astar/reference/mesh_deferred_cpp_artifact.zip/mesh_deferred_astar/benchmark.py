#!/usr/bin/env python3
"""Reproducible paired benchmarks; timed planners run sequentially in random order."""
from __future__ import annotations
import argparse
import csv
import hashlib
import io
import json
import os
import platform
import random
import subprocess
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def synthetic_maps():
    directory=ROOT/'maps';directory.mkdir(exist_ok=True)
    for kind in ['random','rooms','warehouse']:
        rng=random.Random(173);H=W=128
        grid=[['.']*W for _ in range(H)]
        for r in range(H):
            for c in range(W):
                if r in (0,H-1) or c in (0,W-1):grid[r][c]='@'
        if kind=='random':
            for r in range(1,H-1):
                for c in range(1,W-1):
                    if rng.random()<.12:grid[r][c]='@'
        elif kind=='rooms':
            for r in range(32,H-1,32):
                for c in range(1,W-1):
                    if c%32 not in range(10,22):grid[r][c]='@'
            for c in range(32,W-1,32):
                for r in range(1,H-1):
                    if r%32 not in range(10,22):grid[r][c]='@'
        else:
            for r in range(16,112):
                for c in range(16,116):
                    if r%32 in range(0,23) and c%20 in range(0,9):grid[r][c]='@'
        path=directory/f'{kind}.map'
        path.write_text(f'type octile\nheight {H}\nwidth {W}\nmap\n'+'\n'.join(''.join(row) for row in grid)+'\n')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--seeds',type=int,default=4)
    ap.add_argument('--episodes',type=int,default=16)
    ap.add_argument('--repeats',type=int,default=3)
    ap.add_argument('--stage',choices=['generate','run','all'],default='all')
    ap.add_argument('--maps',nargs='+',default=['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown'])
    ap.add_argument('--controls',nargs='+',default=['base','add'])
    ap.add_argument('--patterns',nargs='+',default=['local','path','churn'])
    ap.add_argument('--modes',nargs='+',default=['fixed','moving'])
    ap.add_argument('--label',default='balanced')
    ap.add_argument('--design',choices=['balanced','factorial'],default='balanced')
    ap.add_argument('--timeout',type=int,default=180)
    args=ap.parse_args()
    synthetic_maps()
    workdir=ROOT/'workloads';workdir.mkdir(exist_ok=True)
    rawdir=ROOT/'results'/args.label;rawdir.mkdir(exist_ok=True)
    jobs=[]
    for mapidx,mapname in enumerate(args.maps):
        mapfile=ROOT/'maps'/f'{mapname}.map'
        if not mapfile.exists():mapfile=ROOT.parent/'mesha_reference/maps'/f'{mapname}.map'
        for controlidx,control in enumerate(args.controls):
            for mode in args.modes:
                for pattern in args.patterns:
                    for seed in range(args.seeds):
                        if args.design=='balanced':
                            slot=(seed+2*mapidx+3*controlidx)%6
                            if mode!=['fixed','moving'][slot%2] or pattern!=['local','path','churn'][slot//2]:continue
                        name=f'{mapname}__{control}__{mode}__{pattern}__{seed}'
                        workfile=workdir/f'{name}.work'
                        jobs.append(dict(name=name,map=mapname,control=control,mode=mode,pattern=pattern,seed=seed,
                                         workfile=str(workfile),mapfile=str(mapfile)))
    if args.stage in ('generate','all'):
        for j,job in enumerate(jobs):
            if Path(job['workfile']).exists():continue
            cmd=[str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{job["control"]}_lattice.model'),
                 '--map',job['mapfile'],'--generate',job['workfile'],'--seed',str(1000+job['seed']),
                 '--episodes',str(args.episodes),'--pattern',job['pattern'],'--moving',str(int(job['mode']=='moving'))]
            subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL,timeout=args.timeout)
            if j%10==0:print(f'generated {j+1}/{len(jobs)}',flush=True)
    if args.stage=='generate':return
    environment=dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),python=platform.python_version(),
                     platform=platform.platform(),cpu=subprocess.check_output(['lscpu'],text=True),
                     compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
                     args=vars(args),binary_sha256=hashlib.sha256((ROOT/'bin/ima').read_bytes()).hexdigest(),
                     note='Sequential timed processes, randomized order within each sequence/repeat. Generation and validation excluded from timers.')
    (rawdir/'environment.json').write_text(json.dumps(environment,indent=2))
    failed=[];done=0;beg=time.monotonic()
    shuffle=random.Random(7331);shuffle.shuffle(jobs)
    for job in jobs:
        methods=[('lattice','astar'),('mesh','astar'),('cmesh','astar'),('lattice','dlite'),('mesh','dlite'),('cmesh','dlite'),
                 ('lattice','dlite-cached'),('lattice','dlite-batch')]
        if job['mode']=='fixed':methods += [(k,'lpa') for k in ['lattice','mesh','cmesh']] + [('lattice','lpa-cached'),('lattice','lpa-batch')]
        for rep in range(args.repeats):
            order=methods[:];shuffle.shuffle(order)
            expected=None
            for kind,algo in order:
                name=f'{job["name"]}__{kind}_{algo}__r{rep}'
                dst=rawdir/f'{name}.csv';rssfile=rawdir/f'{name}.rss'
                if not dst.exists():
                    cmd=[str(ROOT/'bin/ima'),
                         '--model',str(ROOT/f'data/{job["control"]}_{kind}.model'),
                         '--workload',job['workfile'],'--algorithm',algo]
                    try:
                        run=subprocess.run(cmd,check=True,text=True,capture_output=True,timeout=args.timeout)
                        # Save only complete successful runs.
                        parsed=list(csv.DictReader(io.StringIO(run.stdout)))
                        if len(parsed)!=args.episodes+1:raise RuntimeError('Incomplete episode sequence')
                        dst.write_text(run.stdout)
                        rssfile.write_text(str(max(int(r['rss_kib']) for r in parsed))+'\n')
                    except (subprocess.SubprocessError,RuntimeError) as exc:
                        failed.append(dict(job=job,method=[kind,algo],repeat=rep,error=str(exc),
                                           stderr=getattr(exc,'stderr',None)))
                        (rawdir/'failures.json').write_text(json.dumps(failed,indent=2))
                        print(f'FAILED {name}: {exc}',flush=True);continue
                rows=list(csv.DictReader(io.StringIO(dst.read_text())))
                costs=[int(row['cost']) for row in rows]
                if expected is None:expected=costs
                elif expected!=costs:raise RuntimeError(f'Cost disagreement: {name}')
                done+=1
        if done%30<args.repeats*len(methods):
            print(f'{done} timed runs; {time.monotonic()-beg:.1f}s; last {job["name"]}',flush=True)
    (rawdir/'failures.json').write_text(json.dumps(failed,indent=2))
    print(json.dumps(dict(runs=done,failures=len(failed),seconds=time.monotonic()-beg)),flush=True)


if __name__=='__main__':main()
