#!/usr/bin/env python3
"""Build the separate research supplement from completed paired measurements."""
import argparse
import json
import re
import subprocess
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/repair'


def table(head,rows):
    return '| '+' | '.join(head)+' |\n| '+' | '.join(['---']*len(head))+' |\n'+'\n'.join('| '+' | '.join(map(str,r))+' |' for r in rows)+'\n'


def f(v):return f'{v:.2f}'


def interval(x):
    return f'{x["median"]:.2f} [{x["ci"][0]:.2f}; {x["ci"][1]:.2f}]' if x.get('ci') else f(x['median'])


def main(pdf):
    a=json.loads((OUT/'analysis.json').read_text())
    done=json.loads((OUT/'raw/completion.json').read_text())
    m=json.loads((OUT/'mechanism/analysis.json').read_text())
    influence=json.loads((OUT/'influence/analysis.json').read_text())
    idone=json.loads((OUT/'influence/completion.json').read_text())
    mdone=json.loads((OUT/'mechanism/completion.json').read_text())
    v=json.loads((OUT/'verification.json').read_text())
    projection=json.loads((OUT/'mesh_projection.json').read_text())
    assert all(x['status']=='passed' for x in projection.values())
    env=json.loads((OUT/'raw/environment.json').read_text())
    assert a['runs']==2700 and a['snapshots']==1020 and done['status']=='passed'
    assert mdone['status']=='passed' and mdone['runs']==288
    assert idone['status']=='passed' and idone['runs']==1944
    labels={'fresh':'Fresh forward','fresh-mesh':'Fresh mesh','fresh-backward':'Fresh backward',
            'lattice-astar':'Old Lattice A*','lattice-dlite':'Lattice D* Lite','cached-dlite':'Cached D* Lite',
            'cmesh-dlite':'C-Mesh D* Lite','gaa':'GAA mesh','gaa-plain':'GAA plain','msp':'MSP',
            'bridge-eager':'Bridge eager','csb':'CSB','forest':'Forest watch','mdf':'MDF','mfr':'MFR'}
    order=['fresh','fresh-mesh','fresh-backward','lattice-astar','lattice-dlite','cached-dlite','cmesh-dlite',
           'gaa-plain','gaa','msp','bridge-eager','csb','forest','mdf','mfr']
    mainrows=[]
    for method in order:
        z=a['methods'][method];s=z['original'];r=s['repair_us']
        mainrows.append([labels[method],interval(s['online_us']),interval(r),f'{r["wins"]}/{r["n"]}',f(z['median_rss_mib'])])
    holdrows=[]
    for method in ['gaa-plain','msp','csb','mdf','mfr']:
        z=a['methods'][method]['heldout'];r=z['repair_us']
        holdrows.append([labels[method],f(z['online_us']['median']),f(r['median']),f'{r["wins"]}/{r["n"]}',
                         f(z['amortized_us']['median'])])
    amortrows=[]
    for method in ['gaa-plain','msp','csb','mdf','mfr']:
        z=a['methods'][method]['original']
        amortrows.append([labels[method],interval(z['all_us']),interval(z['amortized_us']),f(a['methods'][method]['p95_online_ms'])])
    strata=[]
    for mapname in ['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown']:
        strata.append([mapname]+[f(a['methods'][method]['strata_repair']['map'][mapname]['median']) for method in ['mfr','mdf','csb','msp']])
    mechanisms=[]
    for method in ['mdf','mfr','csb','gaa-plain','msp']:
        z=m['methods'][method];r=z['repair_us']
        mechanisms.append([labels[method],f(z['online_us']['median']),f(r['median']),f'{r["wins"]}/{r["n"]}',f(z['amortized_us']['median'])])
    scaling=[]
    for w in [160,320,640]:
        for pos in ['head','tail']:
            scaling.append([w,'у старта' if pos=='head' else 'у цели']+[f(m['strata'][k][f'{w}_{pos}']['median']) for k in ['mdf','mfr','csb']])
    cats=a['categories'];nc=cats['original'].get('increase_finite',0);nh=cats['heldout'].get('increase_finite',0)
    methods=(ROOT/'paper/repair_methods_ru.md').read_text()
    methodtext,sources=methods.split('## Источники',1)
    # The same static coefficients used by the cell certificate, independently recomputed.
    modelrows=[]
    for control in ['base','add']:
        prims=json.loads((ROOT/f'data/{control}_primitives.json').read_text())
        units=lambda r,c:1000*max(abs(r),abs(c))+414*min(abs(r),abs(c))
        alpha=min(p['cost']//units(*p['goal'][:2]) for p in prims if units(*p['goal'][:2]))
        beta=alpha
        for p in prims:
            r,c,_=p['goal']
            for dr,dc in p['trace']:
                den=units(dr,dc)+units(r-dr,c-dc)
                if den:beta=min(beta,p['cost']//den)
        modelrows.append([control,len(prims),sum(len(p['trace']) for p in prims),
                          len({(p['heading'],*d) for p in prims for d in p['trace']}),alpha,beta])
    totalruns=a['runs']+idone['runs']+mdone['runs']
    summary=(f'Реализованы MFR/MDF с ремонтом зависимого дерева, MIR/MIR-F с фильтром влияния и сменой родителя, '
             f'MSP с выборочным ремонтом нижнего потенциала и CSB с клеточным сертификатом и суффиксными мостами. '
             f'В трёх фазах выполнено {totalruns} запусков и {totalruns*17} измеренных запросов; '
             f'совокупно исследовано 1428 различных снимков. '
             f'Оптимальность проверена {v["differential_comparisons"]} сравнениями с независимым Дейкстрой. '
             'Все временные преимущества ниже считаются относительно лучшего свежего A* с совпадающим ядром, '
             'включая поиск в обратном направлении. Преимущество ремонта зависит от расположения изменений '
             'и направления сохранённого дерева; единого победителя на всех нагрузках нет.')
    summary+=(f' В контролируемой семье из 12 серий MDF получил {m["methods"]["mdf"]["repair_us"]["median"]:.2f}×, '
              f'MFR — {m["methods"]["mfr"]["repair_us"]["median"]:.2f}× на настоящих ремонтах. '
              'На основном наборе медианный эффект отрицательный; механизмный результат не подменяет эту оценку.')
    text='''---
title: "Incremental Mesh A*: преимущество ремонта и его границы"
subtitle: "Отдельное исследование в ветке research/repair-advantage"
author: "Исследовательский артефакт"
date: "Ноябрь 2026"
lang: ru-RU
fontsize: 10pt
geometry: margin=19mm
mainfont: Noto Serif
sansfont: Noto Sans
monofont: DejaVu Sans Mono
colorlinks: true
---

## Аннотация

'''+summary+'\n\n'+methodtext
    text+='\n## Измеренные результаты\n\n'
    text+=('Ускорение — отношение времени best-fresh к времени кандидата; больше единицы означает выигрыш. '
           'Сначала суммируется время нужных запросов одной серии в каждом повторении, затем берётся '
           'медиана трёх повторений и медиана парных отношений между сериями. Квадратные скобки — '
           '95% bootstrap-интервал; число выигрышей относится к сериям с соответствующими запросами.\n\n')
    text+='### MIR: доработанный ремонт и новый seed\n\n'
    text+=('После анализа первой фазы заморожена вторая версия. В ней на 72 сериях заново измерены '
           'MDF/MFR, четыре варианта MIR и все три свежих контроля. Новый seed 1005 задаёт ещё 12 '
           'серий по фиксированной формуле: режим — чётность $(i+j)$, тип изменений — $(i+2j+1)\\bmod3$. '
           'До фиксации исходного кода времена новых методов на этих задачах не просматривались. '
           'Все методы получили одинаковые стоимости. Следующая таблица использует прежние 48 серий; '
           'интервалы снова получены перевыборкой seed-блоков внутри карт.\n\n')
    ilabels={'mdf':'MDF','mfr':'MFR','mir-filter':'MIR filter','mdf-rp':'MDF reparent','mir':'MIR','mir-forward':'MIR-F'}
    irows=[]
    for k,label in ilabels.items():
        z=influence['methods'][k];o=z['original'];r=o['repair_us']
        irows.append([label,interval(o['online_us']),interval(r),f'{r["wins"]}/{r["n"]}',f(z['rss_mib'])])
    text+=table(['Метод','Перепланирования','Настоящий ремонт','Выигрыши ремонта','RSS, МиБ'],irows)
    text+=(f'\n**Общего преимущества на основном наборе нет.** Для MIR медианы равны '
           f'{influence["methods"]["mir"]["original"]["online_us"]["median"]:.2f}× по перепланированиям и '
           f'{influence["methods"]["mir"]["original"]["repair_us"]["median"]:.2f}× по настоящему ремонту; '
           f'для MIR-F — {influence["methods"]["mir-forward"]["original"]["online_us"]["median"]:.2f}× и '
           f'{influence["methods"]["mir-forward"]["original"]["repair_us"]["median"]:.2f}× соответственно. '
           'Поэтому положительные локальные примеры далее не следует воспринимать как общий положительный результат.\n')
    text+='\n![Вторая фаза: фильтр влияния, смена родителя и их сочетание. Все контроли измерены заново вместе с кандидатами.](results/repair/influence/speedups.pdf){width=98%}\n'
    text+='\n'+table(['Метод','С первым запросом','С инициализацией'],[[label,interval(influence['methods'][k]['original']['all_us']),interval(influence['methods'][k]['original']['amortized_us'])] for k,label in ilabels.items()])
    text+='\nНа новом seed 1005 (описательная статистика, без доверительных интервалов):\n\n'
    text+=table(['Метод','Перепланирования','Настоящий ремонт','Выигрыши ремонта','С инициализацией'],[
        [label,f(influence['methods'][k]['validation5']['online_us']['median']),f(influence['methods'][k]['validation5']['repair_us']['median']),
         f"{influence['methods'][k]['validation5']['repair_us']['wins']}/{influence['methods'][k]['validation5']['repair_us']['n']}",
         f(influence['methods'][k]['validation5']['amortized_us']['median'])] for k,label in ilabels.items()])
    text+='\nАбляции компонентов во второй фазе; знаменатель ускорения — кандидат, числитель — указанный контроль:\n\n'
    text+=table(['Кандидат / контроль','Перепланирования','Настоящий ремонт'],[
        [ilabels[c]+' / '+ilabels[b],interval(influence['comparisons'][c][b]['online_us']),interval(influence['comparisons'][c][b]['repair_us'])]
        for c,b in [('mir-filter','mdf'),('mdf-rp','mdf'),('mir','mir-filter'),('mir','mdf-rp'),('mir-forward','mfr')]])
    work=influence['work']
    text+='\n'+table(['Метод','Уведомления J','Инвалидированные метки','Смены родителя','Отсеяно изменений'],[
        [label,int(work['notify'][k]),int(work['invalidated'][k]),int(work['alternates'][k]),
         f"{100*work['filtered'][k]/max(1,work['changes'][k]):.1f}%"] for k,label in ilabels.items()])
    text+=(f'\nMIR уменьшил суммарное число уведомлений относительно MDF на '
           f'{100*(1-work["notify"]["mir"]/work["notify"]["mdf"]):.1f}%, число инвалидированных меток — на '
           f'{100*(1-work["invalidated"]["mir"]/work["invalidated"]["mdf"]):.1f}%. '
           'Снижение этих счётчиков само по себе не даёт ускорения: проверки альтернатив и подготовка фильтра тоже стоят времени.\n')
    # This pilot task is declared in advance in benchmark_repair.py, not chosen as a maximum.
    iseq=pd.read_csv(OUT/'influence/sequence_metrics.csv')
    example=iseq[iseq.name=='Berlin_2_256__base__fixed__local__0'].set_index('method')
    ebest=min(example.loc[k,'repair_us'] for k in ['fresh','fresh-mesh','fresh-backward'])
    text+=(f'\nИллюстративная задача разработки Berlin/base/fixed/local/seed0, входившая в исходный пилот: '
           f'MIR-F ускоряет настоящие ремонты в {ebest/example.loc["mir-forward","repair_us"]:.2f} раза '
           'относительно best-fresh. Это локальный положительный пример, а не средний эффект по карте '
           'или доказательство переноса. Сводные таблицы выше показывают и остальные задачи.\n\n')
    text+='### Первая фаза: исходные кандидаты и широкий набор контролей\n\n'
    text+=(f'Основной набор содержит {cats["original"].get("initial",0)} первых запросов и '
           f'{nc} запросов с конечным строго подорожавшим оптимальным продолжением; дополнительный набор — '
           f'{cats["heldout"].get("initial",0)} первых запросов и {nh} таких ремонтов. '
           'Все методы во всех повторах получили одинаковые стоимости, включая отсутствие пути. '
           'Значение ускорения больше единицы означает выигрыш. Квадратные скобки — 95% bootstrap-интервал. '
           'Доли выигрышей относятся к сериям, а не к отдельным запросам.\n\n')
    text+=table(['Метод','Все перепланирования','Настоящий ремонт','Выигрыши ремонта','RSS, МиБ'],mainrows)
    text+='\n![Ускорение на основном наборе. Best-fresh выбирает лучший свежий контроль отдельно для каждого столбца.](figures/repair/speedups.pdf){width=98%}\n\n'
    text+='### Первый запрос, инициализация и задержки\n\n'
    text+=table(['Метод','С первым запросом','С инициализацией','p95 запроса, мс'],amortrows)
    text+=('\np95 описывает распределение медианных по повторам задержек запросов перепланирования. '
           'Это отдельная характеристика, не доверительный интервал среднего эффекта. '
           'Первый запрос новых методов включает построение их поисковой памяти; стоимость сохранения дерева '
           'не исключается из приведённых сумм.\n\n')
    text+='### Перенос на дополнительный seed\n\n'
    text+=table(['Метод','Перепланирования','Настоящий ремонт','Выигрыши ремонта','С инициализацией'],holdrows)
    text+=('\nЭто 12 заранее выбранных серий, по одной на пару «карта, набор примитивов». '
           'Один дополнительный seed не позволяет оценить устойчивость на произвольных новых картах.\n\n')
    text+='### Зависимость настоящего ремонта от карты\n\n'
    text+=table(['Карта','MFR','MDF','CSB','MSP'],strata)
    text+='\n![Зависимость общего перепланирования от карты. На каждой карте представлены оба набора примитивов и четыре seed.](figures/repair/maps.pdf){width=95%}\n\n'
    text+='### Абляции и цена структур данных\n\n'
    ab=[]
    for method,base in [('mdf','forest'),('mfr','fresh'),('mdf','fresh-backward'),('msp','gaa'),('msp','gaa-plain'),('csb','bridge-eager'),('csb','msp')]:
        z=a['comparisons'][method][base]
        ab.append([labels[method]+' / '+labels[base],interval(z['online_us']),interval(z['repair_us'])])
    text+=table(['Кандидат / контроль','Перепланирования','Настоящий ремонт'],ab)
    text+=('\nКонтроль `forest` отличается от MDF динамической регистрацией клеток выбранных рёбер. '
           'Сравнение MSP/GAA mesh выделяет уведомления, тогда как MSP/GAA plain включает цену пакетной '
           'mesh-проверки. CSB/Bridge eager выделяет клеточный сертификат и отсрочку, но не является '
           'сравнением с опубликованной реализацией MPGAA*. Если интервал охватывает единицу, этот эксперимент '
           'не устанавливает надёжного общего ускорения данного компонента.\n\n')
    text+=table(['Метод','Доля сертификатов','Доля времени ремонта H'],[
        [labels[k],f'{100*a["methods"][k]["certified_fraction"]:.1f}%',f'{100*a["methods"][k]["potential_fraction"]:.1f}%'] for k in ['gaa-plain','msp','bridge-eager','csb']])
    text+='\n## Механизмный тест: локальность поломки и масштаб\n\n'
    text+=('Этот диагностический набор задан после пилотов отдельно от основных карт. Он проверяет гипотезу '
           'о локальности зависимого дерева и не служит слепой оценкой обобщения. Карты имеют высоту 80 '
           'и ширину 160, 320 или 640 клеток. Старт и цель лежат на центральной строке, в 16 клетках от границ. '
           'Пост из 13 клеток попеременно появляется и исчезает на 1/8 либо 7/8 расстояния до цели. '
           'Все комбинации размеров, положения и двух наборов примитивов дают 12 серий. '
           'Геометрия фиксирована без использования времени или пути кандидата. Контрольная стоимость '
           'сверена с исходным Lattice A*.\n\n')
    text+=(f'В этих сериях {m["snapshots"]} снимков, из них {m["categories"].get("increase_finite",0)} '
           'конечных настоящих ремонтов. Таблицы снова используют best-fresh, подобранный отдельно для каждой серии и метрики. '
           'Здесь описывается конечная параметрическая семья, поэтому bootstrap-интервалы для неё не приводятся.\n\n')
    text+=table(['Метод','Перепланирования','Настоящий ремонт','Выигрыши ремонта','С инициализацией'],mechanisms)
    text+='\n'+table(['Ширина','Пост','MDF','MFR','CSB'],scaling)
    text+='\n![Масштабирование настоящего ремонта в зависимости от положения препятствия. Каждая точка — медиана по двум наборам примитивов.](results/repair/mechanism/scaling.pdf){width=96%}\n\n'
    text+='## Преимущества, недостатки и практическая применимость\n\n'
    text+=('MFR полезен, когда старт устойчив, а повреждение затрагивает небольшое продолжение сохранённого '
           'префиксного дерева. MDF сохраняет память при движении старта и может использовать небольшой '
           'суффиксный регион ремонта. Решает не только число изменённых клеток: одна клетка может разрушить '
           'крупную зависимую ветвь. Массовое открытие клеток дополнительно требует поиска улучшений даже '
           'при совершенно допустимом старом пути. Поэтому никакого равномерного преимущества над свежим '
           'поиском эти структуры не гарантируют.\n\n'
           'MSP экономит на повторяющихся уведомлениях, но пакетный обход mesh может проверять ветви, которые '
           'обычный A* отсекает ещё до проверки столкновений. На маленьком пространстве поиска эта цена '
           'перевешивает пользу сильной эвристики. CSB позволяет быстро подтвердить оптимальность целого '
           'пути и пропустить ненужный ремонт H; при настоящей поломке он всё равно должен искать обход. '
           'Высокая доля сертификатов сама по себе не подтверждает преимущество такого поиска.\n\n'
           'Для следующей версии практически интересен ограниченный бюджет ремонта с переходом к свежему '
           'поиску по оценке затронутого региона. В текущий эксперимент такая политика не включена: '
           'добавление её после просмотра тестовых времён смешало бы разработку с проверкой переноса. '
           'Также нужны независимая реализация DFSA*/MPGAA*, более длинные серии, новые карты, другие '
           'control sets и более строгий контроль аппаратной вариабельности. Текущие доказательства и '
           'дифференциальные проверки относятся к корректности путей; скорость установлена только для '
           'опубликованных нагрузок и окружения.\n\n')
    text+='## Проверки и воспроизводимость\n\n'
    text+=table(['Набор','Серии','Различные снимки','Запуски','Измеренные запросы'],[
        ['Основные карты',60,1020,a['runs'],a['queries']],
        ['MIR, повторная фаза',72,1224,idone['runs'],idone['queries']],
        ['Локальность',12,m['snapshots'],mdone['runs'],mdone['queries']],
        ['Независимый Дейкстра',v['cases'],v['oracle_episodes'],'—',v['differential_comparisons']+' сравнений' if isinstance(v['differential_comparisons'],str) else str(v['differential_comparisons'])+' сравнений']])
    text+=(f'\nОракул реализован на Python независимо от C++-поиска. Из {v["oracle_episodes"]} снимков '
           f'{v["feasible_episodes"]} имеют путь. Проверяются все 16 направлений, оба набора примитивов, '
           'добавления и удаления препятствий, разрывы связности и восстановление, перемещение и обратное '
           'движение старта, каждая покрытая клетка извлечённой траектории, согласованность H перед поиском '
           f'и после обучения, зависимости конечных меток дерева. Все {len(v["methods"])} вариантов прошли проверки. '
           'На больших сериях выполнено попарное сравнение точных стоимостей со свежим поиском и исходным '
           'Lattice A*, а не полный независимый Дейкстра.\n\n')
    text+=table(['Набор','Примитивы','Отдельные зависимости','Группы J','alpha','beta'],modelrows)
    text+='\nНезависимый обход исходных mesh-моделей подтвердил точное соответствие всех путей-примитивов, их стоимостей, покрытых клеток и граничных масок J.\n\nФайл результата: `results/repair/mesh_projection.json`.\n'
    cpu=next((x.split(':',1)[1].strip() for x in env['cpu'].splitlines() if x.startswith('Model name:')),'see environment.json')
    text+=f'\nОкружение: {cpu}; {env["compiler"]}; C++17, `-O3 -DNDEBUG`. Одна облачная Linux-машина, {env["platform"]}. Порядок рандомизации и контрольные суммы исходников/бинарников сохранены в `results/repair/raw/environment.json`.\n\n'
    text+='''```bash
make repair bin/repair_v1 bin/ima
make test-repair
python benchmark_repair.py --stage prepare
python benchmark_repair.py --repeats 3
python analyze_repair.py --plots
python benchmark_influence.py --stage prepare
python benchmark_influence.py --stage run
python benchmark_influence.py --stage analyze
python mechanism_repair.py --stage prepare
python mechanism_repair.py --stage run
python mechanism_repair.py --stage analyze
python render_repair.py --pdf
```

Тесты и подготовка должны завершиться до начала измерений. CSV содержит полные
стоимости, время, раскрытия, число уведомлений, сертификаты, изменения эвристики
и пиковый RSS. Медианы серий сохранены в `results/repair/sequence_metrics.csv`;
классификация настоящего ремонта — в `results/repair/reference.csv`. Пилоты
исключены из всех итоговых таблиц. Исходное исследование сохранено в ветке
`baseline`, коммит `6cd6a4e`; новый код находится в `research/repair-advantage`.

'''
    text+='## Источники'+sources
    metadata_end=text.find('\n---\n',4)+5
    text=text[:metadata_end]+re.sub(r'(?<![\\\w])(MeshA|LPA|A|D)\*(?!\*)',r'\1\\*',text[metadata_end:])
    path=ROOT/'paper/repair_advantage_ru.md';path.write_text(text)
    brief='# Результаты исследования ремонта\n\n'
    brief+='Ветка `research/repair-advantage`. Все ускорения ниже относятся к лучшему из трёх свежих A* в той же временной фазе. Больше единицы — быстрее.\n\n'
    brief+=table(['Вариант','Перепланирования, 48 серий','Настоящий ремонт, 48 серий','Ремонт, новый seed'],[
        [label,interval(influence['methods'][k]['original']['online_us']),interval(influence['methods'][k]['original']['repair_us']),f(influence['methods'][k]['validation5']['repair_us']['median'])] for k,label in ilabels.items()])
    brief+='\nГраницы эффекта важны: отдельный выигрыш на локальной поломке не означает превосходства на всём наборе. Полные таблицы, отрицательные результаты, абляции и доказательства находятся в `paper/repair_advantage_ru.pdf`.\n\n'
    brief+=f'Три фазы: {totalruns} запусков / {totalruns*17} измеренных запросов; 1428 различных снимков. Независимый Дейкстра: {v["differential_comparisons"]} сравнений без расхождений. Контроль настоящего ремонта требует строгого роста конечного оптимального продолжения.\n\n'
    brief+='Механизмный набор локальности (12 серий):\n\n'+table(['Метод','Настоящий ремонт','Выигрыши'],[[k,f(m['methods'][k]['repair_us']['median']),f"{m['methods'][k]['repair_us']['wins']}/12"] for k in ['mdf','mfr','csb']])
    (OUT/'REPORT_RU.md').write_text(brief)
    if pdf:
        tex=ROOT/'paper/repair_advantage_ru.tex'
        subprocess.run(['pandoc',str(path),'-s','--include-in-header',str(ROOT/'paper/layout.tex'),'-o',str(tex)],cwd=ROOT,check=True)
        subprocess.run(['pandoc',str(path),'-s','--include-in-header',str(ROOT/'paper/layout.tex'),
                        '--pdf-engine=xelatex','-o',str(ROOT/'paper/repair_advantage_ru.pdf')],cwd=ROOT,check=True)
    print(path)


if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--pdf',action='store_true');args=ap.parse_args();main(args.pdf)
