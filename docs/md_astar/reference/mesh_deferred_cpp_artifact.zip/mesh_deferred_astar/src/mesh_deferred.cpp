// MD-A*: a mesh-compiled cell bound delays irrelevant cost decreases.
#define CERTIFIED_LIBRARY
#include "certified.cpp"
#include <climits>
#include "mpgaa_bbox_reference.hpp"

struct DeferredStats {uint64_t certified=0,search_called=0,gate_terms=0,activated=0,refined=0;};
class MeshDeferred {
    Graph& actual;Id goal;std::string method;SuffixCertificate cache;
    MeshCertificate compiled;Grid working_grid;Graph working;
    MeshOracle oracle;MPGAABBoxReference backend;
    using Item=std::pair<I,int>;
    std::unordered_map<int,I> deferred;
    std::priority_queue<Item,std::vector<Item>,std::greater<Item>> waiting;
    std::set<int> pending_blocks;std::vector<RC> pending_opens;
    I travel=0;std::optional<RC> previous_start;
    bool no_path=false;Id no_path_start=NONE;
    I lower(RC s,RC q,DeferredStats& stats)const {
        auto t=actual.pos(goal);
        if(method!="md64") {
            ++stats.gate_terms;
            return actual.m.metric(q.r-s.r,q.c-s.c)+actual.m.metric(t.r-q.r,t.c-q.c)+compiled.uniform;
        }
        static const RC a[8]={{1000,414},{414,1000},{-414,1000},{-1000,414},{-1000,-414},{-414,-1000},{414,-1000},{1000,-414}};
        I best=-INF;
        for(int i=0;i<8;++i)for(int j=0;j<8;++j){++stats.gate_terms;
            I v=actual.m.alpha*(I(a[i].r)*(q.r-s.r)+I(a[i].c)*(q.c-s.c)+I(a[j].r)*(t.r-q.r)+I(a[j].c)*(t.c-q.c));
            best=std::max(best,v+compiled.mu[i][j]);
        }
        return best;
    }
    void activate(int cell,DeferredStats& stats) {
        if(!deferred.erase(cell))return;
        working_grid.blocked[cell]=0;pending_opens.push_back({cell/actual.grid.W,cell%actual.grid.W});++stats.activated;
    }
    uint64_t release(RC s,I upper,DeferredStats& stats) {
        uint64_t before=stats.activated;
        if(method=="md-scan") {
            std::vector<int> ready;
            for(auto [cell,key]:deferred){(void)key;++stats.refined;
                if(upper>=INF||lower(s,{cell/actual.grid.W,cell%actual.grid.W},stats)<upper)ready.push_back(cell);
            }
            for(int cell:ready)activate(cell,stats);
            return stats.activated-before;
        }
        while(!waiting.empty()) {
            auto [key,cell]=waiting.top();auto it=deferred.find(cell);
            if(it==deferred.end()||it->second!=key){waiting.pop();continue;}
            if(upper<INF && key>=upper+travel)break;
            waiting.pop();RC q{cell/actual.grid.W,cell%actual.grid.W};
            if(upper<INF) {
                I fresh=lower(s,q,stats)+travel;++stats.refined;
                if(fresh>=upper+travel){it->second=fresh;waiting.push({fresh,cell});continue;}
            }
            activate(cell,stats);
        }
        return stats.activated-before;
    }
    Chain replan(Id start,DeferredStats& stats) {
        Changes changes;changes.opened.swap(pending_opens);
        for(int cell:pending_blocks)changes.blocked.push_back({cell/actual.grid.W,cell%actual.grid.W});
        pending_blocks.clear();oracle.snapshot();++stats.search_called;
        return backend.solve(start,changes);
    }
    void activate_path(const Chain& p,DeferredStats& stats) {
        for(size_t i=0;i<p.edges.size();++i){auto u=actual.pos(p.states[i]);
            for(auto d:actual.m.edges[p.edges[i]].trace)activate((u.r+d.r)*actual.grid.W+u.c+d.c,stats);
        }
    }
public:
    MeshDeferred(Graph& g,Id t,const std::string& name,const std::string& model):
        actual(g),goal(t),method(name),cache(g),compiled(g.m,model),working_grid(g.grid),working(g.m,working_grid),
        oracle(working,model,false),backend(working,oracle,t,true){}
    size_t cells()const{return cache.cells();}
    size_t delayed()const{return deferred.size();}
    const Stats& work()const{return working.st;}
    Chain solve(Id start,const Changes& changes,DeferredStats& stats) {
        working.st={};auto s=actual.pos(start);
        if(previous_start)travel+=actual.m.metric(s.r-previous_start->r,s.c-previous_start->c);
        previous_start=s;cache.update(changes);
        for(auto q:changes.blocked) {
            int cell=q.r*actual.grid.W+q.c;deferred.erase(cell);
            if(!working_grid.blocked[cell]){working_grid.blocked[cell]=1;pending_blocks.insert(cell);}
        }
        for(auto q:changes.opened) {
            int cell=q.r*actual.grid.W+q.c;I key=lower(s,q,stats)+travel;
            deferred[cell]=key;waiting.push({key,cell});
        }
        // Lazy deleted heap items cannot accumulate without bound.
        if(waiting.size()>2*deferred.size()+64) {
            std::vector<Item> items;items.reserve(deferred.size());for(auto x:deferred)items.push_back({x.second,x.first});
            waiting=decltype(waiting)(std::greater<Item>(),std::move(items));
        }
        if(no_path&&start==no_path_start&&changes.opened.empty()){++stats.certified;return {};}
        auto at=cache.position(start);Chain result;
        if(at&&cache.valid(*at)&&actual.free(start)&&actual.free(goal)) {
            I upper=cache.cost(*at);
            if(!release(s,upper,stats)){++stats.certified;return cache.suffix(*at);}
            // Keep an actual feasible incumbent available in the working map,
            // including equality-bound cells on its own trace.
            activate_path(cache.suffix(*at),stats);result=replan(start,stats);
            if(result.cost>upper)throw std::runtime_error("Working graph lost the incumbent");
        }else {
            result=replan(start,stats);I upper=result.cost;
            if(release(s,upper,stats)){result=replan(start,stats);if(result.cost>upper)throw std::runtime_error("Decreases raised the optimum");}
        }
        cache.install(result);no_path=result.cost>=INF;no_path_start=start;return result;
    }
};

int main(int argc,char** argv) {
    try {
        std::unordered_map<std::string,std::string> args;
        for(int i=1;i<argc;++i){std::string k=argv[i];if(k=="--dump"||k=="--audit")args[k]="1";else{if(i+1>=argc)throw std::runtime_error("Missing option");args[k]=argv[++i];}}
        verify_repair_invariants=args.count("--audit");std::string method=args.count("--algorithm")?args.at("--algorithm"):"md";
        if(method!="md"&&method!="md64"&&method!="md-scan")throw std::runtime_error("Unknown method");
        auto begin=Clock::now();Model model(args.at("--model"));auto w=load_workload(args.at("--workload"));Grid grid(w.map);Graph graph(model,grid);
        Id goal=graph.id(w.goal);MeshDeferred planner(graph,goal,method,args.at("--model"));
        double setup=std::chrono::duration<double,std::micro>(Clock::now()-begin).count();Chain previous;
        std::cout<<"episode,cost,total_us,expanded,edge_checks,cell_checks,pushes,pops,certified,search_called,gate_terms,cache_cells,changes,setup_us,rss_kib,previous_suffix_valid,previous_suffix_cost,deferred_cells,activated_cells,refined_cells,notify_probes\n";
        for(size_t ep=0;ep<w.steps.size();++ep) {
            graph.st={};DeferredStats stats;auto t0=Clock::now();auto changes=change_grid(grid,w.steps[ep]);Id start=graph.id(w.steps[ep].start);
            auto p=planner.solve(start,changes,stats);auto t1=Clock::now();validate_chain(graph,p,start,goal);
            int old_valid=-1;I old_cost=-1;auto at=std::find(previous.states.begin(),previous.states.end(),start);
            if(previous.cost<INF&&at!=previous.states.end()) {
                old_valid=1;old_cost=0;
                for(size_t i=at-previous.states.begin();i<previous.edges.size();++i){auto u=graph.pos(previous.states[i]);const auto& e=model.edges[previous.edges[i]];old_cost+=e.cost;
                    for(auto d:e.trace)if(!grid.free(u.r+d.r,u.c+d.c))old_valid=0;
                }
            }
            struct rusage rss{};getrusage(RUSAGE_SELF,&rss);const auto& st=planner.work();
            std::cout<<ep<<','<<(p.cost>=INF?-1:p.cost)<<','<<std::chrono::duration<double,std::micro>(t1-t0).count()<<','<<st.expanded<<','<<st.edge_checks<<','<<st.cell_checks<<','<<st.pushes<<','<<st.pops<<','<<stats.certified<<','<<stats.search_called<<','<<stats.gate_terms<<','<<planner.cells()<<','<<changes.opened.size()+changes.blocked.size()<<','<<(ep==0?setup:0)<<','<<rss.ru_maxrss<<','<<old_valid<<','<<old_cost<<','<<planner.delayed()<<','<<stats.activated<<','<<stats.refined<<','<<st.notify_probes<<'\n';
            if(args.count("--dump")){std::cerr<<"PATH "<<ep;for(int e:p.edges)std::cerr<<' '<<model.edges[e].pid;std::cerr<<'\n';}previous=std::move(p);
        }
    }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
