#define REPAIR_LIBRARY
#include "repair.cpp"
#include <climits>
#include "mpgaa_bbox_reference.hpp"
int main(int argc,char** argv) {
    try {
        std::unordered_map<std::string,std::string> args;
        for(int i=1;i<argc;++i){std::string k=argv[i];if(k=="--audit"||k=="--dump")args[k]="1";else{if(i+1>=argc)throw std::runtime_error("Missing option");args[k]=argv[++i];}}
        verify_repair_invariants=args.count("--audit");
        auto setup0=Clock::now();Model m(args.at("--model"));auto w=load_workload(args.at("--workload"));Grid grid(w.map);Graph graph(m,grid);
        MeshOracle oracle(graph,args.at("--model"),false);Id goal=graph.id(w.goal);MPGAABBoxReference planner(graph,oracle,goal,true);
        double setup=std::chrono::duration<double,std::micro>(Clock::now()-setup0).count();
        std::cout<<"episode,cost,total_us,expanded,edge_checks,cell_checks,changes,setup_us,rss_kib\n";
        for(size_t ep=0;ep<w.steps.size();++ep) {
            graph.st={};auto t0=Clock::now();auto changes=change_grid(grid,w.steps[ep]);oracle.snapshot();Id start=graph.id(w.steps[ep].start);
            auto p=planner.solve(start,changes);auto t1=Clock::now();validate_chain(graph,p,start,goal);
            struct rusage rss{};getrusage(RUSAGE_SELF,&rss);
            std::cout<<ep<<','<<(p.cost>=INF?-1:p.cost)<<','<<std::chrono::duration<double,std::micro>(t1-t0).count()<<','<<graph.st.expanded<<','<<graph.st.edge_checks<<','<<graph.st.cell_checks<<','<<changes.opened.size()+changes.blocked.size()<<','<<(ep==0?setup:0)<<','<<rss.ru_maxrss<<'\n';
            if(args.count("--dump")){std::cerr<<"PATH "<<ep;for(int e:p.edges)std::cerr<<' '<<m.edges[e].pid;std::cerr<<'\n';}
        }
    }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
