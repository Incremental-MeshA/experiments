// MC-A*: certificates suspend MPGAA* maintenance until a search is necessary.
#define CERTIFIED_LIBRARY
#include "certified.cpp"
#include <climits>
#include "mpgaa_bbox_reference.hpp"

class MCAdaptive {
    Graph& g;Id goal;std::string method;SuffixCertificate cache;
    MeshCertificate compiled;MPGAABBoxReference backend;
    // Final values are a conservative superset of net changes since the backend
    // last ran. No old map is stored. Repeated cell changes are coalesced.
    std::unordered_map<int,bool> pending;
    bool no_path=false;Id no_path_start=NONE;
    uint64_t previous_work=0;
    I frozen_lower(Id u)const {
        I h=backend.goal_lower(u);auto at=cache.position(u);
        return at?std::max(h,cache.cost(*at)):h;
    }
    bool proves(Id start,const Changes& changes,I upper,CertificateStats& stats) {
        auto s=g.pos(start),t=g.pos(goal);
        uint64_t budget=std::max<uint64_t>(64,previous_work/8);
        for(auto q:changes.opened) {
            ++stats.gate_cells;bool excluded=false;
            if(method=="mc-scalar") {
                ++stats.gate_terms;
                excluded=g.m.metric(s.r-q.r,s.c-q.c)+g.m.metric(t.r-q.r,t.c-q.c)+compiled.uniform>=upper;
            }else if(method!="mc-nogate")excluded=compiled.excludes(s,t,q,upper,stats.gate_terms);
            if(excluded)continue;
            if(method=="mc-geometric")return false;
            for(const auto& d:g.m.dep) {
                if(++stats.witness_probes>budget){stats.witness_budget_hit=1;return false;}
                int r=q.r-d.dr,c=q.c-d.dc;if(!g.grid.inside(r,c))continue;
                const auto& e=g.m.edges[d.edge];Id u=g.id(r,c,e.src),v=g.head(u,d.edge);
                if(v==NONE)continue;
                I after=frozen_lower(v);if(after>=INF)continue;
                if(g.m.metric(r-s.r,c-s.c)+e.cost+after<upper && g.cost(u,d.edge)<INF)return false;
            }
        }
        return true;
    }
public:
    MCAdaptive(Graph& graph,MeshOracle& oracle,Id t,const std::string& name,const std::string& model):
        g(graph),goal(t),method(name),cache(g),compiled(g.m,model),backend(g,oracle,t,true){}
    size_t cells()const{return cache.cells();}
    Chain solve(Id start,const Changes& changes,CertificateStats& stats) {
        if(method=="mpgaa-bbox"){++stats.search_called;return backend.solve(start,changes);}
        cache.update(changes);
        for(auto q:changes.opened)pending[q.r*g.grid.W+q.c]=false;
        for(auto q:changes.blocked)pending[q.r*g.grid.W+q.c]=true;
        if(no_path&&start==no_path_start&&changes.opened.empty()){++stats.certified;return {};}
        auto at=cache.position(start);
        if(at&&*at>=cache.certified_at&&cache.valid(*at)&&g.free(start)&&g.free(goal)&&proves(start,changes,cache.cost(*at),stats)) {
            ++stats.certified;cache.certified_at=*at;return cache.suffix(*at);
        }
        Changes accumulated;std::vector<int> ordered;ordered.reserve(pending.size());
        for(auto [cell,value]:pending){(void)value;ordered.push_back(cell);}
        std::sort(ordered.begin(),ordered.end());
        for(int cell:ordered)(pending.at(cell)?accumulated.blocked:accumulated.opened).push_back({cell/g.grid.W,cell%g.grid.W});
        uint64_t before=g.st.cell_checks+g.st.pushes+g.st.pops+g.st.notify_probes;
        uint64_t expansions=g.st.expanded;
        ++stats.search_called;auto result=backend.solve(start,accumulated);
        uint64_t work=g.st.cell_checks+g.st.pushes+g.st.pops+g.st.notify_probes-before;
        if(g.st.expanded>expansions)previous_work=work;
        pending.clear();cache.install(result);no_path=result.cost>=INF;no_path_start=start;
        return result;
    }
};

int main(int argc,char** argv) {
    try {
        std::unordered_map<std::string,std::string> args;
        for(int i=1;i<argc;++i){std::string k=argv[i];if(k=="--dump"||k=="--audit")args[k]="1";else{if(i+1>=argc)throw std::runtime_error("Missing option");args[k]=argv[++i];}}
        verify_repair_invariants=args.count("--audit");
        std::string method=args.count("--algorithm")?args.at("--algorithm"):"mc-adaptive";
        if(!std::set<std::string>{"mc-adaptive","mc-scalar","mc-nogate","mc-geometric","mpgaa-bbox"}.count(method))throw std::runtime_error("Unknown method");
        auto begin=Clock::now();Model model(args.at("--model"));auto w=load_workload(args.at("--workload"));Grid grid(w.map);Graph graph(model,grid);
        MeshOracle oracle(graph,args.at("--model"),false);Id goal=graph.id(w.goal);
        MCAdaptive planner(graph,oracle,goal,method,args.at("--model"));
        double setup=std::chrono::duration<double,std::micro>(Clock::now()-begin).count();Chain previous;
        std::cout<<"episode,cost,total_us,expanded,edge_checks,cell_checks,pushes,pops,certified,search_called,gate_cells,gate_terms,cache_cells,changes,setup_us,rss_kib,previous_suffix_valid,previous_suffix_cost,witness_probes,witness_budget_hit\n";
        for(size_t ep=0;ep<w.steps.size();++ep) {
            graph.st={};CertificateStats stats;auto t0=Clock::now();auto changes=change_grid(grid,w.steps[ep]);oracle.snapshot();Id start=graph.id(w.steps[ep].start);
            auto p=planner.solve(start,changes,stats);auto t1=Clock::now();validate_chain(graph,p,start,goal);
            int old_valid=-1;I old_cost=-1;auto at=std::find(previous.states.begin(),previous.states.end(),start);
            if(previous.cost<INF&&at!=previous.states.end()) {
                old_valid=1;old_cost=0;
                for(size_t i=at-previous.states.begin();i<previous.edges.size();++i) {
                    auto u=graph.pos(previous.states[i]);const auto& e=model.edges[previous.edges[i]];old_cost+=e.cost;
                    for(auto d:e.trace)if(!grid.free(u.r+d.r,u.c+d.c))old_valid=0;
                }
            }
            struct rusage rss{};getrusage(RUSAGE_SELF,&rss);const auto& s=graph.st;
            std::cout<<ep<<','<<(p.cost>=INF?-1:p.cost)<<','<<std::chrono::duration<double,std::micro>(t1-t0).count()<<','<<s.expanded<<','<<s.edge_checks<<','<<s.cell_checks<<','<<s.pushes<<','<<s.pops<<','<<stats.certified<<','<<stats.search_called<<','<<stats.gate_cells<<','<<stats.gate_terms<<','<<planner.cells()<<','<<changes.opened.size()+changes.blocked.size()<<','<<(ep==0?setup:0)<<','<<rss.ru_maxrss<<','<<old_valid<<','<<old_cost<<','<<stats.witness_probes<<','<<stats.witness_budget_hit<<'\n';
            if(args.count("--dump")){std::cerr<<"PATH "<<ep;for(int ei:p.edges)std::cerr<<' '<<model.edges[ei].pid;std::cerr<<'\n';}previous=std::move(p);
        }
    }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
