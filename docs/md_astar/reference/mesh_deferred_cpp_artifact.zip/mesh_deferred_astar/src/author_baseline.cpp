#include <bits/stdc++.h>
#define REPAIR_LIBRARY
#include "repair.cpp"
namespace author {
long long metric_alpha=0;
double baseline_metric(int r,int c){long long a=std::abs(r),b=std::abs(c);return double(metric_alpha*(1000*std::max(a,b)+414*std::min(a,b)));}
#include "../third_party/mesha_author/include/KC_algorithms.hpp"
MyHEAP* HEAP=new MyHEAP();
#include "../third_party/mesha_author/src/KC_heap.cpp"
#include "../third_party/mesha_author/src/KC_searching.cpp"
#include "../third_party/mesha_author/src/KC_structs.cpp"
#include "../third_party/mesha_author/src/KC_search_params.cpp"
#include "../third_party/mesha_author/src/KC_algorithms.cpp"
}

int main(int argc,char** argv) {
    try {
        std::unique_ptr<author::MyHEAP> pool_owner(author::HEAP);
        std::unordered_map<std::string,std::string> args;
        for(int i=1;i<argc;++i){std::string key=argv[i];if(key=="--dump"||key=="--audit")args[key]="1";else {if(i+1>=argc)throw std::runtime_error("Missing option");args[key]=argv[++i];}}
        std::string method=args.at("--algorithm");bool meshmode=method=="author-mesh",lazy=method=="author-lazy";
        if(!meshmode&&!lazy&&method!="author-lattice")throw std::runtime_error("Unknown author method");
        auto setup0=Clock::now();Model m(args.at("--model"));auto work=load_workload(args.at("--workload"));Grid grid(work.map);Graph graph(m,grid);
        author::metric_alpha=m.alpha;author::Map map;map.empty_map(grid.W,grid.H);
        for(int r=0;r<grid.H;++r)for(int c=0;c<grid.W;++c)map.cells[r][c]=grid.blocked[r*grid.W+c];
        author::ControlSet controls;std::unordered_map<int,int> edge_by_pid;
        for(size_t i=0;i<m.edges.size();++i) {
            const auto& e=m.edges[i];const auto& p=m.primitives.at(e.pid);auto* a=new author::Primitive();
            a->id=p.id;a->start_theta=p.h;a->goal->i=p.dr;a->goal->j=p.dc;a->goal->theta=p.th;a->length=double(p.cost);a->accumulated_heading_change=0;
            for(auto d:p.trace)a->add_collision(d.r,d.c);
            controls.list_all_prims[p.id]=a;controls.prims_by_heading[p.h].push_back(p.id);
            if(!controls.prim_between_states.emplace(std::make_tuple(p.h,p.dr,p.dc,p.th),p.id).second)throw std::runtime_error("Author engine needs unique transitions");
            edge_by_pid[p.id]=int(i);
        }
        author::MeshInfo info;
        if(meshmode) {
            auto path=args.at("--model");auto at=path.rfind("_lattice.model");path.replace(at,14,"_mesh.model");Model mm(path);
            for(int h=0;h<mm.headings;++h)info.initial_config_by_theta[h]=h;
            for(int q=0;q<mm.Q;++q) {
                info.theta_by_initial_config[q]=mm.conf[q].initial;
                for(int ei:mm.out[q]){const auto& e=mm.edges[ei];info.successors[q].emplace_back(e.dr,e.dc,e.dst,e.pid);}
                for(auto [pid,k]:mm.conf[q].finals){const auto& p=mm.primitives.at(pid);auto d=p.trace[k];info.primitives_in_config[q].emplace_back(p.th,p.dr-d.r,p.dc-d.c,k,pid);}
            }
        }
        author::SearchAlgorithm solver(method,&map,&controls,meshmode?&info:nullptr,lazy,1.0,0.0,0,
            meshmode?ALGO_MESH_ASTAR:ALGO_LATTICE_ASTAR);
        double setup=std::chrono::duration<double,std::micro>(Clock::now()-setup0).count();
        std::cout<<"episode,cost,total_us,expanded,cell_checks,changes,setup_us,rss_kib\n";
        for(size_t ep=0;ep<work.steps.size();++ep) {
            auto t0=Clock::now();auto delta=change_grid(grid,work.steps[ep]);
            for(auto q:delta.opened)map.cells[q.r][q.c]=false;
            for(auto q:delta.blocked)map.cells[q.r][q.c]=true;
            auto s=work.steps[ep].start,t=work.goal;bool run=grid.free(s.r,s.c)&&grid.free(t.r,t.c);
            author::Vertex start(s.r,s.c,s.h),goal(t.r,t.c,t.h);
            if(run)solver.solve(&start,&goal);
            auto t1=Clock::now();Chain path;
            if(run&&solver.is_solved){path.cost=std::llround(solver.cost_path);path.states.push_back(graph.id(s));for(int pid:solver.path){int e=edge_by_pid.at(pid);path.edges.push_back(e);path.states.push_back(graph.head(path.states.back(),e));}}
            validate_chain(graph,path,graph.id(s),graph.id(t));
            struct rusage rss{};getrusage(RUSAGE_SELF,&rss);
            std::cout<<ep<<','<<(path.cost>=INF?-1:path.cost)<<','<<std::chrono::duration<double,std::micro>(t1-t0).count()<<','<<(run?solver.steps:0)<<','<<(run?solver.checked_cells:0)<<','<<delta.opened.size()+delta.blocked.size()<<','<<(ep==0?setup:0)<<','<<rss.ru_maxrss<<'\n';
            if(args.count("--dump")){std::cerr<<"PATH "<<ep;for(int edge:path.edges)std::cerr<<' '<<m.edges[edge].pid;std::cerr<<'\n';}
        }
    }catch(const std::exception& e){std::cerr<<"ERROR: "<<e.what()<<'\n';return 1;}
}
