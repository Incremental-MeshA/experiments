#!/usr/bin/env python3
"""Render the Russian paper using completed, checked experimental artifacts."""
from __future__ import annotations
import argparse
import json
import re
import subprocess
from pathlib import Path
import pandas as pd

ROOT=Path(__file__).resolve().parent


def escape_algorithm_stars(text):
    # Repeated algorithm asterisks otherwise become Markdown emphasis markers.
    return re.sub(r'(?<![\\\w])(MeshA|LBA|LPA|A|D)\*(?!\*)',r'\1\\*',text)


def md_table(columns,rows):
    return '| '+' | '.join(columns)+' |\n| '+' | '.join(['---']*len(columns))+' |\n'+'\n'.join(
        '| '+' | '.join(map(str,row))+' |' for row in rows)+'\n'


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--pdf',action='store_true');args=ap.parse_args()
    a=json.loads((ROOT/'results/analysis.json').read_text())
    if a['partial']:raise RuntimeError('Partial measurements cannot produce a final paper')
    if a['sequences']!=48 or a['timed_runs']!=1512 or a['snapshots']!=816:
        raise RuntimeError('This paper template describes the 48-sequence balanced design; completed counts do not match')
    v=json.loads((ROOT/'results/verification.json').read_text())
    sv=json.loads((ROOT/'results/verification_suffix.json').read_text())
    sx=json.loads((ROOT/'results/suffix_analysis.json').read_text())
    manifest=json.loads((ROOT/'data/manifest.json').read_text())
    summary=pd.read_csv(ROOT/'results/summary.csv').set_index('method')
    seq=pd.read_csv(ROOT/'results/sequence_metrics.csv')
    comparisons=json.loads((ROOT/'results/comparisons.json').read_text())
    env=json.loads((ROOT/'results/balanced/environment.json').read_text())
    labels={'lattice_astar':'Lattice A*','mesh_astar':'Mesh A*','cmesh_astar':'C-Mesh A*',
            'lattice_dlite':'Lattice D* Lite','mesh_dlite':'Mesh-D* Lite','cmesh_dlite':'C-Mesh-D* Lite',
            'lattice_dlite-cached':'Cached Lattice D* Lite','lattice_dlite-batch':'Boundary-Mesh-D* Lite',
            'lattice_lpa':'Lattice LPA*','mesh_lpa':'Mesh-LPA*','cmesh_lpa':'C-Mesh-LPA*',
            'lattice_lpa-cached':'Cached Lattice LPA*','lattice_lpa-batch':'Boundary-Mesh-LPA*'}
    def s(method):return summary.loc[method]
    def f(value):return f'{value:.2f}'
    def ci(method):return f'[{f(s(method).speedup_ci_lo)}; {f(s(method).speedup_ci_hi)}]'
    def from_comp(method,group,value):
        return next(x for x in comparisons[method][group] if x[group]==value)
    from analyze import paired,bootstrap
    p=paired(seq,'lattice_dlite-cached','lattice_dlite-batch');blo,bhi=bootstrap(p)
    bm=p.speedup.median();raw=s('mesh_dlite').median_speedup;compressed=s('cmesh_dlite').median_speedup
    abstract=(f'Медианное ускорение Mesh-D* Lite относительно обычного решёточного D* Lite равно {raw:.2f}×, '
              f'C-Mesh-D* Lite — {compressed:.2f}×. Для Boundary-Mesh относительно усиленного решёточного '
              f'бейзлайна с кешем получено {bm:.2f}× (95% ДИ [{blo:.2f}; {bhi:.2f}]).')
    sc=sx['comparisons']['cached_dlite'];sp=sx['comparisons']['prefix_dlite']
    abstract+=(f' В отдельной фазе из 432 запусков суффиксный mesh получил {sp["median_speedup"]:.2f}× '
               f'относительно префиксного и {sc["median_speedup"]:.2f}× относительно кешированного решёточного D* Lite.')
    suffix_results=(f'В дополнительной фазе выполнено {sx["timed_runs"]} запусков на тех же 48 последовательностях. '
                    'Prefix-Mesh-D* Lite и Cached Lattice D* Lite измерены заново, в случайном порядке вместе с '
                    'Suffix-Mesh-D* Lite внутри каждого из трёх повторений. Поэтому сравнение направления не зависит '
                    'только от результатов другой временной фазы.\n\n'+
                    md_table(['Бейзлайн отдельной фазы','Ускорение Suffix-Mesh','95% ДИ','Доля выигрышей'],
                             [['Prefix-Mesh-D* Lite',f(sp['median_speedup']),f'[{f(sp["ci"][0])}; {f(sp["ci"][1])}]',f(sp['win_pct'])+'%'],
                              ['Cached Lattice D* Lite',f(sc['median_speedup']),f'[{f(sc["ci"][0])}; {f(sc["ci"][1])}]',f(sc['win_pct'])+'%']]))
    suffix_results+=(f'\nМедианные пики RSS в этой фазе: Prefix-Mesh {sx["median_rss_mib"]["prefix_dlite"]:.2f} МиБ, '
                     f'Suffix-Mesh {sx["median_rss_mib"]["suffix_dlite"]:.2f} МиБ, Cached Lattice '
                     f'{sx["median_rss_mib"]["cached_dlite"]:.2f} МиБ. Смена направления объединения не устраняет '
                     'саму необходимость хранить внутренние метки; этот эффект отделён от полного исключения состояний в Boundary-Mesh.')
    modelrows=[]
    for control in ['base','add']:
        desc=manifest['control_sets'][control]
        prims=json.loads((ROOT/f'data/{control}_primitives.json').read_text())
        union=len({(p['heading'],*t) for p in prims for t in p['trace']})
        for kind in ['lattice','mesh','cmesh']:
            d=desc['graphs'][kind];modelrows.append([control,kind,d['configurations'],d['edges'],d['dependency_entries']])
        modelrows.append([control,'Boundary-Mesh',16,len(prims),union])
    models=md_table(['Набор','Представление','Конфигурации','Рёбра','Записи индекса'],modelrows)
    selected=['lattice_astar','mesh_astar','lattice_dlite','mesh_dlite','cmesh_dlite','lattice_dlite-cached','lattice_dlite-batch']
    rows=[]
    for method in selected:
        t=s(method);rows.append([labels[method],f(t.median_speedup),ci(method),f(t.p95_update_ms),f(t.median_rss_mib)])
    mainresults=('В таблице приведены 48 одинаковых последовательностей для всех строк. Ускорение — медиана парных '
                 'отношений суммарного времени перепланирования к обычному Lattice D* Lite; больше единицы — быстрее. '
                 'p95 относится к отдельному обновлению, RSS — к пику процесса.\n\n'+
                 md_table(['Метод','Ускорение','95% ДИ','p95, мс','RSS, МиБ'],rows))
    cm=comparisons['cmesh_vs_cached'];ca=comparisons['cmesh_vs_astar']
    cb=from_comp('cmesh_dlite','control','base');cs=from_comp('cmesh_dlite','control','add')
    mainresults+=(f'\n**Сжатие даёт выигрыш внутри инкрементального поиска.** C-Mesh-D* Lite относительно обычного '
                  f'Lattice D* Lite получил {compressed:.2f}×, 95% ДИ {ci("cmesh_dlite")}; относительно кешированной '
                  f'решётки — {cm["median"]:.2f}×, 95% ДИ [{cm["ci"][0]:.2f}; {cm["ci"][1]:.2f}]. '
                  f'Эффект зависит от control set: при 24 примитивах на направление (`base`) — {cb["speedup"]:.2f}× '
                  f'относительно кеша, а при 7 (`add`) — {cs["speedup"]:.2f}×. По всей выборке сжатие выигрывает '
                  f'у кешированной решётки в {cm["win_pct"]:.1f}% последовательностей. Медианный пик RSS '
                  f'C-Mesh равен {s("cmesh_dlite").median_rss_mib:.2f} МиБ, обычного Lattice D* Lite — '
                  f'{s("lattice_dlite").median_rss_mib:.2f} МиБ.\n\n'
                  f'**Ремонт не доминирует над перезапуском.** Повторный Lattice A* относительно обычного D* Lite '
                  f'получил {s("lattice_astar").median_speedup:.2f}×, 95% ДИ {ci("lattice_astar")}. '
                  f'C-Mesh-D* Lite относительно повторного Lattice A* имеет {ca["median"]:.2f}× '
                  f'(95% ДИ [{ca["ci"][0]:.2f}; {ca["ci"][1]:.2f}]); доля выигрышей — {ca["win_pct"]:.1f}%. '
                  'Поэтому выигрыш от сжатия относительно D* Lite не означает, что этот вариант следует выбирать для каждой задачи.\n')
    rawratio=1/raw if raw<1 else raw
    rawinterpret=(f'Прямой Mesh-D* Lite медленнее обычного D* Lite на решётке по медиане парных времён в {rawratio:.2f} раза.'
                  if raw<1 else f'Прямой Mesh-D* Lite быстрее обычного D* Lite на решётке по медиане парных времён в {rawratio:.2f} раза.')
    memratio=s('mesh_dlite').median_rss_mib/s('lattice_dlite-batch').median_rss_mib
    mainresults+=('\n'+rawinterpret+' Положительная стоимость рёбер обеспечивает корректность ремонта, но сама по себе '
                  'не устраняет рост числа меток. Сжатие цепочек и полный переход на границу примитивов адресуют разные '
                  f'части этой цены. Отношение медианных пиков RSS прямого Mesh-D* Lite и Boundary-Mesh равно {memratio:.2f}.\n\n'
                  f'Boundary-Mesh относительно кешированного Lattice D* Lite имеет медиану парных ускорений {bm:.2f}× '
                  f'с 95% ДИ [{blo:.2f}; {bhi:.2f}]. ')
    if blo>1:
        mainresults+='Интервал целиком выше единицы на данной выборке; это поддерживает преимущество данной реализации в выбранном плане.'
    elif bhi<1:
        mainresults+='Интервал целиком ниже единицы: усиленный решёточный бейзлайн быстрее на данной выборке.'
    else:
        mainresults+='Интервал пересекает единицу; уверенного общего преимущества над усиленным бейзлайном эти данные не устанавливают.'
    maxmethod=summary.max_rss_mib.idxmax();maxrow=s(maxmethod)
    mainresults+=(f'\n\nНаибольший измеренный пик RSS среди всех основных запусков — {maxrow.max_rss_mib:.2f} МиБ '
                  f'у {labels[maxmethod]}; максимальное число материализованных меток этого метода — '
                  f'{int(maxrow.max_records):,}.')
    group_rows=[]
    for name in ['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown']:
        item=from_comp('lattice_dlite-batch','map',name)
        group_rows.append([name,item['n'],f(item['speedup']),f'[{f(item["ci"][0])}; {f(item["ci"][1])}]'])
    groupresults=('Сравнение Boundary-Mesh с точечным решёточным кешем по картам показывает неоднородность эффекта:\n\n'+
                  md_table(['Карта','Задач','Ускорение / cached D*','95% ДИ'],group_rows))
    facts=[]
    for pattern in ['local','path','churn']:
        item=from_comp('lattice_dlite-batch','pattern',pattern);facts.append(f'`{pattern}` — {item["speedup"]:.2f}×')
    groupresults+='\nПо типам изменений медианы составили '+', '.join(facts)+'. Это описательное сравнение разных сбалансированных задач, а не изолированный причинный эффект размера пакета.'
    controls=[from_comp('lattice_dlite-batch','control',c) for c in ['base','add']]
    modes=[from_comp('lattice_dlite-batch','mode',m) for m in ['fixed','moving']]
    groupresults+=(f' Для набора `base` медиана равна {controls[0]["speedup"]:.2f}×, для `add` — '
                   f'{controls[1]["speedup"]:.2f}×; при фиксированном старте — {modes[0]["speedup"]:.2f}×, '
                   f'при движущемся — {modes[1]["speedup"]:.2f}×.')
    lpa=comparisons['boundary_lpa_vs_cached_lpa']
    groupresults+=(f' На 24 задачах с фиксированным стартом Boundary-Mesh-LPA* относительно Cached Lattice LPA* '
                   f'дал {lpa["median"]:.2f}× (95% ДИ [{lpa["ci"][0]:.2f}; {lpa["ci"][1]:.2f}]).')
    amort=[]
    for method in ['lattice_dlite','mesh_dlite','cmesh_dlite','lattice_dlite-cached','lattice_dlite-batch']:
        t=s(method);amort.append([labels[method],f(t.initial_ms),f(t.setup_ms),f(t.median_amortized_speedup)])
    amortization=('Ускорение только ремонта не включает первоначальное построение поисковых меток. В следующей таблице '
                  'амортизированное ускорение включает исходный запрос и все 16 обновлений, но исключает загрузку модели. '
                  'Настройка процесса и моделей показана отдельно.\n\n'+
                  md_table(['Метод','Первый поиск, мс','Настройка, мс','Аморт. ускорение / D*'],amort))
    # Report the relation to restarting A* rather than implying incremental is always better.
    astarpair=paired(seq,'lattice_astar','lattice_dlite-batch');alo,ahi=bootstrap(astarpair)
    amortization+=(f'\nДля Boundary-Mesh-D* Lite медиана парных ускорений 16 обновлений относительно повторного '
                   f'Lattice A* равна {astarpair.speedup.median():.2f}× (95% ДИ [{alo:.2f}; {ahi:.2f}]); '
                   f'выигрыш по суммарному ремонту наблюдается в {100*(astarpair.speedup>1).mean():.1f}% последовательностей. '
                   'Этот результат важен для выбора между ремонтом и перезапуском на конкретной карте.')
    allrows=[]
    for method,t in summary.iterrows():
        allrows.append([labels[method],int(t.sequences),f(t.median_speedup),ci(method),f(t.speedup_vs_cached),f(t.median_rss_mib)])
    allmethods=md_table(['Метод','N','Ускорение / D*','95% ДИ','/ cached D*','RSS, МиБ'],allrows)
    conclusion=(f'В выполненной оценке C-Mesh-D* Lite получил {compressed:.2f}× относительно обычного решёточного D* Lite '
                f'и {cm["median"]:.2f}× относительно его кешированной версии; прямой Mesh-D* Lite — {raw:.2f}× '
                'относительно обычного D* Lite. '
                f'Boundary-Mesh получил {bm:.2f}× относительно кешированной версии. ')
    conclusion+=('Данные поддерживают преимущество Boundary-Mesh в выбранном плане, но не универсальную доминацию.' if blo>1 else
                 'Данные показывают, что корректность переноса и экономия collision checks не гарантируют выигрыша во времени над сильным решёточным бейзлайном.')
    conclusion+=(f' Суффиксное объединение изменило время относительно префиксного mesh с медианой ускорения '
                 f'{sp["median_speedup"]:.2f}×, а относительно кешированной решётки — {sc["median_speedup"]:.2f}×.')
    conclusion+=(f' Повторный Lattice A* остаётся сильным практическим выбором: его медианное ускорение '
                 f'относительно обычного D* Lite составило {s("lattice_astar").median_speedup:.2f}×.')
    vals={'VERIFY_QUERIES':v['differential_queries']+sv['differential_queries'],
          'HEURISTIC_CHECKS':v['heuristic_edge_checks']+sv['heuristic_edge_checks'],
          'SEQUENCES':a['sequences'],'SNAPSHOTS':a['snapshots'],'RUNS':a['timed_runs'],
          'INFEASIBLE':a['infeasible_snapshots'],'COMPILER':env['compiler'].split(' ')[-1],
          'ABSTRACT_RESULT':abstract,'MODEL_TABLE':models,'MAIN_RESULTS':mainresults,'GROUP_RESULTS':groupresults,
          'AMORTIZATION_RESULTS':amortization,'CONCLUSION_RESULT':conclusion,'ALL_METHODS_TABLE':allmethods,
          'SUFFIX_RESULTS':suffix_results,'ZERO_COST':a['zero_cost_snapshots'],
          'ZERO_COST_TEXT':('Эпизодов с нулевой стоимостью в основном плане не было.' if a['zero_cost_snapshots']==0 else
                            f'Эпизодов с нулевой стоимостью — {a["zero_cost_snapshots"]}; они включены в основной показатель.'),
          'ACTUAL_CHANGES':', '.join(f'{k}: {val:.1f}' for k,val in a['actual_change_medians'].items()),
          'ORACLE_SNAPSHOTS':v['oracle_snapshots']}
    text=(ROOT/'paper/article_template.md').read_text()
    for k,value in vals.items():text=text.replace('@@'+k+'@@',str(value))
    assert not re.search(r'@@[A-Z_]+@@',text),'Unfilled placeholder'
    front=text.split('---',2)
    text='---'.join(front[:2]+[escape_algorithm_stars(front[2])])
    dest=ROOT/'paper/article_ru.md';dest.write_text(text)
    # A short standalone Russian result for navigation, with measured values.
    report=(f'# Результат\n\nСтатья: [article_ru.pdf](../paper/article_ru.pdf), '
            f'[исходник](../paper/article_ru.md).\n\nВ основной фазе выполнено {a["timed_runs"]} запусков на {a["sequences"]} '
            f'последовательностях в 24 seed-блоках; {a["snapshots"]} разных снимков, шесть карт, два набора примитивов. '
            f'В дополнительной фазе — {sx["timed_runs"]} запуска; всего {a["timed_runs"]+sx["timed_runs"]}. '
            f'Все стоимости совпали. Независимый оракул: {v["differential_queries"]+sv["differential_queries"]} сравнений '
            f'на {v["oracle_snapshots"]} снимках.\n\n'
            +abstract+'\n\n'+conclusion+'\n\n'+mainresults+'\n')
    (ROOT/'results/REPORT_RU.md').write_text(escape_algorithm_stars(report))
    print(dest)
    if args.pdf:
        cmd=['pandoc',str(dest),'-o',str(ROOT/'paper/article_ru.pdf'),'--pdf-engine=xelatex',
             '--resource-path',str(ROOT),'-V','mainfont=Noto Serif','-V','sansfont=Noto Sans',
             '-V','monofont=DejaVu Sans Mono','-V','geometry:margin=20mm','-V','fontsize=10pt',
             '-V','papersize=a4','-V','colorlinks=true','--highlight-style=tango',
             '--include-in-header',str(ROOT/'paper/layout.tex')]
        subprocess.run(cmd,check=True,cwd=ROOT)
        print(ROOT/'paper/article_ru.pdf')
        texcmd=cmd[:];texcmd[texcmd.index('-o')+1]=str(ROOT/'paper/article_ru.tex');texcmd.append('--standalone')
        subprocess.run(texcmd,check=True,cwd=ROOT)
        print(ROOT/'paper/article_ru.tex')


if __name__=='__main__':main()
