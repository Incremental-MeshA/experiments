#!/usr/bin/env python3
"""Analytical locality/scaling probe, separate from the 60-map workload cohort."""
import csv
import io
import json
import platform
import random
import subprocess
import time
from pathlib import Path
from benchmark_repair import ROOT, command, digest

OUT=ROOT/'results/repair/mechanism'
METHODS=['fresh','fresh-mesh','fresh-backward','mfr','mdf','csb','gaa-plain','msp']


def prepare():
    OUT.mkdir(exist_ok=True)
    jobs=[];reference=[]
    for width in [160,320,640]:
        for position,fraction in [('head',1/8),('tail',7/8)]:
            mapname=f'repair_post{width}_{position}'
            height=80;row=40;left=16;right=width-17;column=left+round((right-left)*fraction)
            mp=ROOT/'maps'/f'{mapname}.map'
            grid=['@'*width]+['@'+'.'*(width-2)+'@' for _ in range(height-2)]+['@'*width]
            mp.write_text(f'type octile\nheight {height}\nwidth {width}\nmap\n'+'\n'.join(grid)+'\n')
            for control in ['base','add']:
                name=f'{mapname}__{control}__fixed__post__5';work=ROOT/'workloads'/f'{name}.work'
                lines=[str(mp),f'{row} {left} 0 {row} {right} 0',f'{row} {left} 0 0']
                for ep in range(1,17):
                    lines.append(f'{row} {left} 0 13')
                    lines.extend(f'{r} {column} {ep%2}' for r in range(row-6,row+7))
                work.write_text('\n'.join(lines)+'\n')
                job=dict(name=name,control=control,width=width,position=position,post_column=column,
                         workload_sha256=digest(work));jobs.append(job)
                run=subprocess.run(command(job,'fresh')+['--dump'],check=True,text=True,capture_output=True,timeout=240)
                rows=list(csv.DictReader(io.StringIO(run.stdout)))
                check=subprocess.run(command(job,'lattice-astar'),check=True,text=True,capture_output=True,timeout=240)
                assert [r['cost'] for r in rows]==[r['cost'] for r in csv.DictReader(io.StringIO(check.stdout))]
                (OUT/f'{name}.paths').write_text(run.stderr)
                for r in rows:
                    cost=int(r['cost']);old=int(r['previous_suffix_cost']);ep=int(r['episode'])
                    category='initial' if ep==0 else ('increase_finite' if cost>old>=0 else 'improvement' if 0<=cost<old else 'other')
                    reference.append(dict(name=name,episode=ep,cost=cost,category=category))
    (OUT/'cohorts.json').write_text(json.dumps(jobs,indent=2)+'\n')
    with (OUT/'reference.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=reference[0],lineterminator='\n');w.writeheader();w.writerows(reference)
    print('Prepared locality probe:',len(jobs),'sequences,',sum(r['category']=='increase_finite' for r in reference),'finite forced repairs',flush=True)


def run():
    jobs=json.loads((OUT/'cohorts.json').read_text());rng=random.Random(55071);rng.shuffle(jobs)
    raw=OUT/'raw';raw.mkdir(exist_ok=True)
    env=dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),platform=platform.platform(),
             sha256={'repair':digest(ROOT/'bin/repair_v1'),'ima':digest(ROOT/'bin/ima'),
                     'repair.cpp':digest(ROOT/'frozen/v1/repair.cpp')},
             methods=METHODS,note='Sequential processes; geometry fixed by width and post position, never candidate speed. Mechanism probe, not held-out evidence.')
    ep=OUT/'environment.json'
    if ep.exists():assert json.loads(ep.read_text())['sha256']==env['sha256']
    else:ep.write_text(json.dumps(env,indent=2)+'\n')
    expected={}
    for r in csv.DictReader((OUT/'reference.csv').open()):expected.setdefault(r['name'],[]).append(int(r['cost']))
    start=time.monotonic();done=0
    for job in jobs:
        assert digest(ROOT/'workloads'/f'{job["name"]}.work')==job['workload_sha256']
        for rep in range(3):
            order=METHODS[:];rng.shuffle(order)
            for method in order:
                dst=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not dst.exists():
                    r=subprocess.run(command(job,method),check=True,text=True,capture_output=True,timeout=240)
                    rows=list(csv.DictReader(io.StringIO(r.stdout)))
                    assert [int(x['cost']) for x in rows]==expected[job['name']],(job['name'],method)
                    dst.write_text(r.stdout)
                done+=1
        print(done,'runs;',round(time.monotonic()-start,1),'seconds;',job['name'],flush=True)
    (OUT/'completion.json').write_text(json.dumps(dict(status='passed',runs=done,queries=done*17,cost_disagreements=0),indent=2)+'\n')


def analyze():
    import numpy as np
    import pandas as pd
    jobs=pd.DataFrame(json.loads((OUT/'cohorts.json').read_text())).set_index('name')
    ref=pd.read_csv(OUT/'reference.csv')
    frames=[]
    for p in sorted((OUT/'raw').glob('*.csv')):
        name,method,rep=p.stem.rsplit('__',2)
        d=pd.read_csv(p);d['name']=name;d['method']=method;d['repeat']=int(rep[1:]);frames.append(d)
    raw=pd.concat(frames).merge(ref[['name','episode','category']],on=['name','episode'])
    records=[]
    for (name,method,rep),d in raw.groupby(['name','method','repeat']):
        records.append(dict(name=name,method=method,repeat=rep,online_us=d.loc[d.episode>0,'total_us'].sum(),
                            repair_us=d.loc[d.category=='increase_finite','total_us'].sum(),
                            all_us=d.total_us.sum(),amortized_us=d.total_us.sum()+d.setup_us.sum(),
                            repair_expanded=d.loc[d.category=='increase_finite','expanded'].sum(),rss_mib=d.rss_kib.max()/1024))
    seq=pd.DataFrame(records).groupby(['name','method']).median(numeric_only=True).reset_index().merge(jobs.reset_index(),on='name')
    seq.to_csv(OUT/'sequence_metrics.csv',index=False)
    result=dict(sequences=len(jobs),snapshots=len(ref),categories=ref.category.value_counts().to_dict(),methods={},strata={})
    for method in METHODS:
        result['methods'][method]={}
        for metric in ['online_us','repair_us','all_us','amortized_us']:
            p=seq.pivot(index='name',columns='method',values=metric)
            r=p[['fresh','fresh-mesh','fresh-backward']].min(axis=1)/p[method]
            result['methods'][method][metric]=dict(median=float(r.median()),wins=int((r>1).sum()),n=len(r))
        result['strata'][method]={}
        for (width,position),group in seq[seq.method==method].groupby(['width','position']):
            names=group.name;p=seq[seq.name.isin(names)].pivot(index='name',columns='method',values='repair_us')
            r=p[['fresh','fresh-mesh','fresh-backward']].min(axis=1)/p[method]
            result['strata'][method][f'{width}_{position}']=dict(median=float(r.median()),n=len(r))
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(1,2,figsize=(8,3.3),constrained_layout=True)
    for ax,position in zip(axes,['head','tail']):
        for method in ['mdf','mfr','csb']:
            ax.plot([160,320,640],[result['strata'][method][f'{w}_{position}']['median'] for w in [160,320,640]],'o-',label=method)
        ax.axhline(1,color='black',lw=.8);ax.set_yscale('log');ax.set_xticks([160,320,640]);ax.set_xlabel('Map width, cells');ax.set_title('Post near '+('start' if position=='head' else 'goal'))
    axes[0].set_ylabel('Forced repair speedup vs best fresh A*');axes[1].legend()
    fig.savefig(OUT/'scaling.pdf');fig.savefig(OUT/'scaling.png',dpi=180);plt.close(fig)


if __name__=='__main__':
    import argparse
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','run','analyze'],required=True);a=p.parse_args()
    {'prepare':prepare,'run':run,'analyze':analyze}[a.stage]()
