#!/usr/bin/env python3
"""Create a portable, hashed research bundle; exclude unrelated older results."""
import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ARCHIVE=ROOT.parent/'mesh_deferred_astar_artifact.zip'

def included(p):
    rel=p.relative_to(ROOT);parts=rel.parts
    if any(x in {'.git','__pycache__'} for x in parts) or p.suffix=='.pyc':return False
    if parts[0]=='bin':return p.name in ['mesh_deferred','mc_adaptive','mpgaa_bbox','certified_v1','ima','repair','author_baseline']
    if parts[0]=='results':
        if parts[1]=='deferred':return p.name!='artifact_validation.json'
        if parts[1]=='certified':return len(parts)==3 and p.name in ['cohorts.json','reference.csv','design.json','verification.json','author_verification.json']
        return False
    if parts[0]=='paper':return p.name in ['mesh_deferred_ru.md','mesh_deferred_ru.tex','mesh_deferred_ru.pdf','md_method_ru.md','layout.tex']
    if parts[0]=='tests':return p.suffix in ['.py','.work','.map']
    if parts[0] in ['src','data','maps','workloads','frozen','third_party']:return True
    return len(parts)==1 and (p.suffix in ['.py','.txt'] or p.name in ['Makefile','README.md','README_MD_ASTAR_RU.md','LICENSE','.gitignore'])

def main():
    files=[p for p in ROOT.rglob('*') if p.is_file() and included(p)]
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
    with zipfile.ZipFile(ARCHIVE,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(files):z.write(p,'mesh_deferred_astar/'+str(p.relative_to(ROOT)))
        z.writestr('mesh_deferred_astar/ARTIFACT_MANIFEST_SHA256.json',json.dumps(manifest,indent=2)+'\n')
    print(json.dumps(dict(archive=str(ARCHIVE),files=len(files),bytes=ARCHIVE.stat().st_size,sha256=hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()),indent=2))
if __name__=='__main__':main()
