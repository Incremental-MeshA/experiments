#!/usr/bin/env python3
"""Paired sequence statistics; repeats and episodes are not independent trials."""
import argparse
import csv
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/repair'
FRESH=['fresh','fresh-mesh','fresh-backward']
METRICS=['online_us','all_us','amortized_us','repair_us','broken_us','initial_us']


def analyze(label):
    cohort=pd.DataFrame(json.loads((OUT/'cohorts.json').read_text())).set_index('name')
    reference=pd.read_csv(OUT/'reference.csv').set_index(['name','episode'])
    frames=[]
    for p in sorted((OUT/label).glob('*.csv')):
        name,method,rep=p.stem.rsplit('__',2)
        d=pd.read_csv(p);d['name']=name;d['method']=method;d['repeat']=int(rep[1:]);frames.append(d)
    raw=pd.concat(frames,ignore_index=True).merge(reference.reset_index()[['name','episode','category']],on=['name','episode'],validate='many_to_one')
    records=[]
    for (name,method,rep),d in raw.groupby(['name','method','repeat']):
        def total(mask,col='total_us'):
            sub=d.loc[mask,col];return sub.sum() if len(sub) else np.nan
        rec=dict(name=name,method=method,repeat=rep,online_us=total(d.episode>0),
                 all_us=d.total_us.sum(),amortized_us=d.total_us.sum()+d.setup_us.sum(),
                 repair_us=total(d.category=='increase_finite'),
                 broken_us=total(d.category.isin(['increase_finite','unchanged_broken','disconnected'])),
                 initial_us=total(d.episode==0),rss_mib=d.rss_kib.max()/1024,
                 online_expanded=total(d.episode>0,'expanded'),repair_expanded=total(d.category=='increase_finite','expanded'),
                 certified=d.loc[d.episode>0,'certified'].sum() if 'certified' in d else 0,
                 potential_us=d.potential_us.sum() if 'potential_us' in d else 0)
        records.append(rec)
    run=pd.DataFrame(records)
    seq=run.groupby(['name','method']).median(numeric_only=True).reset_index().drop(columns='repeat')
    seq=seq.merge(cohort.reset_index(),on='name',validate='many_to_one')
    seq.to_csv(OUT/'sequence_metrics.csv',index=False)
    names=cohort.index[cohort.cohort=='original'].to_list()
    blocks={(m,s):[i for i,n in enumerate(names) if cohort.loc[n,'map']==m and cohort.loc[n,'seed']==s]
            for m in cohort['map'].unique() for s in range(4)}
    rng=np.random.default_rng(19082026)
    samples=[]
    for _ in range(6000):
        ids=[]
        for m in cohort['map'].unique():
            for s in rng.integers(0,4,4):ids.extend(blocks[m,int(s)])
        samples.append(ids)
    samples=np.array(samples)

    def compare(method,baseline='best-fresh',metric='online_us',part='original',selection=None):
        p=seq.pivot(index='name',columns='method',values=metric)
        if baseline=='best-fresh':base=p[FRESH].min(axis=1)
        else:base=p[baseline]
        ratio=(base/p[method]).rename('speedup').to_frame().join(cohort[['cohort','map','control','mode','pattern','seed']])
        ratio=ratio[ratio.cohort==part]
        if selection:
            key,value=selection;ratio=ratio[ratio[key]==value]
        ratio=ratio.dropna(subset=['speedup'])
        vals=ratio.speedup
        if not len(vals):return dict(n=0)
        ci=None
        if part=='original' and selection is None:
            x=ratio.speedup.reindex(names).to_numpy()
            med=np.nanmedian(x[samples],axis=1)
            ci=np.nanpercentile(med,[2.5,97.5]).tolist()
        return dict(n=len(vals),median=float(vals.median()),ci=ci,wins=int((vals>1).sum()),
                    win_pct=float(100*(vals>1).mean()),q25=float(vals.quantile(.25)),q75=float(vals.quantile(.75)),
                    min=float(vals.min()),max=float(vals.max()))

    methods=sorted(seq.method.unique())
    result=dict(label=label,sequences=len(cohort),runs=len(run),queries=len(raw),snapshots=len(reference),
                original_snapshots=int((reference.cohort=='original').sum()),
                categories={part:reference[reference.cohort==part].category.value_counts().to_dict() for part in ['original','heldout']},
                note='Speedup = baseline/candidate. Median of per-sequence ratios of median repeated sequence totals. Best-fresh selects the fastest of three fresh policies separately per sequence and metric. 95% percentile CI: 6000 seed-block resamples within each of six fixed maps; no independent-episode assumption.',
                methods={},comparisons={})
    for method in methods:
        info={part:{metric:compare(method,metric=metric,part=part) for metric in METRICS} for part in ['original','heldout']}
        original=seq[(seq.method==method)&(seq.cohort=='original')]
        ep=raw[(raw.method==method)&(raw.episode>0)&raw.name.isin(names)].groupby(['name','episode']).median(numeric_only=True)
        info['median_rss_mib']=float(original.rss_mib.median())
        info['p95_online_ms']=float(ep.total_us.quantile(.95)/1000)
        info['certified_fraction']=float(original.certified.sum()/(48*16))
        info['potential_fraction']=float(original.potential_us.sum()/original.all_us.sum())
        info['strata']={key:{str(v):compare(method,selection=(key,v)) for v in cohort[key].unique()} for key in ['map','control','mode','pattern']}
        info['strata_repair']={key:{str(v):compare(method,metric='repair_us',selection=(key,v)) for v in cohort[key].unique()} for key in ['map','control','mode','pattern']}
        result['methods'][method]=info
    for method in ['mdf','mfr','csb','msp']:
        result['comparisons'][method]={b:{metric:compare(method,b,metric) for metric in METRICS}
               for b in ['gaa','gaa-plain','msp','bridge-eager','forest','cached-dlite','cmesh-dlite','lattice-dlite','fresh','fresh-backward']}
    result['cohort_rss']={part:seq[seq.cohort==part].groupby('method').rss_mib.median().to_dict() for part in ['original','heldout']}
    # Expansion counts and query-level distributions are descriptive only.
    result['repair_expansions']=seq[seq.cohort=='original'].groupby('method').repair_expanded.sum().to_dict()
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    summary=[]
    for m in methods:
        z=result['methods'][m]
        summary.append(dict(method=m,online=z['original']['online_us']['median'],
                            repair=z['original']['repair_us']['median'],all=z['original']['all_us']['median'],
                            setup_included=z['original']['amortized_us']['median'],
                            heldout=z['heldout']['online_us']['median'],heldout_repair=z['heldout']['repair_us']['median'],
                            rss_mib=z['median_rss_mib'],certified=z['certified_fraction']))
    pd.DataFrame(summary).to_csv(OUT/'summary.csv',index=False)
    print(pd.DataFrame(summary).round(3).to_string(index=False))
    print(json.dumps(result['categories'],indent=2))
    return result,seq,raw


def plots(result,seq):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    dst=ROOT/'figures/repair';dst.mkdir(parents=True,exist_ok=True)
    selected=['lattice-dlite','cached-dlite','cmesh-dlite','gaa-plain','msp','csb','mdf','mfr']
    fig,axes=plt.subplots(1,2,figsize=(9.0,3.5),constrained_layout=True)
    for ax,metric,title in zip(axes,['online_us','repair_us'],['All replanning queries','Forced finite repairs']):
        vals=[result['methods'][m]['original'][metric]['median'] for m in selected]
        ci=[result['methods'][m]['original'][metric]['ci'] for m in selected]
        y=np.arange(len(selected));ax.scatter(vals,y,c=['#888888']*3+['#6c91b6']*4+['#c1572c'],s=30,zorder=3)
        ax.hlines(y,[x[0] for x in ci],[x[1] for x in ci],color='black')
        ax.set_yticks(y,selected);ax.invert_yaxis();ax.axvline(1,c='black',lw=.8);ax.set_xscale('log');ax.set_title(title);ax.set_xlabel('Speedup vs best fresh A* (log scale)')
        low=.8*min(x[0] for x in ci);high=1.2*max(1,max(x[1] for x in ci))
        ticks=[x for x in [.05,.1,.2,.5,1,2,5,10] if low<=x<=high]
        ax.set_xticks(ticks,[f'{x:g}' for x in ticks]);ax.xaxis.set_minor_formatter(ticker.NullFormatter());ax.set_xlim(low,high)
    fig.savefig(dst/'speedups.pdf');fig.savefig(dst/'speedups.png',dpi=180);plt.close(fig)
    fig,ax=plt.subplots(figsize=(7.8,3.4),constrained_layout=True)
    names=['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown']
    x=np.arange(6);width=.24
    for k,m in enumerate(['mdf','mfr','csb']):
        vals=[result['methods'][m]['strata']['map'][n]['median'] for n in names]
        ax.bar(x+(k-1)*width,vals,width,label=m)
    ax.axhline(1,c='black',lw=.8);ax.set_yscale('log');ax.set_ylabel('Replanning speedup (log scale)');ax.set_xticks(x,names,rotation=15,ha='right');ax.legend(ncol=3)
    fig.savefig(dst/'maps.pdf');fig.savefig(dst/'maps.png',dpi=180);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--label',default='raw');p.add_argument('--plots',action='store_true');args=p.parse_args()
    a,s,r=analyze(args.label)
    if args.plots:plots(a,s)
