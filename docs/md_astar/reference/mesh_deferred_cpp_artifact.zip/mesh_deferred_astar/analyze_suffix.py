#!/usr/bin/env python3
"""Paired analysis of the separately randomized direction ablation."""
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from analyze import ROOT,KEY,load,paired,bootstrap


def main():
    plt.rcParams.update({'font.size':12})
    df=load(ROOT/'results/suffix')
    assert df.groupby(KEY+['episode']).cost.nunique().max()==1
    assert df.groupby(KEY+['method','repeat']).ngroups==432
    r=df[df.episode>0].groupby(KEY+['method','repeat']).agg(
        repair_us=('total_us','sum'),rss_kib=('rss_kib','max'),records=('records','max'),
        cell_checks=('cell_checks','sum'),expanded=('expanded','sum')).reset_index()
    total=df.groupby(KEY+['method','repeat']).total_us.sum().rename('all_us').reset_index()
    r=r.merge(total,on=KEY+['method','repeat']);r['rss_mib']=r.rss_kib/1024
    seq=r.groupby(KEY+['method']).median(numeric_only=True).reset_index()
    seq.to_csv(ROOT/'results/suffix_sequence_metrics.csv',index=False)
    comparisons={}
    for ref in ['prefix_dlite','cached_dlite']:
        p=paired(seq,ref,'suffix_dlite');lo,hi=bootstrap(p)
        comparisons[ref]=dict(n=len(p),median_speedup=float(p.speedup.median()),ci=[lo,hi],
                              win_pct=float(100*(p.speedup>1).mean()),
                              by_map={m:float(g.speedup.median()) for m,g in p.groupby('map')})
    out=dict(timed_runs=432,timed_queries=len(df),snapshots=df.groupby(KEY+['episode']).ngroups,
             comparisons=comparisons,median_rss_mib={m:float(g.rss_mib.median()) for m,g in seq.groupby('method')})
    (ROOT/'results/suffix_analysis.json').write_text(json.dumps(out,indent=2)+'\n')
    maps=sorted(seq['map'].unique());fig,ax=plt.subplots(figsize=(9,3.7));x=np.arange(len(maps))
    for j,(ref,color,label) in enumerate([('prefix_dlite','#35749c','vs prefix Mesh D* Lite'),
                                         ('cached_dlite','#2b8b66','vs cached lattice D* Lite')]):
        vals=[comparisons[ref]['by_map'][m] for m in maps]
        ax.plot(x+(j-.5)*.24,vals,'o',markersize=7,color=color,label=label)
    ax.set_yscale('log');ax.axhline(1,color='#333',ls='--',lw=1)
    ax.set_xticks(x,maps,rotation=20,ha='right');ax.set_ylabel('Suffix-Mesh repair speedup');ax.legend(fontsize=10)
    ax.spines[['top','right']].set_visible(False);fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(ROOT/f'paper/figures/suffix.{ext}',dpi=240,bbox_inches='tight')
    print(json.dumps(out,indent=2))


if __name__=='__main__':main()
