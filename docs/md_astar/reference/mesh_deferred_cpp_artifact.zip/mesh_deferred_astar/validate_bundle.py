#!/usr/bin/env python3
"""Check archive CRC and run both packaged binaries after relocating their map."""
import argparse
import csv
import io
import json
import os
import subprocess
import tempfile
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--archive',type=Path,default=ROOT.parent/'incremental_mesh_astar_artifact.zip');args=ap.parse_args()
    with zipfile.ZipFile(args.archive) as z:
        assert z.testzip() is None,'Archive CRC failure'
        for name in z.namelist():
            p=Path(name);assert not p.is_absolute() and '..' not in p.parts
        with tempfile.TemporaryDirectory(prefix='ima_artifact_') as tmp:
            z.extractall(tmp);product=Path(tmp)/ROOT.name
            work=product/'workloads/warehouse__add__moving__local__0.work'
            lines=work.read_text().splitlines()
            # Force the loader to use the map in the relocated artifact, even
            # when the original reference clone exists on this computer.
            lines[0]='/nonexistent_reference_clone/warehouse.map'
            smoke=product/'workloads/portable_smoke.work';smoke.write_text('\n'.join(lines[:3])+'\n')
            with (product/'results/balanced/warehouse__add__moving__local__0__lattice_astar__r0.csv').open() as f:
                expected=int(next(csv.DictReader(f))['cost'])
            costs={}
            for binary,model,algo in [('ima','lattice','astar'),('ima_suffix','suffix','dlite')]:
                executable=product/f'bin/{binary}';os.chmod(executable,0o755)
                run=subprocess.run([str(executable),'--model',str(product/f'data/add_{model}.model'),
                                    '--workload',str(smoke),'--algorithm',algo],text=True,capture_output=True,check=True,timeout=30,cwd=product)
                cost=int(next(csv.DictReader(io.StringIO(run.stdout)))['cost']);assert cost==expected
                costs[binary]=cost
    result=dict(status='passed',archive_crc='passed',forced_local_map_fallback=True,
                expected_cost=expected,relocated_binary_costs=costs)
    (ROOT/'results/portability_check.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
