#!/usr/bin/env python3
"""Paired, sequence-level analysis with cluster bootstrap and paper figures."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
LABELS={'lattice_astar':'Lattice A*','mesh_astar':'Mesh A*','cmesh_astar':'C-Mesh A*',
        'lattice_dlite':'Lattice D* Lite','mesh_dlite':'Mesh D* Lite','cmesh_dlite':'C-Mesh D* Lite',
        'lattice_dlite-cached':'Cached Lattice D* Lite','lattice_dlite-batch':'Boundary-Mesh D* Lite',
        'lattice_lpa':'Lattice LPA*','mesh_lpa':'Mesh LPA*','cmesh_lpa':'C-Mesh LPA*',
        'lattice_lpa-cached':'Cached Lattice LPA*','lattice_lpa-batch':'Boundary-Mesh LPA*'}
KEY=['map','control','mode','pattern','seed']


def load(raw):
    frames=[]
    for path in sorted(raw.glob('*.csv')):
        parts=path.stem.split('__')
        if len(parts)!=7:continue
        mapname,control,mode,pattern,seed,method,repeat=parts
        frame=pd.read_csv(path)
        for key,val in dict(map=mapname,control=control,mode=mode,pattern=pattern,seed=int(seed),
                            method=method,repeat=int(repeat[1:])).items():frame[key]=val
        frame['sequence']='__'.join(parts[:5]);frames.append(frame)
    return pd.concat(frames,ignore_index=True)


def paired(seq,reference,method):
    a=seq[seq.method==reference].set_index(KEY)
    b=seq[seq.method==method].set_index(KEY)
    p=a[['repair_us','all_us','rss_mib','records','cell_checks','expanded']].join(
        b[['repair_us','all_us','rss_mib','records','cell_checks','expanded']],how='inner',lsuffix='_ref',rsuffix='_new')
    p['speedup']=p.repair_us_ref/p.repair_us_new
    p['amortized_speedup']=p.all_us_ref/p.all_us_new
    return p.reset_index()


def bootstrap(frame,column='speedup',samples=3000):
    rng=np.random.default_rng(4291)
    # Hold the selected maps fixed. Resample seed blocks within each map,
    # keeping both control sets and all their modes/patterns in the same block.
    # The two controls share the RNG seed, so they are not independent draws.
    strata=[[g[column].to_numpy() for _,g in m.groupby('seed')] for _,m in frame.groupby('map')]
    if not strata:return (float('nan'),float('nan'))
    vals=[]
    for _ in range(samples):
        selected=[]
        for blocks in strata:
            picks=rng.integers(0,len(blocks),size=len(blocks))
            selected.extend(blocks[i] for i in picks)
        vals.append(np.median(np.concatenate(selected)))
    return tuple(float(v) for v in np.quantile(vals,[.025,.975]))


def table_md(frame):
    cols=list(frame.columns)
    return '| '+' | '.join(cols)+' |\n| '+' | '.join(['---']*len(cols))+' |\n'+'\n'.join(
        '| '+' | '.join(str(x) for x in row)+' |' for row in frame.itertuples(index=False,name=None))+'\n'


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--label',default='balanced');ap.add_argument('--partial',action='store_true');args=ap.parse_args()
    raw=ROOT/'results'/args.label;out=ROOT/'results';df=load(raw)
    # Check all solution costs in each identical snapshot, including infeasibility.
    agreement=df.groupby(KEY+['episode']).cost.nunique()
    assert agreement.max()==1,'Cost disagreement across methods/repeats'
    agg={'total_us':'sum','update_us':'sum','search_us':'sum','extract_us':'sum','expanded':'sum',
         'cell_checks':'sum','edge_checks':'sum','notify_probes':'sum','affected':'sum',
         'records':'max','heap_entries':'max','cache_origins':'max','rss_kib':'max'}
    repairs=df[df.episode>0]
    perrun=repairs.groupby(KEY+['method','repeat']).agg(agg).reset_index().rename(columns={'total_us':'repair_us'})
    total=df.groupby(KEY+['method','repeat']).agg(all_us=('total_us','sum'),setup_us=('setup_us','sum')).reset_index()
    perrun=perrun.merge(total,on=KEY+['method','repeat']);perrun['rss_mib']=perrun.rss_kib/1024
    seq=perrun.groupby(KEY+['method']).median(numeric_only=True).reset_index()
    per_episode=df.groupby(KEY+['method','episode']).median(numeric_only=True).reset_index()
    summary=[]
    for method in LABELS:
        if method not in set(seq.method):continue
        pair=paired(seq,'lattice_dlite',method);pair_cached=paired(seq,'lattice_dlite-cached',method)
        lo,hi=bootstrap(pair)
        sub=seq[seq.method==method]
        ep=per_episode[(per_episode.method==method)&(per_episode.episode>0)]
        summary.append(dict(method=method,label=LABELS[method],sequences=len(pair),median_speedup=pair.speedup.median(),
                            speedup_ci_lo=lo,speedup_ci_hi=hi,geomean_speedup=float(np.exp(np.log(pair.speedup).mean())),
                            speedup_vs_cached=pair_cached.speedup.median(),win_pct=100*(pair.speedup>1).mean(),
                            median_update_ms=ep.total_us.median()/1000,p95_update_ms=ep.total_us.quantile(.95)/1000,
                            median_rss_mib=sub.rss_mib.median(),median_peak_records=sub.records.median(),
                            max_rss_mib=float(df[df.method==method].rss_kib.max()/1024),
                            max_records=int(df[df.method==method].records.max()),
                            median_amortized_speedup=pair.amortized_speedup.median(),
                            initial_ms=per_episode[(per_episode.method==method)&(per_episode.episode==0)].total_us.median()/1000,
                            setup_ms=sub.setup_us.median()/1000))
    summary=pd.DataFrame(summary)
    seq.to_csv(out/'sequence_metrics.csv',index=False);summary.to_csv(out/'summary.csv',index=False)
    per_episode.to_csv(out/'episode_medians.csv.gz',index=False,compression='gzip')
    totals=dict(timed_runs=int(df.groupby(KEY+['method','repeat']).ngroups),timed_queries=len(df),
                sequences=int(df.groupby(KEY).ngroups),distinct_initial_task_clusters=int(df.groupby(['map','seed']).ngroups),
                snapshots=int(df.groupby(KEY+['episode']).ngroups),cost_disagreements=int((agreement>1).sum()),
                infeasible_snapshots=int((df.groupby(KEY+['episode']).cost.first()<0).sum()),
                zero_cost_snapshots=int((df.groupby(KEY+['episode']).cost.first()==0).sum()),
                actual_change_medians={p:float(g.groupby(KEY+['episode']).changes.first().median()) for p,g in repairs.groupby('pattern')},
                maps=sorted(df['map'].unique()),controls=sorted(df.control.unique()),
                bootstrap='3000 stratified resamples: seeds within each fixed map; both controls kept in a seed block; median paired sequence speedup',
                repair_metric='sum of episodes 1..16; median over 3 repeats; map updates, notification, search, reconstruction included',
                partial=args.partial)
    (out/'analysis.json').write_text(json.dumps(totals,indent=2)+'\n')
    comparisons={}
    for method in ['mesh_dlite','cmesh_dlite','lattice_dlite-batch']:
        pair=paired(seq,'lattice_dlite-cached',method)
        comparisons[method]={}
        for group in ['map','control','mode','pattern']:
            comparisons[method][group]=[{group:k,'n':len(g),'speedup':float(g.speedup.median()),
                                        'ci':bootstrap(g),'amortized':float(g.amortized_speedup.median())}
                                       for k,g in pair.groupby(group)]
    for mode in ['fixed','moving']:
        part=seq[seq['mode']==mode]
        comparisons[f'boundary_vs_astar_{mode}']=dict(median=float(paired(part,'lattice_astar','lattice_dlite-batch').speedup.median()))
    lpa=paired(seq,'lattice_lpa-cached','lattice_lpa-batch')
    comparisons['boundary_lpa_vs_cached_lpa']={'median':float(lpa.speedup.median()),'ci':bootstrap(lpa)}
    for reference,name in [('lattice_dlite-cached','cmesh_vs_cached'),('lattice_astar','cmesh_vs_astar')]:
        pair=paired(seq,reference,'cmesh_dlite')
        comparisons[name]={'median':float(pair.speedup.median()),'ci':bootstrap(pair),
                           'win_pct':float(100*(pair.speedup>1).mean())}
    (out/'comparisons.json').write_text(json.dumps(comparisons,indent=2)+'\n')
    md=summary[['label','sequences','median_speedup','speedup_ci_lo','speedup_ci_hi','speedup_vs_cached','median_update_ms','p95_update_ms','median_rss_mib']].copy()
    for col in md.columns[2:]:md[col]=md[col].map(lambda v:f'{v:.2f}')
    (out/'tables.md').write_text(table_md(md))
    plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'figure.dpi':120,'savefig.dpi':240})
    figdir=ROOT/'paper/figures';figdir.mkdir(parents=True,exist_ok=True)
    colors=['#b64b42','#35749c','#2b8b66'];methods=['mesh_dlite','cmesh_dlite','lattice_dlite-batch']
    fig,ax=plt.subplots(figsize=(9,4.6))
    maps=list(totals['maps']);xs=np.arange(len(maps))
    for j,(method,color) in enumerate(zip(methods,colors)):
        pair=paired(seq,'lattice_dlite-cached',method)
        items=[next(row for row in comparisons[method]['map'] if row['map']==m) for m in maps]
        vals=np.array([row['speedup'] for row in items]);lo=np.array([row['ci'][0] for row in items]);hi=np.array([row['ci'][1] for row in items])
        ax.errorbar(xs+(j-1)*.18,vals,yerr=[np.maximum(0,vals-lo),np.maximum(0,hi-vals)],
                    fmt='o',markersize=6,capsize=3,color=color,label=LABELS[method])
    ax.axhline(1,color='#333',lw=1,ls='--');ax.set_yscale('log');ax.set_ylabel('Speedup vs cached lattice')
    ax.set_xticks(xs,maps,rotation=20,ha='right');ax.legend(loc='lower left',bbox_to_anchor=(0,1.02),ncol=3,fontsize=10,frameon=False);fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(figdir/f'speedup.{ext}',bbox_inches='tight')
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4.5))
    for method,color in zip(methods,colors):
        pair=paired(seq,'lattice_dlite-cached',method)
        ys=[pair[pair.pattern==p].speedup.median() for p in ['local','path','churn']]
        axes[0].plot(range(3),ys,'o-',label=LABELS[method],color=color)
    axes[0].set_xticks(range(3),['Local\n4 attempts','Path\n8 attempts','Churn\n128 attempts'])
    axes[0].set_yscale('log');axes[0].axhline(1,color='#333',lw=.8,ls='--');axes[0].set_ylabel('Speedup vs cached lattice')
    axes[0].legend(loc='lower left',bbox_to_anchor=(0,1.02),fontsize=10,frameon=False)
    memmethods=['lattice_dlite','lattice_dlite-cached',*methods]
    memory=[seq[seq.method==m].rss_mib.median() for m in memmethods]
    axes[1].barh(range(len(memmethods)),memory,color=['#777','#555',*colors])
    axes[1].set_yticks(range(len(memmethods)),['Lattice','Cached lattice','Mesh','C-Mesh','Boundary-Mesh'])
    axes[1].invert_yaxis();axes[1].set_xlabel('Median peak RSS (MiB)');fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(figdir/f'tradeoffs.{ext}',bbox_inches='tight')
    plt.close(fig)
    # A prespecified trace; includes the initial search and every later repair.
    trace=per_episode[(per_episode['map']=='Berlin_2_256')&(per_episode.control=='base')&
                      (per_episode['mode']=='fixed')&(per_episode.pattern=='local')&(per_episode.seed==0)]
    if not trace.empty:
        fig,ax=plt.subplots(figsize=(8,3.8))
        for method,color in zip(['lattice_astar','lattice_dlite-cached',*methods],['#222','#888',*colors]):
            sub=trace[trace.method==method].sort_values('episode')
            ax.plot(sub.episode,sub.total_us.cumsum()/1000,label=LABELS[method],color=color)
        ax.set_xlabel('Episode (0 = initial search)');ax.set_ylabel('Cumulative online time (ms)')
        ax.legend(fontsize=10);fig.tight_layout()
        for ext in ['png','pdf']:fig.savefig(figdir/f'amortization.{ext}',bbox_inches='tight')
        plt.close(fig)
    print(json.dumps(totals,indent=2));print(summary[['label','median_speedup','speedup_vs_cached','median_rss_mib']].to_string(index=False))


if __name__=='__main__':main()
