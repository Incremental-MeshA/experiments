#!/usr/bin/env python3
"""Portable supplement archive with a per-file SHA-256 manifest."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    archive=ROOT.parent/'incremental_mesh_repair_artifact.zip'
    tracked=subprocess.run(['git','ls-files','-z'],cwd=ROOT,capture_output=True)
    if tracked.returncode==0:
        paths=[ROOT/p.decode() for p in tracked.stdout.split(b'\0') if p]
    else:
        paths=[p for p in ROOT.rglob('*') if p.is_file() and not any(
            part in {'.git','bin','__pycache__','.pytest_cache'} for part in p.relative_to(ROOT).parts)]
    paths=sorted(p for p in paths if p.is_file())
    manifest={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in paths:z.write(p,'incremental_mesh_repair/'+str(p.relative_to(ROOT)))
        z.writestr('incremental_mesh_repair/ARTIFACT_MANIFEST_SHA256.json',json.dumps(manifest,indent=2)+'\n')
    sha=hashlib.sha256(archive.read_bytes()).hexdigest()
    archive.with_suffix('.zip.sha256').write_text(f'{sha}  {archive.name}\n')
    print(json.dumps(dict(path=str(archive),files=len(paths)+1,bytes=archive.stat().st_size,sha256=sha),indent=2))


if __name__=='__main__':main()
