#!/usr/bin/env python3
"""Verify timed provenance, a portable rebuild, exact smoke costs, PDF bounds."""
import csv,hashlib,io,json,subprocess,tempfile,zipfile
from pathlib import Path
import fitz
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/deferred'
ARCHIVE=ROOT.parent/'mesh_deferred_astar_artifact.zip'

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    report={};env=json.loads((OUT/'raw/environment.json').read_text())
    for path,sha in env['sha256'].items():assert digest(ROOT/path)==sha,path
    mechanism=json.loads((OUT/'mechanism/environment.json').read_text())
    for path,sha in mechanism['sha256'].items():assert digest(ROOT/path)==sha,path
    report['timed_source_and_binary_hashes']='passed'
    with tempfile.TemporaryDirectory(prefix='mesh_deferred_portable_') as tmp:
        directory=Path(tmp)
        with zipfile.ZipFile(ARCHIVE) as z:z.extractall(directory)
        project=directory/'mesh_deferred_astar';manifest=json.loads((project/'ARTIFACT_MANIFEST_SHA256.json').read_text())
        for path,sha in manifest.items():assert digest(project/path)==sha,path
        report['archive_files_verified']=len(manifest)
        # Force compilation even though runnable binaries are also supplied.
        targets=['mesh_deferred','mpgaa_bbox','mc_adaptive','certified_v1','repair','ima','author_baseline']
        for b in targets:(project/'bin'/b).unlink()
        subprocess.run(['make']+['bin/'+b for b in targets],cwd=project,check=True,capture_output=True)
        report['portable_build']='passed'
        report['binary_reproduction']={b:digest(project/'bin'/b)==digest(ROOT/'bin'/b) for b in targets}
        assert all(report['binary_reproduction'].values()),report['binary_reproduction']
        jobs=json.loads((project/'results/certified/cohorts.json').read_text())
        reference={}
        for r in csv.DictReader((project/'results/certified/reference.csv').open()):reference.setdefault(r['name'],[]).append(int(r['cost']))
        chosen=[next(j for j in jobs if j['cohort']=='primary' and j['control']==c) for c in ['base','add']]
        smoke=[]
        for job in chosen:
            work=project/job['workfile'];lines=work.read_text().splitlines();lines[0]='/unavailable/workspace/maps/'+Path(lines[0]).name;work.write_text('\n'.join(lines)+'\n')
            for method,binary in [('md','mesh_deferred'),('md64','mesh_deferred'),('mpgaa-bbox','mpgaa_bbox'),('mc-adaptive','mc_adaptive'),('fresh-backward','certified_v1'),('author-mesh','author_baseline')]:
                p=subprocess.run([str(project/'bin'/binary),'--model',str(project/f'data/{job["control"]}_lattice.model'),
                      '--workload',str(work),'--algorithm',method],cwd=project,check=True,capture_output=True,text=True,timeout=300)
                assert [int(r['cost']) for r in csv.DictReader(io.StringIO(p.stdout))]==reference[job['name']],(job['name'],method)
                smoke.append(dict(control=job['control'],method=method,episodes=job['episodes']))
        report['portable_smoke']=dict(checks=smoke,cost_disagreements=0,map_path_fallback='passed')
    pdf=ROOT/'paper/mesh_deferred_ru.pdf';doc=fitz.open(pdf);outside=[];outtext=[];vectors=[]
    for i,page in enumerate(doc):
        for info in page.get_image_info():
            if not page.rect.contains(fitz.Rect(info['bbox'])):outside.append(dict(page=i+1,bbox=info['bbox']))
        for block in page.get_text('dict')['blocks']:
            if block['type']==0:
                for line in block['lines']:
                    for span in line['spans']:
                        if not page.rect.contains(fitz.Rect(span['bbox'])):outtext.append(dict(page=i+1,text=span['text']))
    def transform(p,m):
        a,b,c,d,e,f=map(float,m);x,y=p;return a*x+c*y+e,b*x+d*y+f
    for i,page in enumerate(PdfReader(pdf).pages):
        objects=page['/Resources'].get('/XObject',{})
        def visit(op,args,cm,tm):
            if op!=b'Do' or args[0] not in objects:return
            obj=objects[args[0]].get_object();box=obj.get('/BBox')
            if not box:return
            x0,y0,x1,y1=map(float,box);matrix=obj.get('/Matrix',[1,0,0,1,0,0])
            pts=[transform(transform(p,matrix),cm) for p in [(x0,y0),(x0,y1),(x1,y0),(x1,y1)]]
            bbox=[min(p[0] for p in pts),min(p[1] for p in pts),max(p[0] for p in pts),max(p[1] for p in pts)];record=dict(page=i+1,bbox=bbox);vectors.append(record)
            if bbox[0]<float(page.mediabox.left)-.01 or bbox[1]<float(page.mediabox.bottom)-.01 or bbox[2]>float(page.mediabox.right)+.01 or bbox[3]>float(page.mediabox.top)+.01:outside.append(record)
        page.extract_text(visitor_operand_before=visit)
    assert not outside and not outtext,(outside,outtext)
    assert len(vectors)==5,len(vectors)
    text='\n'.join(p.get_text() for p in doc);assert '2043' in text.replace(' ','') and 'MD-A' in text
    report['pdf']=dict(pages=len(doc),vector_figures=vectors,out_of_page_figures=outside,out_of_page_text=outtext,result_counts='passed')
    report['status']='passed';report['archive_sha256']=digest(ARCHIVE)
    (OUT/'artifact_validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
if __name__=='__main__':main()
