#!/usr/bin/env python3
"""Package the completed artifact; exclude exploratory runs and downloaded papers."""
import hashlib
import json
import zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def main():
    audit=json.loads((ROOT/'results/audit.json').read_text());assert audit['status']=='passed'
    assert (ROOT/'paper/article_ru.pdf').stat().st_size>10000
    assert '@@' not in (ROOT/'paper/article_ru.md').read_text()
    allowed_dirs={'src','bin','data','maps','workloads','tests','paper'}
    results_files={'verification.json','verification_suffix.json','analysis.json','comparisons.json','audit.json',
                   'sequence_metrics.csv','summary.csv','episode_medians.csv.gz','tables.md','REPORT_RU.md',
                   'suffix_analysis.json','suffix_sequence_metrics.csv','build_reproducibility.json','portability_check.json',
                   'pdf_validation.json'}
    files=[]
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or '__pycache__' in p.parts:continue
        rel=p.relative_to(ROOT)
        if len(rel.parts)==1:
            if p.suffix=='.py' or p.name in {'Makefile','README.md','requirements.txt'}:files.append(p)
        elif rel.parts[0]=='results':
            if (len(rel.parts)>=3 and rel.parts[1] in {'balanced','suffix'}) or rel.name in results_files:files.append(p)
        elif rel.parts[0] in allowed_dirs:
            if rel.parts[0]=='paper' and rel.name.startswith('mesha_original'):continue
            if rel.parts[0]=='workloads' and rel.name=='pilot.work':continue
            if rel.parts[0]=='bin' and rel.name not in {'ima','ima_suffix'}:continue
            files.append(p)
    archive=ROOT.parent/'incremental_mesh_astar_artifact.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
    digest=hashlib.sha256(archive.read_bytes()).hexdigest()
    archive.with_suffix('.zip.sha256').write_text(f'{digest}  {archive.name}\n')
    print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':digest},indent=2))


if __name__=='__main__':main()
