#!/usr/bin/env python3
"""Declared diagnostic family: remote changes inside a large learned bounding box.
This is a mechanism experiment, not a held-out performance claim.
"""
import argparse,csv,io,json,random,subprocess,tempfile,time
from pathlib import Path
from benchmark_mesh_deferred import ROOT,digest,command
OUT=ROOT/'results/deferred/mechanism'
METHODS=['md','md64','md-scan','mc-adaptive','mpgaa-bbox','mpgaa-grouped']

def prepare():
    OUT.mkdir(exist_ok=True)
    if (OUT/'cohorts.json').exists():raise RuntimeError('Inputs already fixed')
    jobs=[]
    for width in [160,240,320]:
        mp=ROOT/f'maps/mc_diagonal_{width}.map'
        rows=['@'*width]+['@'+'.'*(width-2)+'@' for _ in range(width-2)]+['@'*width]
        mp.write_text(f'type octile\nheight {width}\nwidth {width}\nmap\n'+'\n'.join(rows)+'\n')
        for control in ['base','add']:
            for radius in [1,3]:
                name=f'mc_diag{width}__{control}__fixed__radius{radius}__0';work=ROOT/f'workloads/{name}.work'
                s=(16,16,2);t=(width-17,width-17,2);lines=[str(mp),' '.join(map(str,(*s,*t)))]
                overlay=set();rng=random.Random(width*901+radius)
                for ep in range(25):
                    changes=[]
                    if ep:
                        # Opposite far corners lie inside the diagonal search's
                        # rectangular support yet outside its improvement region.
                        a=width//8+rng.randrange(-3,4);b=width-width//8+rng.randrange(-3,4)
                        if ep%2:a,b=b,a
                        new={(a+i,b+j) for i in range(-radius,radius+1) for j in range(-radius,radius+1)}
                        changes=[(r,c,int((r,c) in new)) for r,c in sorted(overlay^new)];overlay=new
                    lines.append(' '.join(map(str,(*s,len(changes)))));lines+=[' '.join(map(str,c)) for c in changes]
                work.write_text('\n'.join(lines)+'\n')
                jobs.append(dict(name=name,map=mp.stem,width=width,control=control,radius=radius,mode='fixed',episodes=25,
                   workfile=str(work.relative_to(ROOT)),workload_sha256=digest(work)))
    (OUT/'cohorts.json').write_text(json.dumps(jobs,indent=2)+'\n')
    (OUT/'design.json').write_text(json.dumps(dict(widths=[160,240,320],radii=[1,3],controls=['base','add'],
        methods=METHODS,repeats=3,updates=24,description='Diagonal empty-room query; alternating remote square patches in opposite corners. Bbox cannot exclude them; the compiled witness bound can.',
        scope='Diagnostic family chosen to expose the proved maintenance advantage; not an estimate of general-world performance.',
        pilot_note='An exact-reference-only 640 pilot was stopped for cost before any MD-A* diagnostic timing. Its inputs/log are preserved separately.'),indent=2)+'\n')
    print('Prepared',len(jobs),'diagnostic sequences',flush=True)

def add_oscillating_inputs():
    jobs=json.loads((OUT/'cohorts.json').read_text())
    if any(j['mode']=='oscillating' for j in jobs):return
    extra=[]
    for job in jobs:
        lines=(ROOT/job['workfile']).read_text().splitlines();root=list(map(int,lines[1].split()));start=root[:3]
        with tempfile.TemporaryDirectory(prefix='md_control_path_') as directory:
            work=Path(directory)/'initial.work';work.write_text('\n'.join(lines[:3])+'\n')
            p=subprocess.run([str(ROOT/'bin/mpgaa_bbox'),'--model',str(ROOT/f'data/{job["control"]}_lattice.model'),
                '--workload',str(work),'--dump'],check=True,text=True,capture_output=True,timeout=600)
        pid=int(p.stderr.split()[2]);prims=json.loads((ROOT/f'data/{job["control"]}_primitives.json').read_text())
        primitive=next(p for p in prims if p['id']==pid);dr,dc,h=primitive['goal'];forward=[start[0]+dr,start[1]+dc,h]
        updated=lines[:2];at=2;episode=0
        while at<len(lines):
            header=lines[at].split();n=int(header[-1]);at+=1
            current=forward if (episode//4)%2 else start
            updated.append(' '.join(map(str,(*current,n))));updated+=lines[at:at+n];at+=n;episode+=1
        name=job['name'].replace('__fixed__','__oscillating__');target=ROOT/f'workloads/{name}.work';target.write_text('\n'.join(updated)+'\n')
        extra.append(dict(job,name=name,mode='oscillating',workfile=str(target.relative_to(ROOT)),
                 workload_sha256=digest(target),movement_primitive=pid,moves=6))
    jobs+=extra;(OUT/'cohorts.json').write_text(json.dumps(jobs,indent=2)+'\n')
    design=json.loads((OUT/'design.json').read_text());design['modes']=['fixed','oscillating']
    design['movement']='Alternate original start and its first-primitive successor every four events; path selected by the common MPGAA* control before timing.'
    design['timing_note']='Oscillating inputs added before any diagnostic MD-A* performance was observed.'
    (OUT/'design.json').write_text(json.dumps(design,indent=2)+'\n')

def references():
    add_oscillating_inputs()
    for job in json.loads((OUT/'cohorts.json').read_text()):assert digest(ROOT/job['workfile'])==job['workload_sha256']
    if (OUT/'reference.csv').exists():
        print('Preserved frozen diagnostic reference',flush=True);return
    refs=[]
    for job in json.loads((OUT/'cohorts.json').read_text()):
        cmd=[str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{job["control"]}_lattice.model'),
           '--workload',str(ROOT/job['workfile']),'--algorithm','astar']
        p=subprocess.run(cmd,check=True,text=True,capture_output=True,timeout=600)
        for r in csv.DictReader(io.StringIO(p.stdout)):refs.append(dict(name=job['name'],episode=int(r['episode']),cost=int(r['cost'])))
        print('referenced',job['name'],flush=True)
    with (OUT/'reference.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=refs[0],lineterminator='\n');w.writeheader();w.writerows(refs)

def run():
    jobs=json.loads((OUT/'cohorts.json').read_text());raw=OUT/'raw';raw.mkdir(exist_ok=True)
    sha={p:digest(ROOT/p) for p in ['bin/mesh_deferred','bin/mc_adaptive','bin/mpgaa_bbox','bin/certified_v1','bin/ima',
        'results/deferred/mechanism/cohorts.json','results/deferred/mechanism/reference.csv']}
    environment=OUT/'environment.json'
    if environment.exists():assert json.loads(environment.read_text())['sha256']==sha
    else:environment.write_text(json.dumps(dict(sha256=sha,sequential=True,methods=METHODS),indent=2)+'\n')
    expected={}
    for r in csv.DictReader((OUT/'reference.csv').open()):expected.setdefault(r['name'],[]).append(int(r['cost']))
    rng=random.Random(6701);rng.shuffle(jobs);start=time.monotonic();done=0
    for job in jobs:
        assert digest(ROOT/job['workfile'])==job['workload_sha256']
        for rep in range(3):
            order=METHODS[:];rng.shuffle(order)
            for method in order:
                target=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not target.exists():
                    p=subprocess.run(command(job,method),check=True,text=True,capture_output=True,timeout=600)
                    rows=list(csv.DictReader(io.StringIO(p.stdout)));assert [int(r['cost']) for r in rows]==expected[job['name']],(job['name'],method)
                    target.write_text(p.stdout)
                done+=1
        print(done,'runs;',round(time.monotonic()-start,1),'seconds;',job['name'],flush=True)
    (OUT/'completion.json').write_text(json.dumps(dict(status='passed',runs=done,queries=done*25,sequences=len(jobs),cost_disagreements=0,seconds=time.monotonic()-start),indent=2)+'\n')

def analyze():
    import numpy as np
    import pandas as pd
    records=[];jobs=pd.DataFrame(json.loads((OUT/'cohorts.json').read_text())).set_index('name')
    for p in (OUT/'raw').glob('*.csv'):
        name,method,rep=p.stem.rsplit('__',2);d=pd.read_csv(p)
        records.append(dict(name=name,method=method,repeat=rep,online_us=d.loc[d.episode>0,'total_us'].sum(),amortized_us=d.total_us.sum()+d.setup_us.sum(),
                 certified=d.loc[d.episode>0,'certified'].sum() if 'certified' in d else 0))
    seq=pd.DataFrame(records).groupby(['name','method']).median(numeric_only=True).reset_index().join(jobs,on='name');seq.to_csv(OUT/'sequence_metrics.csv',index=False)
    result=dict(sequences=len(jobs),methods={},scope='Declared mechanism probe, no population confidence interval')
    for method in METHODS:
        result['methods'][method]={}
        for metric in ['online_us','amortized_us']:
            p=seq.pivot(index='name',columns='method',values=metric)
            r=p['mpgaa-bbox']/p[method];result['methods'][method][metric]=dict(median=float(r.median()),wins=int((r>1).sum()),n=len(r),minimum=float(r.min()),maximum=float(r.max()))
    result['strata']={}
    for (width,radius,mode),sub in seq.groupby(['width','radius','mode']):
        p=sub.pivot(index='name',columns='method',values='online_us');result['strata'][f'{width}_{radius}_{mode}']=float((p['mpgaa-bbox']/p['md']).median())
    result['motion']={}
    for mode,sub in seq.groupby('mode'):
        p=sub.pivot(index='name',columns='method',values='online_us')
        result['motion'][mode]={b:dict(median=float((p[b]/p['md']).median()),wins=int(((p[b]/p['md'])>1).sum()),n=len(p)) for b in ['mpgaa-bbox','mc-adaptive']}
    result['certified_fraction']=float(seq[seq.method=='md'].certified.sum()/(len(jobs)*24))
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    from analyze_mesh_deferred import plot_cache
    plot_cache()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,2,figsize=(8.5,3),constrained_layout=True)
    for ax,mode in zip(axes,['fixed','oscillating']):
        for radius in [1,3]:
            ax.plot([160,240,320],[result['strata'][f'{w}_{radius}_{mode}'] for w in [160,240,320]],'o-',label=f'{2*radius+1} x {2*radius+1} patch')
        ax.axhline(1,c='black',lw=.8);ax.set_xticks([160,240,320]);ax.set_xlabel('Square map width, cells');ax.set_title(mode.capitalize());ax.legend()
    axes[0].set_ylabel('MD-A* speedup vs spatial MPGAA*')
    fig.savefig(OUT/'scaling.pdf');fig.savefig(OUT/'scaling.png',dpi=180);plt.close(fig)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','reference','run','analyze'],required=True);a=p.parse_args()
    {'prepare':prepare,'reference':references,'run':run,'analyze':analyze}[a.stage]()
