#!/usr/bin/env python3
"""Audit completed artifacts: coverage, agreement, hashes and frozen binaries."""
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    groups=defaultdict(list);counts={}
    for phase,expected in [('balanced',1512),('suffix',432)]:
        files=sorted((ROOT/'results'/phase).glob('*.csv'));assert len(files)==expected,(phase,len(files),expected)
        phasegroups=defaultdict(set)
        for p in files:
            parts=p.stem.split('__');assert len(parts)==7
            seq='__'.join(parts[:5]);method=parts[5];rep=int(parts[6][1:]);assert rep in (0,1,2)
            rows=list(csv.DictReader(p.open()));assert len(rows)==17
            assert [int(r['episode']) for r in rows]==list(range(17))
            for ep,row in enumerate(rows):groups[(seq,ep)].append(int(row['cost']))
            phasegroups[seq].add((method,rep))
        assert len(phasegroups)==48
        for seq,methods in phasegroups.items():
            expectedmethods=13 if '__fixed__' in seq else 8
            assert len(methods)==(3 if phase=='suffix' else expectedmethods)*3,(seq,len(methods))
        counts[phase]=len(files)
    assert len(groups)==816
    assert all(len(set(values))==1 for values in groups.values())
    for phase in ['balanced','suffix']:
        env=json.loads((ROOT/f'results/{phase}/environment.json').read_text())
        binary=ROOT/('bin/ima' if phase=='balanced' else 'bin/ima_suffix')
        assert hashlib.sha256(binary.read_bytes()).hexdigest()==env['binary_sha256']
    mainenv=json.loads((ROOT/'results/balanced/environment.json').read_text())
    sxenv=json.loads((ROOT/'results/suffix/environment.json').read_text())
    assert sxenv['reference_binary_sha256']==mainenv['binary_sha256']
    for p,d in json.loads((ROOT/'workloads/manifest.json').read_text()).items():
        assert hashlib.sha256((ROOT/'workloads'/p).read_bytes()).hexdigest()==d['sha256']
    for p,digest in json.loads((ROOT/'maps/manifest.json').read_text()).items():
        assert hashlib.sha256((ROOT/'maps'/p).read_bytes()).hexdigest()==digest
    for p,digest in json.loads((ROOT/'data/models_sha256.json').read_text()).items():
        assert hashlib.sha256((ROOT/'data'/p).read_bytes()).hexdigest()==digest
    for filename in ['verification.json','verification_suffix.json']:
        assert json.loads((ROOT/'results'/filename).read_text())['status']=='passed'
    failures=ROOT/'results/balanced/failures.json'
    assert not json.loads(failures.read_text()),'Benchmark failures must be reported and resolved'
    report=dict(status='passed',timed_runs=sum(counts.values()),phases=counts,snapshots=len(groups),
                timed_queries=sum(counts.values())*17,checks=['complete method/repeat/episode coverage',
                'cost and infeasibility agreement across both phases','frozen binary hashes',
                '288 workload hashes','map/scenario/model hashes','independent verification status','no hidden benchmark failures'])
    (ROOT/'results/audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
