#!/usr/bin/env python3
"""Second frozen phase: mesh influence filtering, reparenting, a fresh seed."""
import argparse
import csv
import io
import json
import platform
import random
import subprocess
import time
from pathlib import Path
from benchmark_repair import ROOT, OUT, MAPS, command, digest

DEST=OUT/'influence'
METHODS=['fresh','fresh-mesh','fresh-backward','mdf','mfr','mir','mir-forward','mir-filter','mdf-rp']


def prepare():
    DEST.mkdir(exist_ok=True)
    jobs=json.loads((OUT/'cohorts.json').read_text())
    for j in jobs:j['phase_cohort']='development'
    for i,mapname in enumerate(MAPS):
        for k,control in enumerate(['base','add']):
            mode=['fixed','moving'][(i+k)%2];pattern=['local','path','churn'][(i+2*k+1)%3]
            name=f'{mapname}__{control}__{mode}__{pattern}__5'
            job=dict(name=name,map=mapname,control=control,mode=mode,pattern=pattern,seed=5,
                     cohort='validation5',phase_cohort='validation5')
            work=ROOT/'workloads'/f'{name}.work'
            if not work.exists():
                subprocess.run([str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{control}_lattice.model'),
                    '--map',str(ROOT/f'maps/{mapname}.map'),'--generate',str(work),'--seed','1005',
                    '--episodes','16','--pattern',pattern,'--moving',str(int(mode=='moving'))],
                    check=True,capture_output=True,text=True,timeout=240)
            job['workload_sha256']=digest(work);jobs.append(job)
    # The new cohort is fixed before any new candidate is timed on it.
    (DEST/'cohorts.json').write_text(json.dumps(jobs,indent=2)+'\n')
    ref=[];old={}
    for r in csv.DictReader((OUT/'reference.csv').open()):old.setdefault(r['name'],[]).append(r)
    for job in jobs:
        if job['name'] in old:
            for r in old[job['name']]:ref.append(dict(r,phase_cohort=job['phase_cohort']))
            continue
        fresh=subprocess.run(command(job,'fresh',ROOT/'bin/repair')+['--dump'],check=True,capture_output=True,text=True,timeout=240)
        rows=list(csv.DictReader(io.StringIO(fresh.stdout)))
        control=subprocess.run(command(job,'lattice-astar'),check=True,capture_output=True,text=True,timeout=240)
        assert [r['cost'] for r in rows]==[r['cost'] for r in csv.DictReader(io.StringIO(control.stdout))]
        (DEST/f'{job["name"]}.paths').write_text(fresh.stderr)
        for r in rows:
            ep=int(r['episode']);cost=int(r['cost']);oldcost=int(r['previous_suffix_cost'])
            cat='initial' if ep==0 else 'off_reference' if oldcost<0 else 'disconnected' if cost<0 else 'increase_finite' if cost>oldcost else 'improvement' if cost<oldcost else 'unchanged_broken' if r['previous_suffix_valid']=='0' else 'unchanged_valid'
            ref.append(dict(name=job['name'],cohort=job['cohort'],episode=ep,cost=cost,
                            previous_suffix_cost=oldcost,previous_suffix_valid=r['previous_suffix_valid'],category=cat,phase_cohort=job['phase_cohort']))
    with (DEST/'reference.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=ref[0],lineterminator='\n');w.writeheader();w.writerows(ref)
    print('Prepared',len(jobs),'sequences,',len(ref),'snapshots',flush=True)


def run():
    jobs=json.loads((DEST/'cohorts.json').read_text());rng=random.Random(3316008);rng.shuffle(jobs)
    raw=DEST/'raw';raw.mkdir(exist_ok=True)
    env=dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),platform=platform.platform(),
             sha256={p.name:digest(p) for p in [ROOT/'bin/repair',ROOT/'src/repair.cpp']},
             methods=METHODS,note='Sequential processes, random method order. Seed 1005 is unseen validation; first-phase 60 tasks are now development.')
    ep=DEST/'environment.json'
    if ep.exists():assert json.loads(ep.read_text())['sha256']==env['sha256']
    else:ep.write_text(json.dumps(env,indent=2)+'\n')
    expected={}
    for r in csv.DictReader((DEST/'reference.csv').open()):expected.setdefault(r['name'],[]).append(int(r['cost']))
    start=time.monotonic();done=0
    for job in jobs:
        assert digest(ROOT/'workloads'/f'{job["name"]}.work')==job['workload_sha256']
        for rep in range(3):
            order=METHODS[:];rng.shuffle(order)
            for method in order:
                dst=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not dst.exists():
                    p=subprocess.run(command(job,method,ROOT/'bin/repair'),check=True,capture_output=True,text=True,timeout=240)
                    rows=list(csv.DictReader(io.StringIO(p.stdout)))
                    assert [int(r['cost']) for r in rows]==expected[job['name']],(job['name'],method)
                    dst.write_text(p.stdout)
                done+=1
        print(done,'runs;',round(time.monotonic()-start,1),'seconds;',job['name'],flush=True)
    (DEST/'completion.json').write_text(json.dumps(dict(status='passed',runs=done,queries=done*17,sequences=len(jobs),cost_disagreements=0),indent=2)+'\n')


def analyze():
    import numpy as np
    import pandas as pd
    cohort=pd.DataFrame(json.loads((DEST/'cohorts.json').read_text())).set_index('name')
    ref=pd.read_csv(DEST/'reference.csv');frames=[]
    for p in sorted((DEST/'raw').glob('*.csv')):
        name,method,rep=p.stem.rsplit('__',2);d=pd.read_csv(p);d['name']=name;d['method']=method;d['repeat']=int(rep[1:]);frames.append(d)
    raw=pd.concat(frames).merge(ref[['name','episode','category']],on=['name','episode'])
    records=[]
    for (name,method,rep),d in raw.groupby(['name','method','repeat']):
        repaired=d.category=='increase_finite'
        records.append(dict(name=name,method=method,repeat=rep,online_us=d.loc[d.episode>0,'total_us'].sum(),
            repair_us=d.loc[repaired,'total_us'].sum() if repaired.any() else np.nan,
            all_us=d.total_us.sum(),amortized_us=d.total_us.sum()+d.setup_us.sum(),
            invalidated=d.invalidated.sum(),notify=d.notify_probes.sum(),filtered=d.filtered_cells.sum(),
            alternates=d.alternate_parents.sum(),changes=d.changes.sum(),rss_mib=d.rss_kib.max()/1024))
    seq=pd.DataFrame(records).groupby(['name','method']).median(numeric_only=True).reset_index().merge(cohort.reset_index(),on='name')
    seq.to_csv(DEST/'sequence_metrics.csv',index=False)
    result=dict(sequences=len(cohort),snapshots=len(ref),methods={},comparisons={},categories={})
    names=cohort.index[cohort.cohort=='original'].tolist();rng=np.random.default_rng(9183)
    blocks={(m,s):[i for i,n in enumerate(names) if cohort.loc[n,'map']==m and cohort.loc[n,'seed']==s] for m in MAPS for s in range(4)}
    sample=[]
    for _ in range(6000):
        ids=[]
        for m in MAPS:
            for s in rng.integers(0,4,4):ids.extend(blocks[m,int(s)])
        sample.append(ids)
    sample=np.array(sample)
    def compare(method,metric,part,baseline=None):
        p=seq.pivot(index='name',columns='method',values=metric)
        b=p[baseline] if baseline else p[['fresh','fresh-mesh','fresh-backward']].min(axis=1)
        ratio=(b/p[method]).rename('ratio').to_frame().join(cohort[['cohort','phase_cohort']])
        ratio=ratio[ratio.cohort=='original'] if part=='original' else ratio[ratio.phase_cohort==part]
        x=ratio.ratio.dropna();ci=None
        if part=='original':
            vals=x.reindex(names).to_numpy();ci=np.nanpercentile(np.nanmedian(vals[sample],axis=1),[2.5,97.5]).tolist()
        return dict(n=len(x),median=float(x.median()),wins=int((x>1).sum()),ci=ci)
    for method in METHODS:
        result['methods'][method]={part:{metric:compare(method,metric,part) for metric in ['online_us','repair_us','all_us','amortized_us']} for part in ['original','development','validation5']}
        result['methods'][method]['rss_mib']=float(seq[(seq.method==method)&(seq.cohort=='original')].rss_mib.median())
    for method in ['mir','mir-forward','mir-filter','mdf-rp']:
        result['comparisons'][method]={base:{metric:compare(method,metric,'original',base) for metric in ['online_us','repair_us','amortized_us']} for base in ['mdf','mfr','mir-filter','mdf-rp']}
    for part in ['development','validation5']:
        result['categories'][part]=ref[ref.phase_cohort==part].category.value_counts().to_dict()
    result['work']=seq[seq.cohort=='original'].groupby('method')[['invalidated','notify','filtered','alternates','changes']].sum().to_dict()
    (DEST/'analysis.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    plot_results(result)
    for method in METHODS:print(method,result['methods'][method],flush=True)


def plot_results(result):
    import numpy as np
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    plt.rcParams.update({'pdf.fonttype':42,'font.size':11})
    chosen=['mdf','mfr','mir-filter','mdf-rp','mir','mir-forward']
    labels=['MDF','MFR','MIR filter','MDF reparent','MIR','MIR-F']
    fig,axes=plt.subplots(1,2,figsize=(8.8,3.3),constrained_layout=True)
    for ax,metric,title in zip(axes,['online_us','repair_us'],['All replanning queries','Forced finite repairs']):
        vals=[result['methods'][k]['original'][metric]['median'] for k in chosen]
        ci=[result['methods'][k]['original'][metric]['ci'] for k in chosen]
        y=np.arange(len(chosen));ax.scatter(vals,y,c=['#888888']*2+['#6c91b6']*2+['#c1572c']*2,s=32,zorder=3)
        ax.hlines(y,[x[0] for x in ci],[x[1] for x in ci],color='black',lw=1.2)
        ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xscale('log');ax.axvline(1,c='black',lw=.8);ax.set_title(title);ax.set_xlabel('Speedup vs best fresh A*')
        low=.8*min(x[0] for x in ci);high=1.2*max(1,max(x[1] for x in ci))
        ticks=[x for x in [.05,.1,.2,.5,1,2,5,10] if low<=x<=high]
        ax.set_xticks(ticks,[f'{x:g}' for x in ticks]);ax.xaxis.set_minor_formatter(ticker.NullFormatter());ax.set_xlim(low,high)
    fig.savefig(DEST/'speedups.pdf');fig.savefig(DEST/'speedups.png',dpi=180);plt.close(fig)


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','run','analyze'],required=True);a=p.parse_args()
    {'prepare':prepare,'run':run,'analyze':analyze}[a.stage]()
