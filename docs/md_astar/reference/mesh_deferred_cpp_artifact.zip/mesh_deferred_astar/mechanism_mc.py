#!/usr/bin/env python3
"""Declared diagnostic family: remote changes inside a large learned bounding box.
This is a mechanism experiment, not a held-out performance claim.
"""
import argparse,csv,io,json,random,subprocess,time
from pathlib import Path
from benchmark_mc_adaptive import ROOT,digest,command
OUT=ROOT/'results/certified/adaptive/mechanism'
METHODS=['mc-adaptive','mc-scalar','mc-geometric','mc-nogate','mpgaa-bbox','mpgaa-grouped','fresh-backward']

def prepare():
    OUT.mkdir(exist_ok=True)
    if (OUT/'cohorts.json').exists():raise RuntimeError('Inputs already fixed')
    jobs=[]
    for width in [160,320,640]:
        mp=ROOT/f'maps/mc_diagonal_{width}.map'
        rows=['@'*width]+['@'+'.'*(width-2)+'@' for _ in range(width-2)]+['@'*width]
        mp.write_text(f'type octile\nheight {width}\nwidth {width}\nmap\n'+'\n'.join(rows)+'\n')
        for control in ['base','add']:
            for radius in [1,3]:
                name=f'mc_diag{width}__{control}__fixed__radius{radius}__0';work=ROOT/f'workloads/{name}.work'
                s=(16,16,2);t=(width-17,width-17,2);lines=[str(mp),' '.join(map(str,(*s,*t)))]
                overlay=set();rng=random.Random(width*901+radius)
                for ep in range(25):
                    changes=[]
                    if ep:
                        # Opposite far corners lie inside the diagonal search's
                        # rectangular support yet outside its improvement region.
                        a=width//8+rng.randrange(-3,4);b=width-width//8+rng.randrange(-3,4)
                        if ep%2:a,b=b,a
                        new={(a+i,b+j) for i in range(-radius,radius+1) for j in range(-radius,radius+1)}
                        changes=[(r,c,int((r,c) in new)) for r,c in sorted(overlay^new)];overlay=new
                    lines.append(' '.join(map(str,(*s,len(changes)))));lines+=[' '.join(map(str,c)) for c in changes]
                work.write_text('\n'.join(lines)+'\n')
                jobs.append(dict(name=name,map=mp.stem,width=width,control=control,radius=radius,mode='fixed',episodes=25,
                   workfile=str(work.relative_to(ROOT)),workload_sha256=digest(work)))
    (OUT/'cohorts.json').write_text(json.dumps(jobs,indent=2)+'\n')
    (OUT/'design.json').write_text(json.dumps(dict(widths=[160,320,640],radii=[1,3],controls=['base','add'],
        methods=METHODS,repeats=3,updates=24,description='Diagonal empty-room query; alternating remote square patches in opposite corners. Bbox cannot exclude them; the compiled witness bound can.',
        scope='Diagnostic family chosen to expose the proved maintenance advantage; not an estimate of general-world performance.'),indent=2)+'\n')
    print('Prepared',len(jobs),'diagnostic sequences',flush=True)

def references():
    refs=[]
    for job in json.loads((OUT/'cohorts.json').read_text()):
        cmd=[str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{job["control"]}_lattice.model'),
           '--workload',str(ROOT/job['workfile']),'--algorithm','astar']
        p=subprocess.run(cmd,check=True,text=True,capture_output=True,timeout=600)
        for r in csv.DictReader(io.StringIO(p.stdout)):refs.append(dict(name=job['name'],episode=int(r['episode']),cost=int(r['cost'])))
        print('referenced',job['name'],flush=True)
    with (OUT/'reference.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=refs[0],lineterminator='\n');w.writeheader();w.writerows(refs)

def run():
    jobs=json.loads((OUT/'cohorts.json').read_text());raw=OUT/'raw';raw.mkdir(exist_ok=True)
    sha={p:digest(ROOT/p) for p in ['bin/mc_adaptive','bin/mpgaa_bbox','bin/certified_v1','bin/ima']}
    environment=OUT/'environment.json'
    if environment.exists():assert json.loads(environment.read_text())['sha256']==sha
    else:environment.write_text(json.dumps(dict(sha256=sha,sequential=True,methods=METHODS),indent=2)+'\n')
    expected={}
    for r in csv.DictReader((OUT/'reference.csv').open()):expected.setdefault(r['name'],[]).append(int(r['cost']))
    rng=random.Random(6701);rng.shuffle(jobs);start=time.monotonic();done=0
    for job in jobs:
        for rep in range(3):
            order=METHODS[:];rng.shuffle(order)
            for method in order:
                target=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not target.exists():
                    p=subprocess.run(command(job,method),check=True,text=True,capture_output=True,timeout=600)
                    rows=list(csv.DictReader(io.StringIO(p.stdout)));assert [int(r['cost']) for r in rows]==expected[job['name']],(job['name'],method)
                    target.write_text(p.stdout)
                done+=1
        print(done,'runs;',round(time.monotonic()-start,1),'seconds;',job['name'],flush=True)
    (OUT/'completion.json').write_text(json.dumps(dict(status='passed',runs=done,queries=done*25,sequences=len(jobs),cost_disagreements=0,seconds=time.monotonic()-start),indent=2)+'\n')

def analyze():
    import numpy as np
    import pandas as pd
    records=[];jobs=pd.DataFrame(json.loads((OUT/'cohorts.json').read_text())).set_index('name')
    for p in (OUT/'raw').glob('*.csv'):
        name,method,rep=p.stem.rsplit('__',2);d=pd.read_csv(p)
        records.append(dict(name=name,method=method,repeat=rep,online_us=d.loc[d.episode>0,'total_us'].sum(),amortized_us=d.total_us.sum()+d.setup_us.sum(),
                 certified=d.loc[d.episode>0,'certified'].sum() if 'certified' in d else 0))
    seq=pd.DataFrame(records).groupby(['name','method']).median(numeric_only=True).reset_index().join(jobs,on='name');seq.to_csv(OUT/'sequence_metrics.csv',index=False)
    result=dict(sequences=len(jobs),methods={},scope='Declared mechanism probe, no population confidence interval')
    for method in METHODS:
        result['methods'][method]={}
        for metric in ['online_us','amortized_us']:
            p=seq.pivot(index='name',columns='method',values=metric)
            r=p['mpgaa-bbox']/p[method];result['methods'][method][metric]=dict(median=float(r.median()),wins=int((r>1).sum()),n=len(r),minimum=float(r.min()),maximum=float(r.max()))
    result['strata']={}
    for (width,radius),sub in seq.groupby(['width','radius']):
        p=sub.pivot(index='name',columns='method',values='online_us');result['strata'][f'{width}_{radius}']=float((p['mpgaa-bbox']/p['mc-adaptive']).median())
    result['certified_fraction']=float(seq[seq.method=='mc-adaptive'].certified.sum()/(len(jobs)*24))
    (OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    fig,ax=plt.subplots(figsize=(7.3,3),constrained_layout=True)
    for radius in [1,3]:
        ax.plot([160,320,640],[result['strata'][f'{w}_{radius}'] for w in [160,320,640]],'o-',label=f'{2*radius+1} x {2*radius+1} patch')
    ax.axhline(1,c='black',lw=.8);ax.set_xticks([160,320,640]);ax.set_xlabel('Square map width, cells');ax.set_ylabel('MC-A* speedup vs spatial MPGAA*');ax.legend()
    fig.savefig(OUT/'scaling.pdf');fig.savefig(OUT/'scaling.png',dpi=180);plt.close(fig)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','reference','run','analyze'],required=True);a=p.parse_args()
    {'prepare':prepare,'reference':references,'run':run,'analyze':analyze}[a.stage]()
