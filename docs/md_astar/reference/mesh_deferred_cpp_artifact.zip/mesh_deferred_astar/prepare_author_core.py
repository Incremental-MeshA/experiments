#!/usr/bin/env python3
"""Vendor the MIT-licensed author search core with explicit numeric alignment."""
import hashlib,json,re,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT.parent/'mesha_reference'
DEST=ROOT/'third_party/mesha_author'


def body_replace(text,signature,body):
    start=text.index(signature);opening=text.index('{',start);depth=1;end=opening+1
    while depth:
        if text[end]=='{':depth+=1
        if text[end]=='}':depth-=1
        end+=1
    return text[:opening+1]+'\n'+body+'\n'+text[end-1:]


def main():
    files=sorted((SOURCE/'include').glob('*.hpp'))
    files += [SOURCE/'src'/f'KC_{s}.cpp' for s in ['heap','searching','structs','search_params','algorithms']]
    manifest={}
    for path in files:
        relative=path.relative_to(SOURCE);target=DEST/relative;target.parent.mkdir(parents=True,exist_ok=True)
        data=path.read_bytes();text=data.decode();manifest[str(relative)]=hashlib.sha256(data).hexdigest()
        text=re.sub(r'\bfloat\b','double',text)
        if path.name=='KC_search_params.cpp':
            text=body_replace(text,'double StateLatticeParams::heuristic(','''    return w*baseline_metric(node->vertex->i-finish->i,node->vertex->j-finish->j);''')
            text=body_replace(text,'static inline double base_heuristic(','''    if(params->mesh_info->theta_by_initial_config[node->vertex->config_id]>=0)
        return baseline_metric(node->vertex->i-params->finish->i,node->vertex->j-params->finish->j);
    double best=1e100;
    for(auto p:params->mesh_info->primitives_in_config[node->vertex->config_id]) {
        int r=node->vertex->i+get<1>(p),c=node->vertex->j+get<2>(p);
        int config=params->mesh_info->initial_config_by_theta[get<0>(p)];
        if(check_cell(params->task_map,r,c,nullptr)&&!params->ast->was_expanded(r,c,config))
            best=std::min(best,params->control_set->cost(get<4>(p))+baseline_metric(r-params->finish->i,c-params->finish->j));
    }
    return best;''')
        target.write_text(text)
    shutil.copyfile(SOURCE/'LICENSE.txt',DEST/'LICENSE.txt')
    meta=dict(repository='https://github.com/PathPlanning/MeshAStar',
              commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip(),
              original_sha256=manifest,changes=['All scalar float types promoted to double so integer microcosts are exact.',
              'Both heuristics use the same admissible octile metric as other engines; native Finals endpoint filtering retained.',
              'Input adapter supplies the common primitive costs, traces and mesh topology; search, allocator, pruning and reconstruction unchanged.'])
    (DEST/'UPSTREAM.json').write_text(json.dumps(meta,indent=2)+'\n')
    print('Vendored',len(files),'source/header files')


if __name__=='__main__':main()
