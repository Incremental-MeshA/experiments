#!/usr/bin/env python3
"""Final matched comparison and map-cluster uncertainty for MD-A*."""
import argparse,json
from pathlib import Path
import numpy as np
import pandas as pd
from analyze_certified import collect
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'results/certified';OUT=ROOT/'results/deferred'
MAIN='md'
FRESH=['fresh-backward','author-mesh','author-lattice','author-lazy']
KNOWN=['mpgaa-bbox','mpgaa-grouped','cached-dlite','cmesh-dlite','csb','mir','mc-adaptive']
LABELS={'md':'MD-A*','md64':'MD with 64 coefficients','md-scan':'MD without transported heap','mc-adaptive':'MC-A*','mc-scalar':'MC scalar','mc-nogate':'MC without compiled gate','mc-geometric':'MC geometry only',
        'mc-fresh':'MC with fresh backward A*','mpgaa-bbox':'MPGAA* + spatial index','mpgaa-grouped':'MPGAA* grouped',
        'fresh-backward':'Repeated backward A*','author-mesh':'Author MeshA*','author-lattice':'Author LBA*','author-lazy':'Author LazyLBA*',
        'cached-dlite':'Cached D* Lite','cmesh-dlite':'C-Mesh D* Lite','csb':'CSB','mir':'MIR'}

def plot_cache():
    import os,tempfile
    cache=Path(tempfile.gettempdir())/'mesh_deferred_plot_cache';cache.mkdir(exist_ok=True)
    os.environ.setdefault('MPLCONFIGDIR',str(cache/'matplotlib'))
    os.environ.setdefault('XDG_CACHE_HOME',str(cache))

def analyze(partial=False):
    cohorts=pd.DataFrame(json.loads((BASE/'cohorts.json').read_text()));reference=pd.read_csv(BASE/'reference.csv')
    if not partial:
        assert all((OUT/'raw'/f'completion_{c}.json').exists() for c in ['primary','validation','regression'])
    seq,raw,run=collect(OUT/'raw',reference,cohorts)
    seq.to_csv(OUT/'sequence_metrics.csv',index=False)
    maps=cohorts['map'].unique().tolist();rng=np.random.default_rng(151126)
    samples=rng.integers(0,len(maps),(6000,len(maps)))
    def compare(cohort,method=MAIN,baseline='best-fresh',metric='online_us'):
        s=seq[seq.cohort==cohort];p=s.pivot(index='name',columns='method',values=metric)
        pool=FRESH if baseline=='best-fresh' else FRESH+KNOWN if baseline=='best-baseline' else KNOWN if baseline=='best-incremental' else None
        base=p[[m for m in pool if m in p]].min(axis=1) if pool else p[baseline]
        z=(base/p[method]).rename('speedup').to_frame().join(cohorts.set_index('name')[['map','mode','control']]).dropna(subset=['speedup'])
        if not len(z):return dict(n=0)
        ci=None
        if cohort!='validation':
            arrays=[z[z['map']==m].speedup.to_numpy() for m in maps]
            med=[]
            for sample in samples:
                values=np.concatenate([arrays[int(i)] for i in sample])
                if len(values):med.append(np.median(values))
            ci=np.percentile(med,[2.5,97.5]).tolist()
        return dict(n=len(z),median=float(z.speedup.median()),ci=ci,wins=int((z.speedup>1).sum()),
                    minimum=float(z.speedup.min()),q25=float(z.speedup.quantile(.25)),q75=float(z.speedup.quantile(.75)),maximum=float(z.speedup.max()))
    result=dict(status='partial' if partial else 'passed',runs=len(run),timed_queries=len(raw),snapshots=len(reference),sequences=len(cohorts),
        main=MAIN,cohorts={},comparisons={},
        statistics='Median of matched sequence speedups; each duration is median of 3 repeated sums. 6000 resamples of 6 map clusters, retaining controls/modes/seeds; descriptive exploratory intervals. Validation has no interval. Best-baseline envelopes are retrospective, not deployable policies.')
    records=[]
    metrics=['online_us','all_us','amortized_us','repair_us','improvement_us','unchanged_us']
    for cohort in ['primary','validation','regression']:
        s=seq[seq.cohort==cohort];available=set(s.method)
        if not len(s):continue
        info=dict(sequences=int(s.name.nunique()),runs=int(run.name.isin(s.name).sum()),snapshots=int(reference.name.isin(s.name).sum()),
                  categories=reference[reference.name.isin(s.name)].category.value_counts().to_dict(),methods={})
        for method in sorted(available):
            z={m:compare(cohort,method,metric=m) for m in metrics};current=s[s.method==method]
            z['rss_mib']=float(current.rss_mib.median());z['certified_fraction']=float(current.certified.sum()/current.queries.sum())
            z['budget_hit_fraction']=float(current.budget_hits.sum()/current.queries.sum())
            z['median_online_ms']=float(current.online_us.median()/1000);z['median_setup_all_ms']=float(current.amortized_us.median()/1000)
            query=raw[(raw['method']==method)&raw.name.isin(current.name)&(raw.episode>0)].groupby(['name','episode']).total_us.median()
            z['p50_query_ms']=float(query.quantile(.50)/1000);z['p95_query_ms']=float(query.quantile(.95)/1000);z['max_query_ms']=float(query.max()/1000)
            info['methods'][method]=z
            records.append(dict(cohort=cohort,method=method,online=z['online_us']['median'],setup_included=z['amortized_us']['median'],repair=z['repair_us'].get('median'),
                 certificates=z['certified_fraction'],rss=z['rss_mib'],p95_ms=z['p95_query_ms']))
        for baseline in ['best-fresh','best-baseline','best-incremental']+sorted(available-{MAIN}):
            result['comparisons'][cohort+':'+baseline]={m:compare(cohort,baseline=baseline,metric=m) for m in metrics}
        result['cohorts'][cohort]=info
    p=seq[seq.cohort=='primary'].pivot(index='name',columns='method',values='online_us')
    z=(p['mpgaa-bbox']/p[MAIN]).rename('speedup').to_frame().join(cohorts.set_index('name')[['map','mode','control']])
    result['strata_vs_bbox']={key:{str(k):float(v.speedup.median()) for k,v in z.groupby(key)} for key in ['map','mode','control']}
    result['movement']=cohorts[cohorts.cohort!='regression'].groupby(['cohort','mode']).moves.agg(['min','max']).reset_index().to_dict('records')
    primary_jobs=cohorts[cohorts.cohort=='primary']
    opened=0
    for workfile in primary_jobs.workfile:
        lines=(ROOT/workfile).read_text().splitlines();at=2
        while at<len(lines):
            n=int(lines[at].split()[-1]);at+=1
            opened+=sum(int(lines[at+i].split()[-1])==0 for i in range(n));at+=n
    md=raw[(raw['method']==MAIN)&raw.name.isin(primary_jobs.name)].groupby(['name','episode']).median(numeric_only=True).reset_index()
    online=md[md.episode>0]
    result['activation']=dict(opened_events=opened,activated_events=float(md.activated_cells.sum()),
        fraction=float(md.activated_cells.sum()/opened),two_call_fraction=float((online.search_called==2).mean()),
        max_deferred_cells=int(md.deferred_cells.max()),refined_cells=int(md.refined_cells.sum()),notify_probes=int(md.notify_probes.sum()))
    # Paired exact-episode accounting. Zero expansions alone is not a certificate.
    work=[]
    for (method,name,rep),d in raw.groupby(['method','name','repeat']):
        work.append(dict(method=method,name=name,repeat=rep,expanded=float(d.expanded.sum()),cell_checks=float(d.cell_checks.sum()),
             witness_probes=float(d.witness_probes.sum()) if 'witness_probes' in d else 0,
             budget_hits=float(d.witness_budget_hit.sum()) if 'witness_budget_hit' in d else 0))
    pd.DataFrame(work).to_csv(OUT/'work.csv',index=False)
    target=OUT/('analysis_partial.json' if partial else 'analysis.json');target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    pd.DataFrame(records).to_csv(OUT/'summary.csv',index=False)
    print(pd.DataFrame(records).round(3).to_string(index=False))
    for cohort in result['cohorts']:
        print(cohort,{b:result['comparisons'][cohort+':'+b]['online_us'] for b in ['mpgaa-bbox','best-baseline']})
    return result

def plots(result):
    plot_cache()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.ticker import NullFormatter
    plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'pdf.fonttype':42})
    dest=OUT/'figures';dest.mkdir(exist_ok=True)
    methods=['fresh-backward','mpgaa-grouped','mpgaa-bbox','cached-dlite','cmesh-dlite','csb','mir','md']
    fig,axes=plt.subplots(1,2,figsize=(9,4.0),constrained_layout=True)
    primary=result['cohorts']['primary']['methods']
    for ax,metric,title in zip(axes,['online_us','amortized_us'],['Replanning only','With initial search and setup']):
        vals=[primary[m][metric]['median'] for m in methods];ci=[primary[m][metric]['ci'] for m in methods];y=np.arange(len(methods))
        ax.scatter(vals,y,c=['#707070']*7+['#be4d2d'],s=32,zorder=3);ax.hlines(y,[x[0] for x in ci],[x[1] for x in ci],color='black',lw=1)
        ax.set_yticks(y,[LABELS[m] for m in methods]);ax.invert_yaxis();ax.axvline(1,c='black',lw=.8);ax.set_xscale('log')
        ax.set_title(title);ax.set_xlabel('Speedup vs best fresh')
        lo=min(x[0] for x in ci)*.8;hi=max(x[1] for x in ci)*1.3;ticks=[x for x in [.1,.2,.5,1,2,5,10,20,50,100] if lo<=x<=hi]
        ax.set_xticks(ticks,[f'{x:g}' for x in ticks]);ax.set_xlim(lo,hi);ax.xaxis.set_minor_formatter(NullFormatter())
    fig.savefig(dest/'comparison.pdf');fig.savefig(dest/'comparison.png',dpi=180);plt.close(fig)
    # Direct paired comparison is the main claim, not a ratio of medians.
    seq=pd.read_csv(OUT/'sequence_metrics.csv');jobs=pd.DataFrame(json.loads((BASE/'cohorts.json').read_text())).set_index('name')
    fig,axes=plt.subplots(1,2,figsize=(8.8,3.6),constrained_layout=True)
    for i,cohort in enumerate(['primary','validation','regression']):
        p=seq[seq.cohort==cohort].pivot(index='name',columns='method',values='online_us')
        vals=p['mpgaa-bbox']/p[MAIN];rng=np.random.default_rng(123+i)
        axes[0].scatter(np.full(len(vals),i)+rng.uniform(-.13,.13,len(vals)),vals,s=17,alpha=.7,c=['#aa4c32','#387a9f','#777777'][i])
        axes[0].plot([i-.2,i+.2],[vals.median()]*2,color='black',lw=2)
    axes[0].axhline(1,color='black',lw=.8);axes[0].set_yscale('log');axes[0].set_xticks(range(3),['Background','New seed','Regression']);axes[0].set_ylabel('MD-A* speedup vs spatial MPGAA*')
    ps=seq[seq.cohort=='primary'].pivot(index='name',columns='method',values='online_us')
    ratio=(ps['mpgaa-bbox']/ps[MAIN]).to_frame('speedup').join(jobs[['map']])
    names=ratio['map'].unique();values=[ratio[ratio['map']==m].speedup.median() for m in names]
    axes[1].barh(names,values,color='#387a9f');axes[1].invert_yaxis();axes[1].axvline(1,c='black',lw=.8);axes[1].set_xlabel('Median paired speedup')
    fig.savefig(dest/'transfer.pdf');fig.savefig(dest/'transfer.png',dpi=180);plt.close(fig)
    names=['md','md64','md-scan','mc-scalar','mc-adaptive']
    fig,axes=plt.subplots(1,2,figsize=(8.8,3.1),constrained_layout=True)
    for ax,metric,title in zip(axes,['online_us','amortized_us'],['Replanning only','With setup']):
        vals=[primary[m][metric]['median'] for m in names];ax.barh([LABELS[m] for m in names],vals,color='#658fa6');ax.invert_yaxis();ax.axvline(1,c='black',lw=.8)
        ax.set_xlabel('Speedup vs best fresh');ax.set_title(title)
    fig.savefig(dest/'ablation.pdf');fig.savefig(dest/'ablation.png',dpi=180);plt.close(fig)

    # Minimal reproducible counterexample from the independent oracle tests.
    grid=np.ones((12,18))
    for r in [2,5,10]:grid[r,2:16]=0
    for c in [2,15]:grid[2:11,c]=0
    fig,axes=plt.subplots(1,2,figsize=(8.8,3.2),constrained_layout=True)
    for i,ax in enumerate(axes):
        ax.imshow(grid,cmap='Greys',vmin=0,vmax=1,interpolation='nearest')
        ax.scatter([8],[2],marker='s',s=65,color='#e4a13a',zorder=4)
        ax.scatter([2,15],[5,5],color='black',s=22,zorder=5)
        ax.text(1.1,4.5,'s',color='white',weight='bold');ax.text(15.8,4.5,'t',color='white',weight='bold')
        ax.set_xticks([]);ax.set_yticks([])
        if i==0:
            ax.plot([2,15],[5,5],color='#4087ad',lw=2)
            ax.set_title('Opening deferred: optimal cost 13')
        else:
            ax.scatter([8],[5],marker='s',s=65,color='#bd4434',zorder=4)
            ax.plot([2,2,15,15],[5,10,10,5],'--',color='#999999',lw=2,label='Restricted: 23')
            ax.plot([2,2,15,15],[5,2,2,5],color='#39836c',lw=2,label='After activation: 19')
            ax.set_title('Broken route activates the old opening');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.02),ncol=2,fontsize=8)
    fig.savefig(dest/'reactivation.pdf');fig.savefig(dest/'reactivation.png',dpi=180);plt.close(fig)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--partial',action='store_true');p.add_argument('--plots',action='store_true');a=p.parse_args()
    r=analyze(a.partial)
    if a.plots:plots(r)
