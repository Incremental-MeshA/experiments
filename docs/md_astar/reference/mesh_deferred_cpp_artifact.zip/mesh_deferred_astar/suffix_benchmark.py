#!/usr/bin/env python3
"""Run the suffix ablation after (never concurrently with) the main benchmark."""
import csv
import hashlib
import io
import json
import random
import subprocess
from pathlib import Path
from prepare import ROOT


def main():
    mainraw=ROOT/'results/balanced'
    if len(list(mainraw.glob('*.csv')))!=1512:raise RuntimeError('Finish all main measurements before suffix phase')
    raw=ROOT/'results/suffix';raw.mkdir(exist_ok=True)
    # Select precisely the tasks already in the main study.
    names=sorted({p.stem.split('__lattice_astar__')[0] for p in mainraw.glob('*__lattice_astar__r0.csv')})
    if len(names)!=48:raise RuntimeError('Main balanced study must be complete first')
    rng=random.Random(7332);rng.shuffle(names)
    meta={'binary_sha256':hashlib.sha256((ROOT/'bin/ima_suffix').read_bytes()).hexdigest(),
          'reference_binary_sha256':hashlib.sha256((ROOT/'bin/ima').read_bytes()).hexdigest(),
          'protocol':'Separate suffix-sharing ablation, after main benchmark. Prefix mesh and cached lattice rerun, random order within task/repeat.'}
    (raw/'environment.json').write_text(json.dumps(meta,indent=2)+'\n')
    done=0
    for name in names:
        control=name.split('__')[1]
        reference=list(csv.DictReader((mainraw/f'{name}__lattice_astar__r0.csv').open()))
        for rep in range(3):
            methods=[('prefix_dlite','ima','mesh','dlite'),('cached_dlite','ima','lattice','dlite-cached'),
                     ('suffix_dlite','ima_suffix','suffix','dlite')]
            rng.shuffle(methods)
            for method,binary,model,algo in methods:
                path=raw/f'{name}__{method}__r{rep}.csv'
                if path.exists():done+=1;continue
                run=subprocess.run([str(ROOT/f'bin/{binary}'),'--model',str(ROOT/f'data/{control}_{model}.model'),
                                    '--workload',str(ROOT/f'workloads/{name}.work'),'--algorithm',algo],
                                   text=True,capture_output=True,check=True,timeout=180)
                rows=list(csv.DictReader(io.StringIO(run.stdout)))
                assert [x['cost'] for x in rows]==[x['cost'] for x in reference],name
                path.write_text(run.stdout)
                path.with_suffix('.rss').write_text(str(max(int(x['rss_kib']) for x in rows))+'\n')
                done+=1
        print(f'suffix phase {done}/432: {name}',flush=True)


if __name__=='__main__':main()
