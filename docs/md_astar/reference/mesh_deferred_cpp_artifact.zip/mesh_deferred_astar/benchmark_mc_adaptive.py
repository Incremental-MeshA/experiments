#!/usr/bin/env python3
"""Matched final experiment. Inputs fixed by the earlier frozen design."""
import argparse,csv,hashlib,io,json,platform,random,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE=ROOT/'results/certified';OUT=BASE/'adaptive'
MAIN=['mc-adaptive','mpgaa-bbox','mpgaa-grouped','fresh-backward','author-mesh','author-lattice','author-lazy','cached-dlite','cmesh-dlite','csb','mir']
ABLATIONS=['mc-scalar','mc-nogate','mc-geometric','mc-fresh']
VALIDATION=MAIN+['mc-scalar']
REGRESSION=['mc-adaptive','mc-scalar','mpgaa-bbox','mpgaa-grouped','fresh-backward','author-mesh']

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def command(job,method):
    model='lattice';algo=method;binary='certified_v1'
    if method in ['mc-adaptive','mc-scalar','mc-nogate','mc-geometric']:binary='mc_adaptive'
    elif method=='mpgaa-bbox':binary='mpgaa_bbox'
    elif method=='mc-fresh':algo='mc'
    elif method.startswith('author-'):binary='author_baseline'
    elif method=='cached-dlite':binary='ima';algo='dlite-cached'
    elif method=='cmesh-dlite':binary='ima';model='cmesh';algo='dlite'
    elif method in ['csb','mir']:binary='repair'
    return [str(ROOT/'bin'/binary),'--model',str(ROOT/f'data/{job["control"]}_{model}.model'),
            '--workload',str(ROOT/job['workfile']),'--algorithm',algo]

def run(cohort):
    OUT.mkdir(exist_ok=True);raw=OUT/'raw';raw.mkdir(exist_ok=True)
    plan=dict(primary=MAIN+ABLATIONS,validation=VALIDATION,regression=REGRESSION,repeats=3,
         input_cohort_sha256=digest(BASE/'cohorts.json'),reference_sha256=digest(BASE/'reference.csv'),
         main='mc-adaptive',note='Certificate front-end and spatially strengthened MPGAA* share the identical backend class. No tuning on validation/regression timings.')
    design=OUT/'design.json'
    if design.exists():assert json.loads(design.read_text())==plan
    else:design.write_text(json.dumps(plan,indent=2)+'\n')
    files=[ROOT/'bin'/x for x in ['mc_adaptive','mpgaa_bbox','certified_v1','repair','ima','author_baseline']]
    files += [ROOT/'src'/x for x in ['mc_adaptive.cpp','mpgaa_bbox_reference.hpp','certified.cpp','mpgaa_reference.hpp','repair.cpp','ima.cpp','author_baseline.cpp']]
    files += list((ROOT/'frozen/mc_v1').glob('*'))+[ROOT/'prepare_mpgaa_bbox.py']
    sha={str(p.relative_to(ROOT)):digest(p) for p in files};env=raw/'environment.json'
    if env.exists():assert json.loads(env.read_text())['sha256']==sha,'Code/binary changed'
    else:env.write_text(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),platform=platform.platform(),
        compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],cpu=subprocess.check_output(['lscpu'],text=True),
        sha256=sha,note='Sequential timed processes; randomized method order per sequence/repeat; no concurrent builds, tests or CPU-heavy analysis.'),indent=2)+'\n')
    expected={}
    for r in csv.DictReader((BASE/'reference.csv').open()):expected.setdefault(r['name'],[]).append(int(r['cost']))
    jobs=json.loads((BASE/'cohorts.json').read_text());jobs=[j for j in jobs if cohort=='all' or j['cohort']==cohort]
    rng=random.Random(1511927);rng.shuffle(jobs);start=time.monotonic();done=queries=0
    for job in jobs:
        assert digest(ROOT/job['workfile'])==job['workload_sha256']
        methods={'primary':MAIN+ABLATIONS,'validation':VALIDATION,'regression':REGRESSION}[job['cohort']]
        for rep in range(3):
            order=methods[:];rng.shuffle(order)
            for method in order:
                dst=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not dst.exists():
                    p=subprocess.run(command(job,method),check=True,text=True,capture_output=True,timeout=300)
                    rows=list(csv.DictReader(io.StringIO(p.stdout)))
                    assert [int(r['cost']) for r in rows]==expected[job['name']],(job['name'],method,'cost mismatch')
                    dst.write_text(p.stdout)
                else:
                    rows=list(csv.DictReader(dst.open()));assert [int(r['cost']) for r in rows]==expected[job['name']]
                done+=1;queries+=job['episodes']
        print(done,'runs;',round(time.monotonic()-start,1),'seconds;',job['name'],flush=True)
    (raw/f'completion_{cohort}.json').write_text(json.dumps(dict(status='passed',runs=done,queries=queries,sequences=len(jobs),cost_disagreements=0,seconds=time.monotonic()-start),indent=2)+'\n')
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cohort',choices=['primary','validation','regression','all'],default='all');a=p.parse_args();run(a.cohort)
