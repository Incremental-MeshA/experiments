# MD-A\*: Mesh-Deferred A\*

Отдельная статья об одном алгоритме для точного инкрементального планирования с примитивами движения. Ветка: `research/certified-mesh-a-star`.

MD-A\* откладывает влияние освобождённых клеток, которые не могут улучшить текущий путь. Нижняя оценка компилируется из mesh; очередь сохраняет её корректность при движении старта. При повреждении пути алгоритм пересматривает прежние исключения и делает не более двух вызовов MPGAA\*. Основной поиск работает на граничных состояниях mesh с примитивами как макрорёбрами.

Материалы: [статья PDF](paper/mesh_deferred_ru.pdf), [Markdown](paper/mesh_deferred_ru.md), [метод и доказательства](paper/md_method_ru.md), [реализация](src/mesh_deferred.cpp), [итоговые данные](results/deferred/). Предварительные варианты сертификатов находятся в `results/certified/`; их времена не смешиваются с итоговой фазой.

```bash
make mesh-deferred bin/mc_adaptive bin/certified_v1 bin/repair bin/ima bin/author_baseline
python tests/verify_mesh_deferred.py
python tests/verify_author.py
bin/mesh_deferred --model data/base_lattice.model \
  --workload workloads/bg__Berlin_2_256__base__fixed__1006.work \
  --algorithm md --dump
python benchmark_mesh_deferred.py --cohort primary
python benchmark_mesh_deferred.py --cohort validation
python benchmark_mesh_deferred.py --cohort regression
python analyze_mesh_deferred.py --plots
python render_mesh_deferred.py --pdf
```

Все сборки и тесты завершаются до измерений. Поисковые процессы запускаются последовательно, порядок методов перемешивается. Скрипты возобновляют уже измеренные серии; для нового измерения нужно предварительно переименовать `results/deferred/raw`. Контрольные суммы предотвращают смешивание исходников и бинарников. Диагностическая серия отдельно: `mechanism_mesh_deferred.py --stage reference`, затем `--stage run` и `--stage analyze`; геометрия уже зафиксирована.

Оптимальность проверяется независимым Python Dijkstra и полной проверкой покрытых клеток. В измерениях C++ также проверяет каждый возвращённый путь за пределами таймера. `--audit` проверяет эвристику в рабочем графе и совпадение mesh-компилятора с прямым перебором, поэтому используется только в тестах.

`md` — основной вариант с одной аддитивной поправкой и переносимой кучей; `md64` усиливает оценку 64 коэффициентами; `md-scan` заменяет кучу полным просмотром отложенных клеток. Это абляции одного алгоритма. Базовый MPGAA\* с тем же пространственным фильтром доступен в `bin/mpgaa_bbox`. `src/mpgaa_bbox_reference.hpp` воспроизводимо получается скриптом `prepare_mpgaa_bbox.py` из независимого порта алгоритмов 1–2 Hernández et al., AAAI 2015.

Авторское ядро MeshA\* взято из [PathPlanning/MeshAStar](https://github.com/PathPlanning/MeshAStar), commit `12574ff03d8d61ac153b4e4224eac2229a9577e1`, MIT. Точный список адаптаций и контрольные суммы исходных файлов: [UPSTREAM.json](third_party/mesha_author/UPSTREAM.json). Это порт с согласованными входами, double и общей допустимой эвристикой; он не называется неизменённым авторским бинарником.

Ускорение зависит от нагрузки. Отдельно приводятся фоновое перепланирование, строгий рост конечного оптимального продолжения, дополнительный seed, неизменённые прежние нагрузки и диагностическая семья. Исключение ненужного ремонта не подменяет ускорение поиска нового обхода.
