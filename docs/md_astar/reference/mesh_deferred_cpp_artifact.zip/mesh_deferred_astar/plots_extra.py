"""Static explanatory figures for the standalone paper."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def main():
    out=ROOT/'paper/figures';out.mkdir(exist_ok=True)
    fig,axes=plt.subplots(2,3,figsize=(9,6))
    for ax,name in zip(axes.ravel(),['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown']):
        rows=(ROOT/f'maps/{name}.map').read_text().splitlines();h=int(rows[1].split()[1]);w=int(rows[2].split()[1]);
        grid=np.array([[0 if c in '.GS' else 1 for c in r[:w]] for r in rows[4:4+h]])
        ax.imshow(grid,cmap='gray_r',interpolation='nearest',vmin=0,vmax=1);ax.set_title(f'{name} ({h} x {w})',fontsize=14);ax.set_axis_off()
    fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(out/f'maps.{ext}',dpi=240,bbox_inches='tight')
    plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,3.4));color='#2b8b66'
    def node(ax,x,y,label,initial=False,blocked=False):
        ax.scatter([x],[y],s=240 if initial else 160,c='#b64b42' if blocked else (color if initial else '#b8cbd8'),zorder=3,
                   marker='s' if initial else 'o',edgecolor='white',linewidth=1.2)
        if label:ax.text(x,y+.24,label,ha='center',va='bottom',fontsize=14)
    def edge(ax,a,b,label=None):
        ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#666','shrinkA':8,'shrinkB':8,'lw':1.3})
        if label:ax.text((a[0]+b[0])/2,(a[1]+b[1])/2-.17,label,ha='center',fontsize=14)
    ax=axes[0];node(ax,0,0,'s',True)
    for j,y in enumerate([-1,0,1]):
        edge(ax,(0,0),(3,y),f'$C_{j+1}$');node(ax,3,y,f'$t_{j+1}$',True)
    ax.set_title('State lattice / Boundary search',fontsize=14)
    ax=axes[1];node(ax,0,0,'s',True);node(ax,1,0,r'$\{p_1,p_2,p_3\}$');edge(ax,(0,0),(1,0),r'$\delta$')
    for j,y in enumerate([-1,0,1]):
        edge(ax,(1,0),(2,y),r'$\delta$' if y==0 else None);node(ax,2,y,f'$p_{j+1}$',blocked=j==2)
        edge(ax,(2,y),(3,y),fr'$C_{j+1}-2\delta$');node(ax,3,y,f'$t_{j+1}$',True)
    ax.set_title('Mesh: shared prefix\nand cell-level pruning',fontsize=14)
    for ax in axes:
        ax.set_xlim(-.3,3.4);ax.set_ylim(-1.5,1.7);ax.set_axis_off()
    fig.tight_layout()
    for ext in ['png','pdf']:fig.savefig(out/f'schematic.{ext}',dpi=240,bbox_inches='tight')
    plt.close(fig)


if __name__=='__main__':main()
