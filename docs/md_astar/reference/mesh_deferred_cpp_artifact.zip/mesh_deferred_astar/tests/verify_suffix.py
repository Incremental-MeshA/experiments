#!/usr/bin/env python3
"""Independent oracle and edge-consistency checks for suffix-oriented D* Lite."""
import csv
import io
import json
import subprocess
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT));sys.path.insert(0,str(ROOT/'tests'))
from verify import oracle
from prepare import d8


def read_model(path):
    t=iter(map(int,path.read_text().split()));H,P,Q,E,delta,alpha=[next(t) for _ in range(6)]
    prim={}
    for _ in range(P):
        pid,h,dr,dc,th,cost,n=[next(t) for _ in range(7)]
        trace=[(next(t),next(t)) for _ in range(n)];prim[pid]=(cost,trace)
    conf=[]
    for _ in range(Q):
        ini,depth,orr,orc,n=[next(t) for _ in range(5)];finals=[(next(t),next(t)) for _ in range(n)]
        conf.append((ini,depth,finals))
    edges=[]
    for _ in range(E):
        src,dst,dr,dc,cost,pid,n=[next(t) for _ in range(7)];trace=[(next(t),next(t)) for _ in range(n)]
        edges.append((src,dst,dr,dc,cost))
    return delta,alpha,prim,conf,edges


def main():
    checks=queries=0
    for control in ['base','add']:
        delta,alpha,pr,cf,edges=read_model(ROOT/f'data/{control}_suffix.model')
        def h(q,r,c,target):
            ini,k,finals=cf[q];tr,tc=target
            if ini>=0:return alpha*d8(r-tr,c-tc)
            return min(cost+alpha*d8(r-tr-trace[-1-index][0],c-tc-trace[-1-index][1])
                       for pid,index in finals for cost,trace in [pr[pid]])-delta*k
        for a,b,r,c,cost in edges:
            assert cost>0
            for target in [(0,0),(17,31),(-8,11)]:
                assert h(b,r,c,target)<=cost+h(a,0,0,target)
                checks+=1
        primitives=json.loads((ROOT/f'data/{control}_primitives.json').read_text())
        for work in sorted((ROOT/'tests/generated').glob(f'{control}_*.work')):
            lines=work.read_text().splitlines();mapfile=Path(lines[0]);ms=mapfile.read_text().splitlines();H=int(ms[1].split()[1]);W=int(ms[2].split()[1]);
            grid=[[x!='.' for x in row] for row in ms[4:4+H]];head=list(map(int,lines[1].split()));goal=tuple(head[3:]);expected=[]
            at=2
            while at<len(lines):
                r,c,heading,n=map(int,lines[at].split());at+=1
                for _ in range(n):
                    a,b,v=map(int,lines[at].split());at+=1;grid[a][b]=v
                expected.append(oracle(grid,(r,c,heading),goal,primitives))
            run=subprocess.run([str(ROOT/'bin/ima_suffix'),'--model',str(ROOT/f'data/{control}_suffix.model'),
                                '--workload',str(work),'--algorithm','dlite'],text=True,capture_output=True,check=True,timeout=60)
            got=[int(x['cost']) for x in csv.DictReader(io.StringIO(run.stdout))]
            assert got==expected,(work,expected,got,run.stderr)
            queries+=len(expected)
    report=dict(status='passed',differential_queries=queries,heuristic_edge_checks=checks,
                oracle='independent Python Dijkstra',variant='Suffix-Mesh D* Lite')
    (ROOT/'results/verification_suffix.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))


if __name__=='__main__':main()
