#!/usr/bin/env python3
"""Independent exact oracle for the frozen-field front-end and its backend."""
import hashlib,json,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from verify_repair import check_case,random_cases
from verify_certified import targeted_cases,bound_audit
METHODS=['mc-adaptive','mc-scalar','mc-nogate','mc-geometric','mpgaa-bbox']

def main():
    cases=sorted((ROOT/'tests/repair_cases').glob('*.work'));episodes=feasible=0
    with tempfile.TemporaryDirectory(prefix='mc_adaptive_') as directory:
        tmp=Path(directory);cases+=random_cases(tmp)
        for i,case in enumerate(cases):
            n,f=check_case(case,METHODS,ROOT/'bin/mc_adaptive');episodes+=n;feasible+=f
            if i%8==0:print('verified',i+1,'/',len(cases),flush=True)
        focused=targeted_cases(tmp)
        # Several skipped packets precede a real repair. The same cells toggle
        # more than once, and a deferred opening can create a shorter path.
        mp=tmp/'toy_deferred.map';mp.write_text('type octile\nheight 12\nwidth 18\nmap\n'+'\n'.join('.'*18 for _ in range(12))+'\n')
        wp=tmp/'toy_deferred.work';wp.write_text(mp.name+'\n5 2 0 5 15 0\n5 2 0 0\n5 2 0 2\n10 7 1\n10 8 1\n5 3 0 1\n10 7 0\n5 4 0 2\n10 8 0\n10 7 1\n5 4 0 1\n5 9 1\n5 4 0 3\n10 7 0\n5 9 0\n5 10 1\n5 3 0 1\n5 10 0\n')
        focused.append(wp)
        for case in focused:
            n,f=check_case(case,METHODS,ROOT/'bin/mc_adaptive',tmp);episodes+=n;feasible+=f
        cases+=focused
    files=['src/mc_adaptive.cpp','src/mpgaa_bbox_reference.hpp','src/certified.cpp','src/repair.cpp','src/ima.cpp','bin/mc_adaptive','bin/mpgaa_bbox']
    result=dict(status='passed',cases=len(cases),oracle_episodes=episodes,feasible_episodes=feasible,
        comparisons=episodes*len(METHODS),methods=METHODS,algebra=bound_audit(),
        checks=['independent Python Dijkstra','all swept cells of extracted trajectories',
                'mixed updates, disconnection and reconnection','moving, reversing and off-path start',
                'multiple deferred updates and toggles before a real repair','backend heuristic consistency after synchronization'],
        sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files})
    out=ROOT/'results/certified/adaptive';out.mkdir(exist_ok=True)
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ['algebra','sha256']},flush=True)
if __name__=='__main__':main()
