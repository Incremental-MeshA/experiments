#!/usr/bin/env python3
"""Additional large-workload invariant audit, outside all timing phases."""
import csv
import hashlib
import io
import json
import subprocess
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
    names=['Berlin_2_256__base__fixed__local__0','AR0307SR__base__fixed__path__0',
           'warehouse__base__fixed__churn__0','rooms__add__moving__churn__0']
    methods=['mdf','mfr','msp','csb','mir','mir-forward','mir-filter','mdf-rp'];queries=0
    for name in names:
        control=name.split('__')[1]
        expected=[int(r['cost']) for r in csv.DictReader((ROOT/f'results/balanced/{name}__lattice_astar__r0.csv').open())]
        for method in methods:
            p=subprocess.run([str(ROOT/'bin/repair'),'--model',str(ROOT/f'data/{control}_lattice.model'),
                '--workload',str(ROOT/f'workloads/{name}.work'),'--algorithm',method,'--audit'],
                capture_output=True,text=True,timeout=240)
            assert p.returncode==0,(name,method,p.stderr[-2000:])
            got=[int(r['cost']) for r in csv.DictReader(io.StringIO(p.stdout))]
            assert got==expected,(name,method,'costs');queries+=len(got)
        print('audited',name,flush=True)
    report=dict(status='passed',workloads=names,methods=methods,queries=queries,
         binary_sha256=hashlib.sha256((ROOT/'bin/repair').read_bytes()).hexdigest(),
         note='Large graph potential/tree invariants and trajectory checks; costs cross-checked against baseline A*, not independent Dijkstra.')
    (ROOT/'results/repair/large_audit.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
