#!/usr/bin/env python3
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from verify_repair import check_case

def main():
    methods=['author-mesh','author-lattice','author-lazy'];total=feasible=0
    cases=sorted((ROOT/'tests/repair_cases').glob('*.work'))
    for i,case in enumerate(cases):
        n,f=check_case(case,methods,ROOT/'bin/author_baseline');total+=n;feasible+=f
        if i%8==0:print('author core',i+1,'/',len(cases),flush=True)
    result=dict(status='passed',methods=methods,cases=len(cases),oracle_episodes=total,
                comparisons=total*len(methods),feasible_episodes=feasible,
                note='Author search core; double microcosts, common admissible metric, identical traces/topology. Every primitive trajectory checked against Python Dijkstra.')
    (ROOT/'results/certified/author_verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print(result)

if __name__=='__main__':main()
