#!/usr/bin/env python3
"""Independent Dijkstra, swept-path checks, and dual-bound algebra tests."""
import json
import random
import sys
import tempfile
import csv,io,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from verify_repair import check_case,random_cases
METHODS=['mc','mc-geometry','mc-flat','mc-uniform','mc-unbounded','sphere','primitive-gate','uniform','path-reuse','fresh','fresh-backward','fresh-mesh','mpgaa','mpgaa-grouped']


def targeted_cases(directory):
    primitives=[]
    for pid,(dr,dc) in enumerate([(0,1),(1,0),(0,-1),(-1,0)]):
        primitives.append(dict(id=pid,heading=0,goal=[dr,dc,0],cost=1000000,trace=[[0,0],[dr,dc]]))
    (directory/'toy_primitives.json').write_text(json.dumps(primitives))
    lines=['1 4 1 4 0 1000']
    for p in primitives:
        dr,dc,_=p['goal'];lines.append(f"{p['id']} 0 {dr} {dc} 0 1000000 2 0 0 {dr} {dc}")
    lines+=['0 0 0 0 0']
    for p in primitives:
        dr,dc,_=p['goal'];lines.append(f"0 0 {dr} {dc} 1000000 {p['id']} 2 0 0 {dr} {dc}")
    for suffix in ['lattice','mesh']:(directory/f'toy_{suffix}.model').write_text('\n'.join(lines)+'\n')
    cases=[]
    specs={
        'islands':([(r,9) for r in range(12)]+[(5,4),(6,4)],
                   [((5,2,0),[]),((5,2,0),[(5,4,0)]),((5,2,0),[(6,4,0)]),
                    ((5,2,0),[(5,9,0)]),((5,2,0),[(5,9,1)]),((5,2,0),[(5,9,0),(6,9,0)])]),
        'shortcut':([(r,9) for r in range(12) if r!=2],
                    [((5,2,0),[]),((5,2,0),[(5,9,0)]),((5,3,0),[(5,9,1)]),
                     ((5,3,0),[(5,9,0),(6,9,0)]),((5,4,0),[])]),
        'retirement':([(10,7),(10,8)],
                    [((5,2,0),[]),((5,2,0),[(10,7,0)]),((5,3,0),[(10,8,0)]),
                     ((5,4,0),[(5,2,1)]),((5,3,0),[]),((5,3,0),[(5,2,0)])])}
    for name,(blocked,steps) in specs.items():
        grid=[['.']*18 for _ in range(12)]
        for r,c in blocked:grid[r][c]='@'
        mp=directory/f'toy_{name}.map';wp=directory/f'toy_{name}.work'
        mp.write_text('type octile\nheight 12\nwidth 18\nmap\n'+'\n'.join(''.join(r) for r in grid)+'\n')
        text=[mp.name,'5 2 0 5 15 0']
        for s,changes in steps:
            text.append(' '.join(map(str,(*s,len(changes)))));text += [' '.join(map(str,q)) for q in changes]
        wp.write_text('\n'.join(text)+'\n');cases.append(wp)
    return cases


def bound_audit():
    vectors=[(1000,414),(414,1000),(-414,1000),(-1000,414),(-1000,-414),(-414,-1000),(414,-1000),(1000,-414)]
    norm=lambda r,c:1000*max(abs(r),abs(c))+414*min(abs(r),abs(c))
    report={};rng=random.Random(601113)
    for control in ['base','add']:
        primitives=json.loads((ROOT/f'data/{control}_primitives.json').read_text())
        alpha=min(p['cost']//norm(*p['goal'][:2]) for p in primitives if norm(*p['goal'][:2]))
        directions=[(r*alpha,c*alpha) for r,c in vectors]
        occurrences=[(p['cost'],p['goal'][0],p['goal'][1],r,c) for p in primitives for r,c in p['trace']]
        mu=[[min(C-ar*r-ac*c-br*(dr-r)-bc*(dc-c) for C,dr,dc,r,c in occurrences)
             for br,bc in directions] for ar,ac in directions]
        loose=0
        for C,dr,dc,r,c in occurrences:
            x=[ar*r+ac*c for ar,ac in directions];y=[br*(dr-r)+bc*(dc-c) for br,bc in directions]
            dual=max(x[a]+y[b]+mu[a][b] for a in range(8) for b in range(8))
            assert dual<=C
            if alpha*(norm(r,c)+norm(dr-r,dc-c))>C:loose+=1
        equal=0
        for _ in range(512):
            sr,sc,tr,tc,qr,qc=[rng.randrange(-80,81) for _ in range(6)]
            x=[ar*(qr-sr)+ac*(qc-sc) for ar,ac in directions]
            y=[br*(tr-qr)+bc*(tc-qc) for br,bc in directions]
            dual=max(x[a]+y[b]+mu[a][b] for a in range(8) for b in range(8))
            exact=min(alpha*(norm(qr-r-sr,qc-c-sc)+norm(tr-qr+r-dr,tc-qc+c-dc))+C for C,dr,dc,r,c in occurrences)
            assert dual<=exact,(control,dual,exact)
            equal+=dual==exact
        report[control]=dict(alpha=alpha,coefficients=64,occurrences=len(occurrences),
                            random_bound_checks=512,exact_matches=equal,unsafe_uncorrected_witnesses=loose,
                            mu=mu)
    return report


def main():
    output=ROOT/'results/certified';output.mkdir(exist_ok=True)
    algebra=bound_audit();episodes=feasible=0
    cases=sorted((ROOT/'tests/repair_cases').glob('*.work'))
    with tempfile.TemporaryDirectory(prefix='mc_test_') as tmp:
        cases+=random_cases(Path(tmp))
        for i,case in enumerate(cases):
            n,f=check_case(case,METHODS,ROOT/'bin/certified');episodes+=n;feasible+=f
            if i%8==0:print('verified',i+1,'/',len(cases),flush=True)
        focused=targeted_cases(Path(tmp))
        for case in focused:
            n,f=check_case(case,METHODS,ROOT/'bin/certified',Path(tmp));episodes+=n;feasible+=f
        island=Path(tmp)/'toy_islands.work';text=island.read_text().splitlines();text[0]=str(Path(tmp)/text[0]);island.write_text('\n'.join(text)+'\n')
        run=subprocess.run([str(ROOT/'bin/certified'),'--model',str(Path(tmp)/'toy_lattice.model'),'--workload',str(island),'--algorithm','mc'],check=True,capture_output=True,text=True)
        rows=list(csv.DictReader(io.StringIO(run.stdout)))
        assert rows[1]['certified']=='1' and rows[2]['certified']=='1' and rows[3]['search_called']=='1'
        cases+=focused
    report=dict(status='passed',cases=len(cases),oracle_episodes=episodes,feasible_episodes=feasible,
                comparisons=episodes*len(METHODS),methods=METHODS,algebra=algebra,
                checks=['independent Python Dijkstra','every swept cell of extracted paths',
                        'DAG-compiled 64 coefficients versus flat primitive enumeration',
                        'dual bound versus exact primitive witness bound','mixed updates and cuts/reopening',
                        'all headings, moving and reversing start','last-witness proof, disconnected islands, new shortcuts, retired witnesses'])
    (output/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print({k:v for k,v in report.items() if k!='algebra'},flush=True)


if __name__=='__main__':main()
