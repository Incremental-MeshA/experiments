#!/usr/bin/env python3
"""Independently project mesh paths and verify boundary-event masks."""
import hashlib
import json
from collections import defaultdict
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def model(path):
    it=iter(map(int,path.read_text().split()))
    headings,P,Q,E,delta,alpha=[next(it) for _ in range(6)]
    prims={}
    for _ in range(P):
        pid,h,r,c,t,cost,n=[next(it) for _ in range(7)]
        prims[pid]=dict(h=h,r=r,c=c,t=t,cost=cost,trace={(next(it),next(it)) for _ in range(n)})
    for _ in range(Q):
        initial,depth,r,c,n=[next(it) for _ in range(5)]
        for _ in range(n):next(it);next(it)
    out=defaultdict(list)
    for _ in range(E):
        src,dst,r,c,cost,pid,n=[next(it) for _ in range(7)]
        trace=[(next(it),next(it)) for _ in range(n)]
        out[src].append((dst,r,c,cost,pid,trace))
    assert next(it,None) is None
    return headings,prims,out


def main():
    result={}
    for control in ['base','add']:
        path=ROOT/f'data/{control}_mesh.model';headings,prims,out=model(path)
        projected={};index=defaultdict(set);paths=0
        for h in range(headings):
            stack=[(h,0,0,0,{(0,0)})]
            while stack:
                u,r,c,cost,trace=stack.pop()
                for dst,dr,dc,price,pid,segment in out[u]:
                    nr,nc=r+dr,c+dc;support=trace|{(r+a,c+b) for a,b in segment}|{(nr,nc)}
                    if pid>=0:
                        p=prims[pid];paths+=1
                        assert (h,nr,nc,dst,cost+price)==(p['h'],p['r'],p['c'],p['t'],p['cost']),pid
                        assert support==p['trace'],(control,pid,'swept cells')
                        assert pid not in projected,'Non-unique primitive projection'
                        projected[pid]=support
                        for d in support:index[h,*d].add(pid)
                    else:stack.append((dst,nr,nc,cost+price,support))
        direct=defaultdict(set)
        for pid,p in prims.items():
            for d in p['trace']:direct[p['h'],*d].add(pid)
        assert dict(index)==dict(direct) and len(projected)==len(prims)
        result[control]=dict(mesh_paths=paths,boundary_primitives=len(prims),
            direct_dependencies=sum(map(len,direct.values())),mesh_support_groups=len(index),
            model_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),status='passed')
    (ROOT/'results/repair/mesh_projection.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
