#!/usr/bin/env python3
"""Independent exact oracle for the frozen-field front-end and its backend."""
import csv,hashlib,io,json,subprocess,sys,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from verify_repair import check_case,random_cases
from verify_certified import targeted_cases,bound_audit
METHODS=['md','md64','md-scan']

def main():
    cases=sorted((ROOT/'tests/repair_cases').glob('*.work'));episodes=feasible=0
    with tempfile.TemporaryDirectory(prefix='mc_adaptive_') as directory:
        tmp=Path(directory);cases+=random_cases(tmp)
        for i,case in enumerate(cases):
            n,f=check_case(case,METHODS,ROOT/'bin/mesh_deferred');episodes+=n;feasible+=f
            if i%8==0:print('verified',i+1,'/',len(cases),flush=True)
        focused=targeted_cases(tmp)
        # Several skipped packets precede a real repair. The same cells toggle
        # more than once, and a deferred opening can create a shorter path.
        mp=tmp/'toy_deferred.map';mp.write_text('type octile\nheight 12\nwidth 18\nmap\n'+'\n'.join('.'*18 for _ in range(12))+'\n')
        wp=tmp/'toy_deferred.work';wp.write_text(mp.name+'\n5 2 0 5 15 0\n5 2 0 0\n5 2 0 2\n10 7 1\n10 8 1\n5 3 0 1\n10 7 0\n5 4 0 2\n10 8 0\n10 7 1\n5 4 0 1\n5 9 1\n5 4 0 3\n10 7 0\n5 9 0\n5 10 1\n5 3 0 1\n5 10 0\n')
        focused.append(wp)
        # A formerly irrelevant opening becomes useful after the cheap route
        # breaks: old optimum 13, restricted detour 23, actual detour 19.
        grid=[['@']*18 for _ in range(12)]
        for r in [2,5,10]:
            for c in range(2,16):grid[r][c]='.'
        for c in [2,15]:
            for r in range(2,11):grid[r][c]='.'
        grid[2][8]='@'
        mp=tmp/'toy_reactivate.map';mp.write_text('type octile\nheight 12\nwidth 18\nmap\n'+'\n'.join(''.join(r) for r in grid)+'\n')
        wp=tmp/'toy_reactivate.work';wp.write_text(mp.name+'\n5 2 0 5 15 0\n5 2 0 0\n5 2 0 1\n2 8 0\n5 2 0 1\n5 8 1\n')
        focused.append(wp)
        for case in focused:
            n,f=check_case(case,METHODS,ROOT/'bin/mesh_deferred',tmp);episodes+=n;feasible+=f
        lines=wp.read_text().splitlines();lines[0]=str(mp);wp.write_text('\n'.join(lines)+'\n')
        check=subprocess.run([str(ROOT/'bin/mesh_deferred'),'--model',str(tmp/'toy_lattice.model'),'--workload',str(wp),'--algorithm','md'],check=True,text=True,capture_output=True)
        rows=list(csv.DictReader(io.StringIO(check.stdout)))
        assert [int(r['cost']) for r in rows]==[13000000,13000000,19000000]
        assert rows[1]['certified']=='1' and rows[1]['deferred_cells']=='1'
        assert rows[2]['search_called']=='2' and rows[2]['activated_cells']=='1'
        cases+=focused
    files=['src/mesh_deferred.cpp','src/mpgaa_bbox_reference.hpp','src/certified.cpp','src/repair.cpp','src/ima.cpp','bin/mesh_deferred','bin/mpgaa_bbox']
    result=dict(status='passed',cases=len(cases),oracle_episodes=episodes,feasible_episodes=feasible,
        comparisons=episodes*len(METHODS),methods=METHODS,algebra=bound_audit(),
        checks=['independent Python Dijkstra','all swept cells of extracted trajectories',
                'mixed updates, disconnection and reconnection','moving, reversing and off-path start',
                'multiple deferred updates and toggles before a real repair','backend heuristic consistency in the restricted working graph', 'transported keys on backward and off-path motion'],
        sha256={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files})
    out=ROOT/'results/deferred';out.mkdir(exist_ok=True)
    (out/'verification.json').write_text(json.dumps(result,indent=2)+'\n')
    print({k:v for k,v in result.items() if k not in ['algebra','sha256']},flush=True)
if __name__=='__main__':main()
