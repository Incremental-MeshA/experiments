#!/usr/bin/env python3
"""Independent Python Dijkstra oracle + adversarial dynamic differential tests."""
from __future__ import annotations
import csv
import heapq
import io
import json
import random
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from prepare import compile_model, d8
COUNTS={'oracle_snapshots':0,'feasible_snapshots':0,'infeasible_snapshots':0}


def oracle(grid, start, goal, primitives):
    H, W = len(grid), len(grid[0])
    if grid[start[0]][start[1]] or grid[goal[0]][goal[1]]:
        return -1
    byheading = [[] for _ in range(16)]
    for p in primitives:
        byheading[p['heading']].append(p)
    dist = {start: 0}; queue = [(0, start)]
    while queue:
        cost, u = heapq.heappop(queue)
        if cost != dist[u]:
            continue
        if u == goal:
            return cost
        r, c, h = u
        for p in byheading[h]:
            if any(not (0 <= r+a < H and 0 <= c+b < W) or grid[r+a][c+b] for a, b in p['trace']):
                continue
            a, b, t = p['goal']; v = (r+a, c+b, t)
            new = cost+p['cost']
            if new < dist.get(v, 10**30):
                dist[v] = new; heapq.heappush(queue, (new, v))
    return -1


def heuristic_checks(primitives):
    headings, delta, alpha, models = compile_model(primitives)
    byid = {p['id']: p for p in primitives}
    checks = 0
    for name, graph in models.items():
        def h(q, r, c, reverse, target):
            cf = graph['configs'][q]
            tr, tc = target
            metric = lambda a,b: alpha*d8(a,b)
            if reverse:
                a,b=cf['origin']; return metric(r-a-tr,c-b-tc)+delta*cf['depth']
            if cf['initial'] >= 0:
                return metric(r-tr,c-tc)
            return min(byid[pid]['cost']+metric(r+byid[pid]['goal'][0]-byid[pid]['trace'][k][0]-tr,
                                               c+byid[pid]['goal'][1]-byid[pid]['trace'][k][1]-tc)
                       for pid,k in cf['finals'])-delta*cf['depth']
        for edge in graph['edges']:
            assert edge['cost'] > 0
            for target in [(0,0),(31,17),(-13,8)]:
                a=h(edge['src'],0,0,False,target);b=h(edge['dst'],edge['dr'],edge['dc'],False,target)
                assert a<=edge['cost']+b, (name,edge,'forward',a,b)
                a=h(edge['src'],0,0,True,target);b=h(edge['dst'],edge['dr'],edge['dc'],True,target)
                assert b<=edge['cost']+a, (name,edge,'backward',a,b)
                checks += 2
    return checks


def run_case(name, control, grid, start, goal, steps, moving=False):
    out=ROOT/'tests'/'generated';out.mkdir(exist_ok=True)
    mapfile=out/f'{name}.map';work=out/f'{name}.work'
    H,W=len(grid),len(grid[0])
    mapfile.write_text(f'type octile\nheight {H}\nwidth {W}\nmap\n'+'\n'.join(''.join('@' if v else '.' for v in row) for row in grid)+'\n')
    lines=[str(mapfile), ' '.join(map(str,(*start,*goal)))]
    primitives=json.loads((ROOT/f'data/{control}_primitives.json').read_text())
    expected=[];costgrid=[row[:] for row in grid]
    for s, changes in steps:
        lines.append(' '.join(map(str,(*s,len(changes)))))
        for r,c,v in changes:
            costgrid[r][c]=v;lines.append(f'{r} {c} {v}')
        expected.append(oracle(costgrid,s,goal,primitives))
    work.write_text('\n'.join(lines)+'\n')
    COUNTS['oracle_snapshots']+=len(expected)
    COUNTS['feasible_snapshots']+=sum(x>=0 for x in expected)
    COUNTS['infeasible_snapshots']+=sum(x<0 for x in expected)
    methods=[('lattice','astar'),('mesh','astar'),('cmesh','astar'),('lattice','dijkstra'),
             ('lattice','dlite'),('mesh','dlite'),('cmesh','dlite'),('mesh','dlite-scan'),
             ('lattice','dlite-cached'),('lattice','dlite-batch'),('lattice','astar-cached'),('lattice','astar-batch')]
    if not moving:
        methods += [(k,'lpa') for k in ['lattice','mesh','cmesh']] + [('lattice','lpa-batch'),('lattice','lpa-cached')]
    for kind,algo in methods:
        cmd=[str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{control}_{kind}.model'),
             '--workload',str(work),'--algorithm',algo,'--dump']
        run=subprocess.run(cmd,text=True,capture_output=True,check=True,timeout=60)
        rows=list(csv.DictReader(io.StringIO(run.stdout)))
        got=[int(row['cost']) for row in rows]
        assert got==expected,(name,control,kind,algo,expected,got,run.stderr)
        # Also verify the exported primitive sequence independently in Python.
        lookup={p['id']:p for p in primitives}
        costgrid=[row[:] for row in grid]
        for ep,(line,(s,changes)) in enumerate(zip(run.stderr.splitlines(),steps)):
            for r,c,v in changes:costgrid[r][c]=v
            ids=list(map(int,line.split()[2:]));r,c,h=s;total=0
            if expected[ep]<0:
                assert not ids;continue
            for pid in ids:
                p=lookup[pid];assert h==p['heading']
                assert all(0<=r+a<H and 0<=c+b<W and not costgrid[r+a][c+b] for a,b in p['trace'])
                a,b,h=p['goal'];r+=a;c+=b;total+=p['cost']
            assert (r,c,h)==goal and total==expected[ep]
    return len(methods)*len(steps)


def main():
    checks=0;queries=0
    for control in ['base','add']:
        primitives=json.loads((ROOT/f'data/{control}_primitives.json').read_text())
        checks+=heuristic_checks(primitives)
        for seed in range(4):
            rng=random.Random(seed);H=W=18
            grid=[[int(rng.random()<.10) for _ in range(W)] for _ in range(H)]
            start=(4,3,0);goal=(13,14,4);grid[4][3]=grid[13][14]=0
            steps=[(start,[])]
            # Explicit unreachable episode and reopening all cells of a cut.
            steps.append((start,[(r,9,1) for r in range(H)]))
            steps.append((start,[(r,9,grid[r][9]) for r in range(H)]))
            for j in range(8):
                changes=[(rng.randrange(H),rng.randrange(W),rng.randrange(2)) for _ in range(5)]
                steps.append((start,changes))
            steps.extend([(start,[(4,3,1)]),(start,[(4,3,0)]),(start,[(13,14,1)]),
                          (start,[(13,14,0)]),(start,[])])
            queries+=run_case(f'{control}_fixed_{seed}',control,grid,start,goal,steps)
            movingsteps=[]
            for j,(s,ch) in enumerate(steps):
                s=start if j%2==0 else (4,4,0)
                movingsteps.append((s,ch))
            queries+=run_case(f'{control}_moving_{seed}',control,grid,start,goal,movingsteps,True)
        # start=goal exercises empty-path reconstruction and blocked root.
        grid=[[0]*8 for _ in range(8)];s=(3,3,0)
        queries+=run_case(f'{control}_same',control,grid,s,s,[(s,[]),(s,[(3,3,1)]),(s,[(3,3,0)])])
        # Guaranteed nonempty feasible trajectories for BOTH primitive libraries.
        grid=[[0]*40 for _ in range(32)];s=(12,4,0);t=(12,28,0)
        positive=[(s,[]),(s,[(12,12,1)]),(s,[(12,12,0)]),
                  (s,[(r,20,1) for r in range(32)]),(s,[(r,20,0) for r in range(32)]),
                  (s,[(11,18,1),(13,18,1)]),(s,[(11,18,0),(13,18,0)]),(s,[])]
        queries+=run_case(f'{control}_positive',control,grid,s,t,positive)
        positive_moving=[((12,4 if j%2==0 else 12,0),ch) for j,(_,ch) in enumerate(positive)]
        queries+=run_case(f'{control}_positive_moving',control,grid,s,t,positive_moving,True)
        for heading in range(16):
            # Guaranteed positive single-primitive task for every discrete heading.
            p=min((p for p in primitives if p['heading']==heading and p['goal'][2]==heading),key=lambda p:p['cost'])
            grid=[[0]*32 for _ in range(32)];s=(16,16,heading)
            dr,dc,th=p['goal'];t=(16+dr,16+dc,th);a,b=p['trace'][1]
            orientation=[(s,[]),(s,[(16+a,16+b,1)]),(s,[(16+a,16+b,0)])]
            queries+=run_case(f'{control}_heading_{heading}',control,grid,s,t,orientation)
    report=dict(status='passed',heuristic_edge_checks=checks,differential_queries=queries,**COUNTS,
                oracle='independent Python Dijkstra over full swept-cell traces',
                controls=['base','add'],cases=['random increases/decreases','complete cuts and reopening',
                'moving start','blocked start/goal','start equals goal','index versus full scan','independent reconstruction',
                'nonempty paths for all 16 headings and both control sets'])
    (ROOT/'results'/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
