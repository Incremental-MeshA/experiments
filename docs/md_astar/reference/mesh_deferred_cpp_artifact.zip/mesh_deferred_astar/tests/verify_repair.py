#!/usr/bin/env python3
"""Independent shortest-path oracle, trajectory checks and internal invariants."""
import csv
import io
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from verify import oracle
METHODS=['fresh','fresh-mesh','fresh-backward','gaa','gaa-plain','msp','csb','bridge-eager','forest','mdf','mfr','mir','mir-forward','mir-filter','mdf-rp']


def check_case(case,methods=METHODS,binary=None,data_dir=None):
    lines=case.read_text().splitlines();control=case.name.split('_')[0]
    data_dir=Path(data_dir or ROOT/'data')
    prims=json.loads((data_dir/f'{control}_primitives.json').read_text());byid={p['id']:p for p in prims}
    mapfile=case.parent/lines[0];rows=mapfile.read_text().splitlines();H=int(rows[1].split()[1]);W=int(rows[2].split()[1])
    grid=[[v!='.' for v in row[:W]] for row in rows[4:4+H]]
    startgoal=tuple(map(int,lines[1].split()));goal=startgoal[3:]
    steps=[];at=2;expected=[];cur=[row[:] for row in grid]
    while at<len(lines):
        r,c,h,n=map(int,lines[at].split());at+=1;changes=[]
        for _ in range(n):
            a,b,v=map(int,lines[at].split());at+=1;changes.append((a,b,v));cur[a][b]=v
        steps.append(((r,c,h),changes));expected.append(oracle(cur,(r,c,h),goal,prims))
    with tempfile.TemporaryDirectory(prefix='repair_case_') as tmp:
        work=Path(tmp)/'test.work';lines[0]=str(mapfile);work.write_text('\n'.join(lines)+'\n')
        for method in methods:
            cmd=[str(binary or ROOT/'bin/repair'),'--model',str(data_dir/f'{control}_lattice.model'),
                 '--workload',str(work),'--algorithm',method,'--dump','--audit']
            run=subprocess.run(cmd,text=True,capture_output=True,timeout=120)
            if run.returncode:raise AssertionError((case.name,method,run.stderr,run.stdout[-1500:]))
            got=[int(r['cost']) for r in csv.DictReader(io.StringIO(run.stdout))]
            assert got==expected,(case.name,method,expected,got)
            trajectories=[x for x in run.stderr.splitlines() if x.startswith('PATH ')]
            assert len(trajectories)==len(steps)
            cur=[row[:] for row in grid]
            for ep,(text,(start,changes)) in enumerate(zip(trajectories,steps)):
                for a,b,v in changes:cur[a][b]=v
                ids=list(map(int,text.split()[2:]));r,c,h=start;cost=0
                if expected[ep]<0:assert not ids;continue
                for pid in ids:
                    p=byid[pid];assert h==p['heading']
                    assert all(0<=r+a<H and 0<=c+b<W and not cur[r+a][c+b] for a,b in p['trace'])
                    a,b,h=p['goal'];r+=a;c+=b;cost+=p['cost']
                assert (r,c,h)==goal and cost==expected[ep]
    return len(steps),sum(x>=0 for x in expected)


def random_cases(directory):
    out=[]
    for control in ['base','add']:
        for seed in range(6):
            rng=random.Random(1900+seed);H=W=28
            grid=[[int(rng.random()<.035) for _ in range(W)] for _ in range(H)]
            for r in range(9,17):
                for c in range(1,27):grid[r][c]=0
            s=(12,3,0);t=(12,23,0);name=f'{control}_mixed_{seed}'
            mp=directory/(name+'.map');wp=directory/(name+'.work')
            mp.write_text(f'type octile\nheight {H}\nwidth {W}\nmap\n'+'\n'.join(''.join('@' if v else '.' for v in row) for row in grid)+'\n')
            lines=[mp.name,' '.join(map(str,(*s,*t)))]
            for ep in range(22):
                current=s if ep%4<2 else (12,4,0)
                changes=[] if ep==0 else [(rng.randrange(H),rng.randrange(W),rng.randrange(2)) for _ in range(5)]
                if ep in (4,9,15):changes += [(12,11,1)]
                if ep in (5,10,16):changes += [(12,11,0)]
                if ep in (7,17):changes += [(r,14,1) for r in range(H)]
                if ep in (8,18):changes += [(r,14,0) for r in range(H)]
                lines.append(' '.join(map(str,(*current,len(changes)))))
                lines.extend(f'{a} {b} {v}' for a,b,v in changes)
            wp.write_text('\n'.join(lines)+'\n');out.append(wp)
    return out


def main():
    snapshots=feasible=0
    cases=sorted((ROOT/'tests/repair_cases').glob('*.work'))
    with tempfile.TemporaryDirectory(prefix='repair_random_') as tmp:
        cases+=random_cases(Path(tmp))
        for i,case in enumerate(cases):
            n,f=check_case(case);snapshots+=n;feasible+=f
            if i%8==0:print('verified',i+1,'/',len(cases),flush=True)
    report={'status':'passed','methods':METHODS,'cases':len(cases),'oracle_episodes':snapshots,
            'feasible_episodes':feasible,'differential_comparisons':snapshots*len(METHODS),
            'checks':['independent Python Dijkstra','independent swept-cell trajectory validation',
                      'potential consistency before search and after learning','dependency-forest path labels',
                      'mixed increases/decreases','moving and reversing start','all 16 headings','cuts and reopening']}
    target=ROOT/'results/repair';target.mkdir(exist_ok=True)
    (target/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))


if __name__=='__main__':main()
