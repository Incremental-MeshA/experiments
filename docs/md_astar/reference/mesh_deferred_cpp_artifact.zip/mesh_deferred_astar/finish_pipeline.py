#!/usr/bin/env python3
"""Wait for the current main study and finish its dependent steps in order."""
import argparse
import os
import subprocess
import time
from pathlib import Path
ROOT=Path(__file__).resolve().parent


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--wait-pid',type=int);args=ap.parse_args()
    if args.wait_pid:
        while True:
            try:os.kill(args.wait_pid,0)
            except ProcessLookupError:break
            time.sleep(5)
    count=len(list((ROOT/'results/balanced').glob('*.csv')))
    if count!=1512:raise RuntimeError(f'Main study incomplete: {count}/1512')
    for script in ['tests/verify.py','tests/verify_suffix.py','suffix_benchmark.py',
                   'analyze.py','analyze_suffix.py','plots_extra.py','audit.py']:
        print('START',script,flush=True)
        subprocess.run(['python',script],cwd=ROOT,check=True)
    subprocess.run(['python','render_paper.py','--pdf'],cwd=ROOT,check=True)


if __name__=='__main__':main()
