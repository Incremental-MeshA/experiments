#!/usr/bin/env python3
"""Frozen cohorts, independent reference paths, then sequential paired timings."""
import argparse
import csv
import hashlib
import io
import json
import platform
import random
import subprocess
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results/repair'
REPAIR_BINARY=ROOT/'bin/repair_v1'
MAPS=['random','rooms','warehouse','Berlin_2_256','AR0307SR','ht_0_hightown']
METHODS=['fresh','fresh-mesh','fresh-backward','gaa','gaa-plain','msp','bridge-eager','csb','forest','mdf','mfr',
         'lattice-astar','lattice-dlite','cached-dlite','cmesh-dlite']
LEGACY={'lattice-astar':('lattice','astar'),'lattice-dlite':('lattice','dlite'),
        'cached-dlite':('lattice','dlite-cached'),'cmesh-dlite':('cmesh','dlite')}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def command(job,method,binary=None):
    kind,algo=LEGACY.get(method,('lattice',method))
    return [str(ROOT/'bin/ima' if method in LEGACY else (binary or REPAIR_BINARY)),
            '--model',str(ROOT/f'data/{job["control"]}_{kind}.model'),
            '--workload',str(ROOT/'workloads'/f'{job["name"]}.work'),'--algorithm',algo]


def jobs():
    original=[]
    for p in sorted((ROOT/'results/balanced').glob('*__lattice_astar__r0.csv')):
        name=p.name.removesuffix('__lattice_astar__r0.csv')
        mapname,control,mode,pattern,seed=name.split('__')
        original.append(dict(name=name,map=mapname,control=control,mode=mode,pattern=pattern,
                             seed=int(seed),cohort='original'))
    assert len(original)==48
    heldout=[]
    for i,mapname in enumerate(MAPS):
        for j,control in enumerate(['base','add']):
            mode=['fixed','moving'][(i+j)%2]
            pattern=['local','path','churn'][(i+2*j)%3]
            name=f'{mapname}__{control}__{mode}__{pattern}__4'
            heldout.append(dict(name=name,map=mapname,control=control,mode=mode,pattern=pattern,
                                seed=4,cohort='heldout'))
    return original+heldout


def prepare():
    OUT.mkdir(exist_ok=True)
    cohort=jobs()
    for job in cohort:
        work=ROOT/'workloads'/f'{job["name"]}.work'
        if not work.exists():
            cmd=[str(ROOT/'bin/ima'),'--model',str(ROOT/f'data/{job["control"]}_lattice.model'),
                 '--map',str(ROOT/'maps'/f'{job["map"]}.map'),'--generate',str(work),
                 '--seed','1004','--episodes','16','--pattern',job['pattern'],
                 '--moving',str(int(job['mode']=='moving'))]
            subprocess.run(cmd,check=True,capture_output=True,text=True,timeout=180)
        job['workload_sha256']=digest(work)
    # Membership is fixed before any candidate is timed. New seed is selected by
    # the map/control formula above, never by a candidate's speed or success.
    (OUT/'cohorts.json').write_text(json.dumps(cohort,indent=2)+'\n')
    reference=[]
    refdir=OUT/'reference';refdir.mkdir(exist_ok=True)
    for job in cohort:
        run=subprocess.run(command(job,'fresh')+['--dump'],check=True,capture_output=True,text=True,timeout=180)
        rows=list(csv.DictReader(io.StringIO(run.stdout)))
        expectedfile=ROOT/'results/balanced'/f'{job["name"]}__lattice_astar__r0.csv'
        if expectedfile.exists():
            expected=[r['cost'] for r in csv.DictReader(expectedfile.open())]
        else:
            other=subprocess.run(command(job,'lattice-astar'),check=True,capture_output=True,text=True,timeout=180)
            expected=[r['cost'] for r in csv.DictReader(io.StringIO(other.stdout))]
        assert [r['cost'] for r in rows]==expected,job['name']
        (refdir/f'{job["name"]}.paths').write_text(run.stderr)
        for r in rows:
            ep=int(r['episode']);old=int(r['previous_suffix_cost']);cost=int(r['cost'])
            if ep==0:category='initial'
            elif old<0:category='off_reference'
            elif cost<0:category='disconnected'
            elif cost>old:category='increase_finite'
            elif cost<old:category='improvement'
            elif r['previous_suffix_valid']=='0':category='unchanged_broken'
            else:category='unchanged_valid'
            reference.append(dict(name=job['name'],cohort=job['cohort'],episode=ep,cost=cost,
                                  previous_suffix_cost=old,previous_suffix_valid=r['previous_suffix_valid'],category=category))
    with (OUT/'reference.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=reference[0],lineterminator='\n');writer.writeheader();writer.writerows(reference)
    print('Prepared',len(cohort),'sequences,',len(reference),'snapshots; finite forced repairs:',
          sum(r['category']=='increase_finite' for r in reference),flush=True)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--stage',choices=['prepare','run'],default='run')
    ap.add_argument('--cohort',choices=['all','original','heldout','pilot'],default='all')
    ap.add_argument('--repeats',type=int,default=3)
    ap.add_argument('--methods',nargs='+',default=METHODS,choices=METHODS)
    ap.add_argument('--label',default='raw')
    args=ap.parse_args()
    if args.stage=='prepare':prepare();return
    cohort=json.loads((OUT/'cohorts.json').read_text())
    if args.cohort in ('original','heldout'):cohort=[j for j in cohort if j['cohort']==args.cohort]
    if args.cohort=='pilot':
        wanted={'random__base__fixed__local__0','rooms__add__moving__churn__0',
                'warehouse__base__fixed__churn__0','Berlin_2_256__base__fixed__local__0'}
        cohort=[j for j in cohort if j['name'] in wanted]
        assert len(cohort)==4,[j['name'] for j in cohort]
    raw=OUT/args.label;raw.mkdir(exist_ok=True)
    fingerprints={'repair':digest(REPAIR_BINARY),'ima':digest(ROOT/'bin/ima'),
                  'repair.cpp':digest(ROOT/'frozen/v1/repair.cpp'),'ima.cpp':digest(ROOT/'src/ima.cpp')}
    for j in cohort:assert digest(ROOT/'workloads'/f'{j["name"]}.work')==j['workload_sha256']
    env=raw/'environment.json'
    if env.exists():assert json.loads(env.read_text())['sha256']==fingerprints,'Binaries or source changed; use a new label'
    else:
        env.write_text(json.dumps(dict(utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
             platform=platform.platform(),python=platform.python_version(),
             cpu=subprocess.check_output(['lscpu'],text=True),compiler=subprocess.check_output(['g++','--version'],text=True).splitlines()[0],
             sha256=fingerprints,args=vars(args),note='Sequential processes, random method order per sequence/repeat. No concurrent test/build tasks.'),indent=2)+'\n')
    ref={}
    for row in csv.DictReader((OUT/'reference.csv').open()):ref.setdefault(row['name'],[]).append(int(row['cost']))
    rng=random.Random(851031);rng.shuffle(cohort);begin=time.monotonic();done=0
    for job in cohort:
        for rep in range(args.repeats):
            order=args.methods[:];rng.shuffle(order)
            for method in order:
                dst=raw/f'{job["name"]}__{method}__r{rep}.csv'
                if not dst.exists():
                    run=subprocess.run(command(job,method),capture_output=True,text=True,timeout=240)
                    if run.returncode:raise RuntimeError((job['name'],method,run.stderr[-3000:]))
                    rows=list(csv.DictReader(io.StringIO(run.stdout)))
                    assert [int(r['cost']) for r in rows]==ref[job['name']],(job['name'],method,'cost mismatch')
                    dst.write_text(run.stdout)
                else:
                    rows=list(csv.DictReader(dst.open()))
                    assert [int(r['cost']) for r in rows]==ref[job['name']]
                done+=1
        print(f'{done} runs, {time.monotonic()-begin:.1f}s; {job["name"]}',flush=True)
    (raw/'completion.json').write_text(json.dumps(dict(status='passed',runs=done,
         queries=done*17,sequences=len(cohort),repeats=args.repeats,methods=args.methods,
         seconds=time.monotonic()-begin,cost_disagreements=0),indent=2)+'\n')


if __name__=='__main__':main()
